# Senita TV — texniki qeydlər (v1.2.2)

Android TV + Android telefon üçün IPTV pleyer (M3U və Xtream Codes). Bir APK hər iki cihazda işləyir.
Tətbiqin içində heç bir playlist yoxdur — hər müştəri öz linkini əlavə edir.

## Əsas məlumatlar
- Ad: **Senita TV**, paket ID: `az.senita.tv`
- Capacitor 7, veb hissə `www/` qovluğunda (vanilla JS)
- Native: `android/app/src/main/java/az/senita/tv/` → `MainActivity.java`, `MrbDevicePlugin.java`
- Versiya 4 yerdədir: `android/app/build.gradle` (versionCode/versionName), `package.json`, `www/appinfo.json`, `www/js/config.js`

## Build (GitHub Actions)
- `.github/workflows/build-apk.yml` — repo-ya `update.zip` yüklənəndə onu açır, commit edir və build edir.
  - zip-in içində tək qovluq ola bilər (məs. `senita-tv-android/`) — avtomatik tanınır.
  - `.github` qovluğu zip ilə dəyişmir; workflow-u GitHub-da əl ilə redaktə et.
- İmza: `android/keystore/release.p12` (alias `senitatv`), şifrə GitHub secret `SIGNING_PASSWORD`-dadır.
- Nəticə (Actions → Artifacts):
  - **SenitaTV** → `SenitaTV.apk` (müştərilərə quraşdırmaq üçün)
  - **PlayStore-AAB** → `SenitaTV-PlayStore.aab` (Play Console üçün)
  - Secret yoxdursa yalnız `SenitaTV-DEBUG.apk` — bunu müştəriyə quraşdırma.

## Abunəlik sistemi
- `www/services/license-service.js` + `MrbDevicePlugin.getDeviceId` + Ayarlar → "Abunəlik".
- Server ayarları: `www/js/config.js` → `license: { url, anonKey }` (Supabase Project URL + publishable key).
  **İkisi də boş qalsa sistem sönülüdür** — tətbiq blok olmadan işləyir.
- Ödəniş dövrü: hər ayın 1-i gün sonu (Bakı vaxtı). Gecikən ödəniş köhnə dövrdən sayılır.
- Cihaz kodu (MAC + açar) ANDROID_ID-dən yaranır: eyni cihaz + eyni imza = eyni kod.
- Yoxlama: açılışda, hər 1 saatdan bir və fondan qayıdanda (15 dəq-dən bir). Bloklu ekranda hər 1 dəq.
- Oflayn: son aktiv yoxlamadan sonra 3 gün işləyir; bitmə anı keçəndə internetsiz də bloklanır.
- Server (SQL) və admin panel ayrıca paketdədir.

## Pleyer idarəsi
- Telefon: alt menyu (Əsas · Canlı TV · Filmlər · Seriallar · Ayarlar), toxunma kontrolları.
- TV pultu: OK — pauza, ▲▼ — kanal, ◀ — kanal siyahısı, 0–9 — nömrə ilə keçid, rəngli düymə — favorit, Back — geri / iki dəfə çıxış.
