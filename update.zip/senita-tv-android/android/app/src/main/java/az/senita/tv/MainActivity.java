package az.senita.tv;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    private boolean tv = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // Custom native plugin must be registered before super.onCreate()
        registerPlugin(MrbDevicePlugin.class);

        super.onCreate(savedInstanceState);

        tv = MrbDevicePlugin.isTv(this);
        Window window = getWindow();

        if (tv) {
            // TV: keep the screen on all the time (no screensaver)
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }

        // Same behaviour on every Android version: we draw edge-to-edge and
        // move the WebView away from the system bars ourselves (see insets listener).
        WindowCompat.setDecorFitsSystemWindows(window, false);
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(window, window.getDecorView());
        controller.setAppearanceLightStatusBars(false);
        controller.setAppearanceLightNavigationBars(false);

        if (getBridge() == null) return;

        WebView webView = getBridge().getWebView();
        WebSettings settings = webView.getSettings();

        // TV layout: fixed 1920px canvas scaled to the screen.
        // Phone layout: real device-width (set by www/js/platform.js), no scaling.
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(tv);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);

        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setDomStorageEnabled(true);

        // Remote control: D-pad focus goes to the WebView
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.requestFocus();

        // System bar insets -> WebView margins.
        // In the player (immersive) only the camera cut-out is kept free.
        ViewCompat.setOnApplyWindowInsetsListener(webView, (v, windowInsets) -> {
            Insets insets;
            if (MrbDevicePlugin.isImmersive()) {
                insets = windowInsets.getInsets(WindowInsetsCompat.Type.displayCutout());
            } else {
                Insets bars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
                // keep text fields visible above the on-screen keyboard
                Insets ime = windowInsets.getInsets(WindowInsetsCompat.Type.ime());
                insets = Insets.of(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
            }

            ViewGroup.LayoutParams lp = v.getLayoutParams();
            if (lp instanceof ViewGroup.MarginLayoutParams) {
                ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) lp;
                if (mlp.leftMargin != insets.left || mlp.topMargin != insets.top
                    || mlp.rightMargin != insets.right || mlp.bottomMargin != insets.bottom) {
                    mlp.setMargins(insets.left, insets.top, insets.right, insets.bottom);
                    v.setLayoutParams(mlp);
                }
            }
            return WindowInsetsCompat.CONSUMED;
        });
        ViewCompat.requestApplyInsets(webView);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // rotation: recompute the margins for the new bar positions
        if (getBridge() != null) {
            View webView = getBridge().getWebView();
            if (webView != null) {
                ViewCompat.requestApplyInsets(webView);
                webView.postDelayed(() -> ViewCompat.requestApplyInsets(webView), 250);
            }
        }
    }
}
