package az.senita.tv;

import android.app.Activity;
import android.app.UiModeManager;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Native helper used by www/js/platform.js
 *  - getInfo():     is this device a TV?
 *  - getDeviceId(): ANDROID_ID + model for the subscription (virtual MAC) system.
 *                   ANDROID_ID stays the same for this device + signing key,
 *                   even after the app is uninstalled and installed again.
 *  - enterPlayer(): phone -> landscape + hide status/navigation bars + keep screen on
 *  - exitPlayer():  phone -> normal UI again
 * The WebView margins (system bar insets) are applied in MainActivity and
 * re-computed every time the mode or the orientation changes.
 */
@CapacitorPlugin(name = "MrbDevice")
public class MrbDevicePlugin extends Plugin {

    private static volatile boolean immersive = false;

    public static boolean isImmersive() {
        return immersive;
    }

    public static boolean isTv(Context context) {
        try {
            UiModeManager uiModeManager = (UiModeManager) context.getSystemService(Context.UI_MODE_SERVICE);
            if (uiModeManager != null && uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION) {
                return true;
            }
        } catch (Exception ignored) {
            // fall through to feature checks
        }

        PackageManager pm = context.getPackageManager();
        if (pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK)) {
            return true;
        }
        return !pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN);
    }

    @PluginMethod
    public void getInfo(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("isTv", isTv(getContext()));
        call.resolve(ret);
    }

    @PluginMethod
    public void getDeviceId(PluginCall call) {
        String id = null;
        try {
            id = Settings.Secure.getString(getContext().getContentResolver(), Settings.Secure.ANDROID_ID);
        } catch (Exception ignored) {
            // JS side falls back to a stored random id
        }
        String model = ((Build.MANUFACTURER == null ? "" : Build.MANUFACTURER) + " "
            + (Build.MODEL == null ? "" : Build.MODEL)).trim();
        JSObject ret = new JSObject();
        ret.put("id", id == null ? "" : id);
        ret.put("model", model);
        call.resolve(ret);
    }

    @PluginMethod
    public void enterPlayer(PluginCall call) {
        final Activity activity = getActivity();
        if (activity == null) {
            call.resolve();
            return;
        }

        activity.runOnUiThread(() -> {
            Window window = activity.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            if (!isTv(activity)) {
                immersive = true;
                activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(window, window.getDecorView());
                controller.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                controller.hide(WindowInsetsCompat.Type.systemBars());
                refreshInsets();
            }
            call.resolve();
        });
    }

    @PluginMethod
    public void exitPlayer(PluginCall call) {
        final Activity activity = getActivity();
        if (activity == null) {
            call.resolve();
            return;
        }

        activity.runOnUiThread(() -> {
            Window window = activity.getWindow();

            if (!isTv(activity)) {
                immersive = false;
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(window, window.getDecorView());
                controller.show(WindowInsetsCompat.Type.systemBars());
                controller.setAppearanceLightStatusBars(false);
                controller.setAppearanceLightNavigationBars(false);
                activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                refreshInsets();
            }
            call.resolve();
        });
    }

    private void refreshInsets() {
        if (getBridge() == null) return;
        View webView = getBridge().getWebView();
        if (webView != null) {
            ViewCompat.requestApplyInsets(webView);
            webView.postDelayed(() -> ViewCompat.requestApplyInsets(webView), 300);
        }
    }
}
