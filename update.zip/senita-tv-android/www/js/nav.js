/* Senita TV — spatial navigation for TV remotes.
   Any element with [data-f] is focusable. Arrows move to the nearest element
   in that direction; OK clicks it. Pages can take over keys with onKey(). */
(function () {
  "use strict";

  const Nav = {
    current: null,
    lastContent: null,
    scope: null,
    scopeStack: [],
    page: null,

    root: function () {
      return this.scope || document.getElementById("app") || document.body;
    },

    visible: function (el) {
      if (!el || !el.isConnected) return false;
      if (el.disabled) return false;
      const r = el.getClientRects();
      return r.length > 0 && r[0].width > 0 && r[0].height > 0;
    },

    focusables: function () {
      const nodes = this.root().querySelectorAll("[data-f]");
      const out = [];
      for (let i = 0; i < nodes.length; i++) if (this.visible(nodes[i])) out.push(nodes[i]);
      return out;
    },

    inRail: function (el) {
      return !!(el && el.closest && el.closest(".rail"));
    },

    focus: function (el, opts) {
      opts = opts || {};
      if (!el) return;
      if (this.current && this.current !== el) this.current.classList.remove("is-f");
      this.current = el;
      el.classList.add("is-f");
      if (!this.inRail(el) && !this.scope) this.lastContent = el;
      if (!opts.noScroll) {
        try { el.scrollIntoView({ block: "nearest", inline: "nearest" }); } catch (e) {}
      }
      if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") {
        /* keep the TV keyboard closed until OK is pressed */
      }
      if (this.page && typeof this.page.onFocus === "function" && !this.inRail(el)) {
        try { this.page.onFocus(el); } catch (e) {}
      }
    },

    blur: function () {
      if (this.current) this.current.classList.remove("is-f");
      this.current = null;
    },

    focusFirst: function (selector) {
      const root = this.root();
      let el = selector ? root.querySelector(selector) : null;
      if (el && !this.visible(el)) el = null;
      if (!el) {
        const list = this.focusables().filter(function (x) { return !Nav.inRail(x); });
        el = list[0] || this.focusables()[0];
      }
      if (el) this.focus(el);
      return el;
    },

    focusRail: function () {
      const el = document.querySelector(".rail .ritem.on") || document.querySelector(".rail [data-f]");
      if (el) this.focus(el);
    },

    pushScope: function (el) {
      this.scopeStack.push({ scope: this.scope, current: this.current });
      this.scope = el;
      this.blur();
    },

    popScope: function () {
      const prev = this.scopeStack.pop();
      this.blur();
      this.scope = prev ? prev.scope : null;
      if (prev && prev.current && prev.current.isConnected) this.focus(prev.current, { noScroll: true });
    },

    move: function (dir) {
      const cur = this.current;
      if (!cur || !cur.isConnected || !this.visible(cur)) {
        this.focusFirst();
        return true;
      }

      /* from the rail to the right: back to where the user was */
      if (dir === "right" && this.inRail(cur) && !this.scope) {
        if (this.page && typeof this.page.focusIn === "function") {
          this.blur();
          this.page.focusIn();
          return true;
        }
        if (this.lastContent && this.lastContent.isConnected && this.visible(this.lastContent)) {
          this.focus(this.lastContent);
          return true;
        }
      }

      const target = this.pick(cur, dir);
      if (!target) {
        if (this.page && typeof this.page.onEdge === "function") return !!this.page.onEdge(dir, cur);
        return false;
      }

      /* entering the rail from the content: land on the active section */
      if (this.inRail(target) && !this.inRail(cur)) {
        this.focusRail();
        return true;
      }

      this.focus(target);
      return true;
    },

    pick: function (cur, dir) {
      const r = cur.getBoundingClientRect();
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height / 2;
      const list = this.focusables();
      let best = null;
      let bestScore = Infinity;

      for (let i = 0; i < list.length; i++) {
        const el = list[i];
        if (el === cur || el.contains(cur) || cur.contains(el)) continue;
        const b = el.getBoundingClientRect();
        const bx = b.left + b.width / 2;
        const by = b.top + b.height / 2;
        let primary, secondary, overlap;

        if (dir === "right" || dir === "left") {
          if (dir === "right" && b.left < r.right - 4 && bx <= cx + 1) continue;
          if (dir === "left" && b.right > r.left + 4 && bx >= cx - 1) continue;
          if (dir === "right" && bx <= cx) continue;
          if (dir === "left" && bx >= cx) continue;
          primary = dir === "right" ? Math.max(0, b.left - r.right) : Math.max(0, r.left - b.right);
          overlap = Math.min(r.bottom, b.bottom) - Math.max(r.top, b.top);
          secondary = overlap > 0 ? 0 : Math.abs(by - cy);
        } else {
          if (dir === "down" && by <= cy + 1) continue;
          if (dir === "up" && by >= cy - 1) continue;
          if (dir === "down" && b.top < r.bottom - 4 && by <= cy) continue;
          if (dir === "up" && b.bottom > r.top + 4 && by >= cy) continue;
          primary = dir === "down" ? Math.max(0, b.top - r.bottom) : Math.max(0, r.top - b.bottom);
          overlap = Math.min(r.right, b.right) - Math.max(r.left, b.left);
          secondary = overlap > 0 ? Math.abs(b.left - r.left) * 0.05 : Math.abs(bx - cx);
        }

        const score = primary + secondary * 2;
        if (score < bestScore) {
          bestScore = score;
          best = el;
        }
      }
      return best;
    },

    enter: function () {
      const el = this.current;
      if (!el || !el.isConnected) return false;
      if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") {
        el.focus();
        return true;
      }
      el.click();
      return true;
    },

    reset: function (page) {
      this.blur();
      this.page = page || null;
      this.lastContent = null;
    }
  };

  /* Magic Remote / mouse pointer: hovering focuses */
  document.addEventListener("mouseover", function (e) {
    if (!window.Platform || !Platform.isTV) return;
    const el = e.target && e.target.closest ? e.target.closest("[data-f]") : null;
    if (el && el !== Nav.current && Nav.root().contains(el)) Nav.focus(el, { noScroll: true });
  }, true);

  window.Nav = Nav;
})();
