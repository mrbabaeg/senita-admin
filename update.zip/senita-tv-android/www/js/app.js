/* =========================================================
   Senita TV — application core v1.1
   Router + history, frame (phone tab bar / TV rail), keys,
   toasts, loading, modals, TV stage scaling, boot.
   ========================================================= */
(function () {
  "use strict";

  /* No built-in playlist: the app ships without any content.
     Every user adds their own M3U link or Xtream account. */
  const DEFAULT_PLAYLIST = { name: "", url: "", type: "m3u" };

  const TABS = ["home", "live", "movies", "series", "settings"];
  const FULLSCREEN = ["splash", "player", "onboarding"];
  const BACK_CODES = [8, 27, 461, 10009, 166];

  const MRB = {
    version: (window.APP_CONFIG && APP_CONFIG.version) || "1.2.2",
    defaultPlaylist: DEFAULT_PLAYLIST,

    state: {
      activeRoute: "splash",
      params: {},
      stack: [],
      page: null,
      modal: null,
      lastExitPress: 0,
      booted: false
    },

    pages: function () {
      return {
        splash: window.SplashPage,
        onboarding: window.LanguagePage,
        language: window.LanguagePage,
        home: window.HomePage,
        live: window.LivePage,
        movies: window.VodPage,
        series: window.VodPage,
        detail: window.DetailPage,
        search: window.SearchPage,
        favorites: window.FavoritesPage,
        playlists: window.PlaylistsPage,
        settings: window.SettingsPage,
        player: window.PlayerPage
      };
    },

    /* ---------------- boot ---------------- */
    boot: async function () {
      if (this.state.booted) return;
      this.state.booted = true;
      this.app = document.getElementById("app");

      if (window.RecentManager) RecentManager.installed = true;

      this.installKeys();
      this.installErrorHandlers();
      this.startLicense();
      if (window.Platform && Platform.isTV) {
        this.fitStage();
        window.addEventListener("resize", () => this.fitStage());
      }

      window.addEventListener("mrb:playlist-updated", () => this.refreshPage("playlist"));
      window.addEventListener("mrb:epg-updated", () => this.refreshPage("epg"));

      this.navigate("splash", {}, { replace: true });
      const started = Date.now();

      try {
        this.ensureDefaultPlaylist();
        try { if (window.XMLTVService && XMLTVService.init) XMLTVService.init(); } catch (e) {}

        const hasData = window.PlaylistManager && PlaylistManager.hasActivePlaylistData ? PlaylistManager.hasActivePlaylistData() : true;
        if (!hasData && window.AutoRefresh && AutoRefresh.refreshNow) {
          if (window.SplashPage) SplashPage.setStatus(t("loadingChannels"));
          const refresh = AutoRefresh.refreshNow("first-run").catch(function () { return null; });
          await Promise.race([refresh, this.sleep(20000)]);
        }
      } catch (e) {
        console.warn("Boot step failed", e);
      }

      const wait = 600 - (Date.now() - started);
      if (wait > 0) await this.sleep(wait);

      setTimeout(function () {
        try { if (window.SearchEngine && SearchEngine.buildFromPlaylist) SearchEngine.buildFromPlaylist(); } catch (e) {}
        try { if (window.PlaylistManager && PlaylistManager.ensureEpg) PlaylistManager.ensureEpg(); } catch (e) {}
      }, 2500);

      if (!I18n.hasChoice()) {
        this.navigate("onboarding", { first: true }, { replace: true });
        return;
      }
      this.goStart();
    },

    /* Abunəlik yoxlaması (virtual MAC). Server ayarları yoxdursa sönülüdür.
       Blok ekranı tətbiqin üstünü örtür; pleyer açıqdırsa dayandırılır. */
    startLicense: function () {
      if (!window.MrbLicense) return;
      try {
        MrbLicense.onChange((st) => {
          if (MrbLicense.isBlocking() && this.state.activeRoute === "player") {
            this.state.stack = [];
            this.navigate("home", {}, { replace: true });
          }
          if (this.state.activeRoute === "settings" && window.SettingsPage && SettingsPage.renderLicense) {
            SettingsPage.renderLicense(st);
          }
        });
        MrbLicense.start({
          version: this.version,
          platform: window.Platform && Platform.isTV ? "tv" : "phone",
          lang: window.I18n ? I18n.lang : "az"
        }).catch(function (e) { console.warn("License start failed", e); });
      } catch (e) {
        console.warn("License start failed", e);
      }
    },

    goStart: function () {
      const settings = window.StorageCore ? StorageCore.getSettings() : {};
      const last = window.StorageCore ? StorageCore.getLastChannel() : null;
      this.state.stack = [];
      if (settings.autoplayLastChannel && last && last.url) {
        this.navigate("home", {}, { replace: true });
        this.navigate("player", { channel: last, channels: this.channelsFor(last) });
        return;
      }
      this.navigate("home", {}, { replace: true });
    },

    ensureDefaultPlaylist: function () {
      if (!window.StorageCore) return;
      try {
        const playlists = StorageCore.getPlaylists();
        if (playlists.length) {
          if (!StorageCore.getActivePlaylistId()) StorageCore.setActivePlaylistId(playlists[0].id);
          return;
        }
        if (!DEFAULT_PLAYLIST.url) return;
        const p = StorageCore.addPlaylist({ type: DEFAULT_PLAYLIST.type, name: DEFAULT_PLAYLIST.name, url: DEFAULT_PLAYLIST.url, isDefault: true });
        if (p && p.id) StorageCore.setActivePlaylistId(p.id);
      } catch (e) {
        console.warn("Default playlist failed", e);
      }
    },

    /* channels to zap through for a channel (its category, else all) */
    channelsFor: function (ch) {
      const all = window.PlaylistManager ? PlaylistManager.getActiveLiveChannels() : [];
      if (!ch) return all;
      const group = ch.group || "";
      const same = group ? all.filter(function (x) { return (x.group || "") === group; }) : [];
      return same.length ? same : (all.length ? all : [ch]);
    },

    /* ---------------- routing ---------------- */
    navigate: function (route, params, options) {
      options = options || {};
      params = params || {};
      const pages = this.pages();
      const Page = pages[route];
      if (!Page) {
        console.warn("Unknown route", route);
        return;
      }

      const prevRoute = this.state.activeRoute;
      const prevPage = this.state.page;

      if (TABS.indexOf(route) >= 0 && !options.keepStack) {
        this.state.stack = [];
      } else if (!options.replace && prevPage && FULLSCREEN.indexOf(prevRoute) < 0 && prevRoute !== route) {
        const saved = typeof prevPage.getState === "function" ? prevPage.getState() : this.state.params;
        this.state.stack.push({ route: prevRoute, params: saved || {} });
        if (this.state.stack.length > 20) this.state.stack.shift();
      } else if (!options.replace && prevRoute === "player" && route !== "player") {
        /* leaving the player forward (e.g. to the live list) keeps history */
      }

      this.closeModal(true);
      if (prevPage && typeof prevPage.destroy === "function") {
        try { prevPage.destroy(); } catch (e) { console.warn("destroy failed", e); }
      }

      this.state.activeRoute = route;
      this.state.params = params;
      this.state.page = Page;

      this.renderFrame(route);
      const host = document.getElementById("page");
      if (window.Nav) Nav.reset(Page);

      try {
        Page.mount(host, Object.assign({ route: route }, params));
      } catch (e) {
        console.error("Page failed", route, e);
        host.innerHTML = '<div class="empty"><h3>' + UI.esc(t("errorTitle")) + '</h3><p>' + UI.esc(e.message || String(e)) + '</p></div>';
      }

      if (window.Platform && Platform.isTV && window.Nav && !Nav.current && route !== "player" && route !== "splash") {
        if (!(Page.focusIn && Page.manualFocus)) Nav.focusFirst();
      }
    },

    renderFrame: function (route) {
      const tv = !!(window.Platform && Platform.isTV);
      if (FULLSCREEN.indexOf(route) >= 0) {
        this.app.innerHTML = '<div class="frame"><section class="page" id="page"></section></div>';
        return;
      }
      if (tv) {
        const items = [
          ["home", "home", t("navHome")],
          ["live", "tv", t("navLive")],
          ["movies", "film", t("navMovies")],
          ["series", "series", t("navSeries")],
          ["search", "search", t("navSearch")],
          ["favorites", "star", t("navFavorites")]
        ];
        let rail = '<aside class="rail"><div class="brand"><img src="assets/app-logo.png" alt=""><span>Senita TV</span></div>';
        items.forEach(function (it) {
          rail += '<button class="ritem' + (route === it[0] ? " on" : "") + '" data-f data-go="' + it[0] + '">' + Icon(it[1], 22) + UI.esc(it[2]) + '</button>';
        });
        rail += '<div class="spacer"></div><button class="ritem' + (route === "settings" || route === "playlists" || route === "language" ? " on" : "") + '" data-f data-go="settings">' + Icon("settings", 22) + UI.esc(t("navSettings")) + '</button></aside>';
        this.app.innerHTML = '<div class="frame">' + rail + '<section class="page" id="page"></section></div>';
        this.app.querySelectorAll(".rail [data-go]").forEach((b) => {
          b.addEventListener("click", () => {
            const go = b.getAttribute("data-go");
            if (go === this.state.activeRoute) { if (window.Nav) { Nav.move("right"); } return; }
            this.navigate(go, {});
          });
        });
        return;
      }
      const showTabs = TABS.indexOf(route) >= 0;
      let html = '<div class="frame"><section class="page" id="page"></section></div>';
      if (showTabs) {
        const tabs = [
          ["home", "home", t("navHome")],
          ["live", "tv", t("navLive")],
          ["movies", "film", t("navMovies")],
          ["series", "series", t("navSeries")],
          ["settings", "settings", t("navSettings")]
        ];
        html += '<nav class="tabbar">';
        tabs.forEach(function (tb) {
          html += '<button class="tab' + (route === tb[0] ? " on" : "") + '" data-go="' + tb[0] + '">' + Icon(tb[1], 22) + UI.esc(tb[2]) + '</button>';
        });
        html += '</nav>';
      }
      this.app.innerHTML = html;
      this.app.querySelectorAll(".tabbar [data-go]").forEach((b) => {
        b.addEventListener("click", () => {
          const go = b.getAttribute("data-go");
          if (go === this.state.activeRoute) {
            const sc = document.querySelector("#page .scroll, #page .live-list");
            if (sc) sc.scrollTop = 0;
            return;
          }
          this.navigate(go, {});
        });
      });
    },

    rerender: function () {
      const route = this.state.activeRoute;
      const Page = this.state.page;
      const params = Page && typeof Page.getState === "function" ? Page.getState() : this.state.params;
      this.navigate(route, params, { replace: true, keepStack: true });
    },

    refreshPage: function (reason) {
      const Page = this.state.page;
      if (!Page || this.state.activeRoute === "splash") return;
      if (typeof Page.refresh === "function") {
        try { Page.refresh(reason); } catch (e) {}
      }
    },

    back: function () {
      if (this.state.modal) {
        this.closeModal();
        return;
      }
      const Page = this.state.page;
      if (Page && typeof Page.onBack === "function") {
        try { if (Page.onBack()) return; } catch (e) {}
      }
      const route = this.state.activeRoute;
      if (route === "splash" || (route === "onboarding")) {
        this.exitApp();
        return;
      }
      const prev = this.state.stack.pop();
      if (prev) {
        this.navigate(prev.route, prev.params, { replace: true, keepStack: true });
        return;
      }
      if (route !== "home") {
        this.navigate("home", {}, { replace: true });
        return;
      }
      this.exitApp();
    },

    exitApp: function () {
      const now = Date.now();
      if (window.AndroidBridge && AndroidBridge.isAndroid) {
        if (now - this.state.lastExitPress < 2000) {
          AndroidBridge.exitApp();
          return;
        }
        this.state.lastExitPress = now;
        this.toast(t("pressBackToExit"));
        return;
      }
      try {
        if (window.webOS && typeof webOS.platformBack === "function") webOS.platformBack();
      } catch (e) {}
    },

    /* ---------------- keys ---------------- */
    isBackKey: function (e) {
      const k = e.key;
      return k === "Escape" || k === "GoBack" || k === "BrowserBack" || k === "Backspace" || BACK_CODES.indexOf(e.keyCode) >= 0;
    },

    installKeys: function () {
      document.addEventListener("keydown", (e) => {
        const route = this.state.activeRoute;
        if (route === "splash") { e.preventDefault(); return; }

        const tv = !!(window.Platform && Platform.isTV);
        const target = e.target;
        const typing = target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA");

        if (typing) {
          if (e.key === "Enter" && tv) { target.blur(); e.preventDefault(); return; }
          if ((e.key === "Escape" || e.keyCode === 461 || e.keyCode === 10009) ) {
            target.blur();
            e.preventDefault();
            if (!tv) this.back();
            return;
          }
          if (tv && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
            target.blur();
          } else {
            return;
          }
        }

        /* search page: hardware-keyboard typing goes into the query even before the field is focused */
        if (route === "search" && !this.state.modal && !e.ctrlKey && !e.metaKey && !e.altKey) {
          const q = document.getElementById("q");
          const printable = e.key && e.key.length === 1 && e.key !== " " || (e.key === " " && q && q.value);
          if (q && (printable || (e.key === "Backspace" && q.value))) {
            e.preventDefault();
            q.value = printable ? q.value + e.key : q.value.slice(0, -1);
            q.dispatchEvent(new Event("input", { bubbles: true }));
            return;
          }
        }

        if (this.isBackKey(e)) {
          e.preventDefault();
          e.stopPropagation();
          this.back();
          return;
        }

        const Page = this.state.page;
        if (!this.state.modal && Page && typeof Page.onKey === "function") {
          let handled = false;
          try { handled = Page.onKey(e); } catch (err) { console.warn(err); }
          if (handled) { e.preventDefault(); e.stopPropagation(); return; }
        }

        if (tv && window.Nav) {
          const map = { ArrowUp: "up", ArrowDown: "down", ArrowLeft: "left", ArrowRight: "right" };
          const code = { 38: "up", 40: "down", 37: "left", 39: "right" };
          const dir = map[e.key] || code[e.keyCode];
          if (dir) {
            Nav.move(dir);
            e.preventDefault();
            return;
          }
          if (e.key === "Enter" || e.keyCode === 13) {
            if (Nav.enter()) e.preventDefault();
          }
        }
      }, true);
    },

    installErrorHandlers: function () {
      let last = 0;
      window.addEventListener("error", function (e) {
        console.error("MRB error:", e.message, e.filename, e.lineno);
      });
      window.addEventListener("unhandledrejection", (e) => {
        console.error("MRB promise error:", e.reason);
        const now = Date.now();
        if (now - last > 8000 && this.state.activeRoute !== "splash") {
          last = now;
        }
      });
    },

    fitStage: function () {
      const w = window.innerWidth || 1280;
      const h = window.innerHeight || 720;
      const s = Math.min(w / 1280, h / 720);
      const x = Math.round((w - 1280 * s) / 2);
      const y = Math.round((h - 720 * s) / 2);
      if (this.app) this.app.style.transform = "translate(" + x + "px," + y + "px) scale(" + s + ")";
    },

    /* ---------------- overlays ---------------- */
    toast: function (msg, ms) {
      let root = document.getElementById("toasts");
      if (!root) {
        root = document.createElement("div");
        root.id = "toasts";
        root.className = "toasts";
        (this.app || document.body).appendChild(root);
      }
      if (!root.isConnected || root.parentNode !== this.app) (this.app || document.body).appendChild(root);
      const el = document.createElement("div");
      el.className = "toast";
      el.textContent = String(msg || "");
      root.appendChild(el);
      while (root.children.length > 3) root.removeChild(root.firstChild);
      setTimeout(function () {
        el.classList.add("out");
        setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 220);
      }, ms || 2400);
    },

    showLoading: function (msg) {
      let el = document.getElementById("loading");
      if (!el) {
        el = document.createElement("div");
        el.id = "loading";
        el.className = "loading";
        el.innerHTML = '<div class="loading-card"><span class="spinner"></span><span id="loading-text"></span></div>';
      }
      (this.app || document.body).appendChild(el);
      el.classList.remove("hidden");
      document.getElementById("loading-text").textContent = msg || t("loading");
    },

    hideLoading: function () {
      const el = document.getElementById("loading");
      if (el) el.classList.add("hidden");
    },

    /* modal({ title, text, html, buttons:[{label, kind, value}], onMount }) -> Promise(value) */
    modal: function (opts) {
      opts = opts || {};
      this.closeModal(true);
      return new Promise((resolve) => {
        const wrap = document.createElement("div");
        wrap.className = "modal-wrap";
        let html = '<div class="modal" role="dialog" aria-modal="true">';
        if (opts.title) html += '<h2>' + UI.esc(opts.title) + '</h2>';
        if (opts.text) html += '<p>' + UI.esc(opts.text) + '</p>';
        if (opts.html) html += opts.html;
        if (opts.buttons && opts.buttons.length) {
          html += '<div class="btns">';
          opts.buttons.forEach(function (b, i) {
            html += '<button class="btn ' + (b.kind === "primary" ? "btn-primary" : b.kind === "danger" ? "btn-primary" : "btn-ghost") + '" data-f data-i="' + i + '">' + UI.esc(b.label) + '</button>';
          });
          html += '</div>';
        }
        html += '</div>';
        wrap.innerHTML = html;
        (this.app || document.body).appendChild(wrap);

        const done = (value) => {
          if (this.state.modal !== modalState) return;
          this.state.modal = null;
          if (wrap.parentNode) wrap.parentNode.removeChild(wrap);
          if (window.Nav && Platform.isTV) Nav.popScope();
          resolve(value);
        };
        const modalState = { el: wrap, close: function () { done(undefined); } };
        this.state.modal = modalState;

        wrap.addEventListener("click", function (e) {
          if (e.target === wrap) { done(undefined); return; }
          const b = e.target.closest("[data-i]");
          if (b) done(opts.buttons[Number(b.getAttribute("data-i"))].value);
        });
        if (typeof opts.onMount === "function") opts.onMount(wrap.querySelector(".modal"), done);
        if (window.Nav && Platform.isTV) {
          Nav.pushScope(wrap);
          Nav.focusFirst(opts.focus || ".choice.on, [data-i='" + (opts.defaultIndex || 0) + "']");
        }
      });
    },

    closeModal: function (silent) {
      const m = this.state.modal;
      if (!m) return;
      if (silent) {
        this.state.modal = null;
        if (m.el && m.el.parentNode) m.el.parentNode.removeChild(m.el);
        if (window.Nav && Platform.isTV) { Nav.scope = null; Nav.scopeStack = []; }
        return;
      }
      m.close();
    },

    confirm: function (title, text, okLabel) {
      return this.modal({
        title: title,
        text: text,
        buttons: [
          { label: t("cancel"), kind: "ghost", value: false },
          { label: okLabel || t("ok"), kind: "danger", value: true }
        ],
        defaultIndex: 0
      }).then(function (v) { return v === true; });
    },

    choose: function (title, options, current) {
      let html = '<div style="display:flex;flex-direction:column;gap:8px">';
      options.forEach(function (o, i) {
        html += '<button class="choice' + (o.value === current ? " on" : "") + '" data-f data-c="' + i + '">' + UI.esc(o.label) + (o.value === current ? Icon("check", 20) : "") + '</button>';
      });
      html += '</div>';
      return this.modal({
        title: title,
        html: html,
        onMount: function (el, done) {
          el.addEventListener("click", function (e) {
            const b = e.target.closest("[data-c]");
            if (b) done(options[Number(b.getAttribute("data-c"))].value);
          });
        }
      });
    },

    escapeHtml: function (v) {
      return UI.esc(v);
    },

    sleep: function (ms) {
      return new Promise(function (r) { setTimeout(r, ms); });
    }
  };

  window.MRB = MRB;

  function start() {
    MRB.boot();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
