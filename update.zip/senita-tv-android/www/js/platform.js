/* =========================
   Senita TV
   Platform detection (loaded first, in <head>)
   - webOS / Android TV  -> "tv" mode: 1920x1080 layout, remote control
   - Android phone/tablet -> "mobile" mode: responsive layout, touch
   Manual override: localStorage "mrb_ui_mode" = "tv" | "mobile" | "auto"
   ========================= */

(function () {
  "use strict";

  const STORAGE_KEY = "mrb_ui_mode";

  function isAndroidApp() {
    try {
      return !!(
        window.Capacitor &&
        typeof window.Capacitor.getPlatform === "function" &&
        window.Capacitor.getPlatform() === "android"
      );
    } catch (e) {
      return false;
    }
  }

  function readOverride() {
    try {
      const v = localStorage.getItem(STORAGE_KEY);
      return v === "tv" || v === "mobile" ? v : "auto";
    } catch (e) {
      return "auto";
    }
  }

  function writeOverride(v) {
    try {
      if (v === "tv" || v === "mobile") localStorage.setItem(STORAGE_KEY, v);
      else localStorage.removeItem(STORAGE_KEY);
    } catch (e) {}
  }

  function guessMobile() {
    let touch = false;
    try {
      touch = (navigator.maxTouchPoints || 0) > 0 ||
        (window.matchMedia && window.matchMedia("(pointer: coarse)").matches);
    } catch (e) {}
    return touch;
  }

  const android = isAndroidApp();
  const override = readOverride();
  let mobile = false;

  if (android) {
    mobile = override === "mobile" ? true : override === "tv" ? false : guessMobile();
  } else if (override === "mobile") {
    mobile = true;
  }

  const root = document.documentElement;
  root.classList.add(mobile ? "is-mobile" : "is-tv");
  if (android) root.classList.add("platform-android");

  /* Mobile: real device-width viewport instead of the fixed 1920px TV canvas */
  if (mobile) {
    let meta = document.querySelector('meta[name="viewport"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.name = "viewport";
      document.head.appendChild(meta);
    }
    meta.setAttribute("content", "width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover");
  }

  /* Remember the last touch so focus/scroll helpers do not fight finger scrolling */
  let lastTouchAt = 0;
  document.addEventListener("touchstart", function () { lastTouchAt = Date.now(); }, { passive: true, capture: true });
  document.addEventListener("touchmove", function () { lastTouchAt = Date.now(); }, { passive: true, capture: true });

  function getDevicePlugin() {
    return window.Capacitor && window.Capacitor.Plugins ? window.Capacitor.Plugins.MrbDevice : null;
  }

  const Platform = {
    isAndroid: android,
    isMobile: mobile,
    isTV: !mobile,
    override: override,

    recentlyTouched: function (ms) {
      return Date.now() - lastTouchAt < (ms || 700);
    },

    setMode: function (mode) {
      writeOverride(mode);
      try { location.reload(); } catch (e) {}
    },

    /* Player: landscape + hide system bars + keep screen on (native plugin) */
    enterPlayerMode: function () {
      const p = getDevicePlugin();
      if (p && typeof p.enterPlayer === "function") {
        try { p.enterPlayer().catch(function () {}); } catch (e) {}
      }
    },

    exitPlayerMode: function () {
      const p = getDevicePlugin();
      if (p && typeof p.exitPlayer === "function") {
        try { p.exitPlayer().catch(function () {}); } catch (e) {}
      }
    }
  };

  window.Platform = Platform;

  /* Ask the native side whether this really is a TV; fix a wrong guess once */
  if (android && override === "auto") {
    const p = getDevicePlugin();
    if (p && typeof p.getInfo === "function") {
      try {
        p.getInfo().then(function (info) {
          if (!info) return;
          const nativeMobile = !info.isTv;
          if (nativeMobile !== mobile) {
            writeOverride(nativeMobile ? "mobile" : "tv");
            location.reload();
          }
        }).catch(function () {});
      } catch (e) {}
    }
  }
})();
