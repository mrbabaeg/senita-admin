/* Senita TV — shared UI helpers (pure functions, no state) */
(function () {
  "use strict";

  const PALETTE = ["#2A3240", "#3A2C2C", "#2C3A33", "#35304A", "#3D3526", "#263A40", "#3A2A38", "#2E3442"];

  const UI = {
    esc: function (v) {
      return String(v === undefined || v === null ? "" : v)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
    },

    isTV: function () {
      return !!(window.Platform && Platform.isTV);
    },

    hash: function (s) {
      s = String(s || "");
      let h = 0;
      for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
      return Math.abs(h);
    },

    color: function (s) {
      return PALETTE[UI.hash(s) % PALETTE.length];
    },

    initials: function (name) {
      const clean = String(name || "?").replace(/\b(HD|FHD|UHD|4K|SD|TV)\b/gi, "").replace(/[^0-9A-Za-zÀ-ɏЀ-ӿ\s]/g, " ").trim();
      const words = clean.split(/\s+/).filter(Boolean);
      if (!words.length) return "TV";
      if (words.length === 1) return words[0].slice(0, 3).toUpperCase();
      return (words[0][0] + words[1][0] + (words[2] ? words[2][0] : "")).toUpperCase();
    },

    /* Category names like "1. News/Новости" -> "News/Новости" */
    catName: function (name) {
      if (!name || name === "All") return window.t ? t("all") : "All";
      if (name === "Other") return window.t ? t("other") : "Other";
      return String(name).replace(/^\s*\d+\s*[.)\-:]\s*/, "");
    },

    logo: function (ch, cls) {
      ch = ch || {};
      const src = ch.logo || ch.tvgLogo || "";
      const ini = UI.esc(UI.initials(ch.name));
      if (!src) return '<span class="logo ' + (cls || "") + '">' + ini + '</span>';
      return '<span class="logo ' + (cls || "") + '"><img loading="lazy" decoding="async" alt="" src="' + UI.esc(src) + '" onerror="this.parentNode.textContent=\'' + ini + '\'"></span>';
    },

    posterSrc: function (item) {
      item = item || {};
      return item.poster || item.cover || item.logo || item.tvgLogo || "";
    },

    poster: function (item, extraHtml) {
      const src = UI.posterSrc(item);
      const title = UI.esc(item.name || item.title || "");
      return '<div class="poster" style="background:' + UI.color(item.name) + '"><span class="ptitle">' + title + '</span>' +
        (src ? '<img loading="lazy" decoding="async" alt="" src="' + UI.esc(src) + '" onerror="this.remove()">' : '') +
        (extraHtml || "") + '</div>';
    },

    pad: function (n) {
      return String(n).padStart(2, "0");
    },

    clock: function (d) {
      d = d instanceof Date ? d : new Date(d);
      return UI.pad(d.getHours()) + ":" + UI.pad(d.getMinutes());
    },

    duration: function (sec) {
      sec = Math.max(0, Math.floor(Number(sec) || 0));
      const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
      return (h ? h + ":" + UI.pad(m) : String(m)) + ":" + UI.pad(s);
    },

    /* EPG for a channel: { has, title, start, end, progress, next:[{start,title}] } */
    epg: function (ch, nextCount) {
      const out = { has: false, title: "", start: null, end: null, progress: 0, next: [] };
      if (!ch || !window.EPGEngine || !EPGEngine.getPrograms) return out;
      try {
        const list = EPGEngine.getPrograms(ch) || [];
        if (!list.length) return out;
        const now = Date.now();
        let idx = -1;
        for (let i = 0; i < list.length; i++) {
          const s = new Date(list[i].start).getTime();
          const e = new Date(list[i].end).getTime();
          if (now >= s && now < e) { idx = i; break; }
          if (s > now) { idx = i - 1; break; }
        }
        if (idx >= 0) {
          const p = list[idx];
          const s = new Date(p.start).getTime(), e = new Date(p.end).getTime();
          if (now >= s && now < e) {
            out.has = true;
            out.title = p.title || "";
            out.start = new Date(s);
            out.end = new Date(e);
            out.progress = Math.max(0, Math.min(100, Math.round((now - s) * 100 / (e - s))));
          }
        }
        const from = idx + 1;
        for (let j = Math.max(0, from); j < list.length && out.next.length < (nextCount || 1); j++) {
          if (new Date(list[j].start).getTime() >= now - 1000) out.next.push({ start: new Date(list[j].start), title: list[j].title || "" });
        }
      } catch (e) {}
      return out;
    },

    nowLine: function (ch) {
      const e = UI.epg(ch);
      return e.has ? UI.clock(e.start) + " · " + e.title : "";
    },

    highlight: function (text, q) {
      const s = String(text || "");
      const query = String(q || "").trim();
      if (!query) return UI.esc(s);
      const i = s.toLowerCase().indexOf(query.toLowerCase());
      if (i < 0) return UI.esc(s);
      return UI.esc(s.slice(0, i)) + "<b>" + UI.esc(s.slice(i, i + query.length)) + "</b>" + UI.esc(s.slice(i + query.length));
    },

    /* VOD resume positions */
    progressKey: "mrb_vod_progress",

    getProgressAll: function () {
      try { return JSON.parse(localStorage.getItem(UI.progressKey) || "{}") || {}; } catch (e) { return {}; }
    },

    getProgress: function (item) {
      if (!item) return null;
      const all = UI.getProgressAll();
      return all[item.url || item.id] || null;
    },

    saveProgress: function (item, pos, dur) {
      if (!item || !(item.url || item.id) || !isFinite(dur) || dur < 60) return;
      const all = UI.getProgressAll();
      const key = item.url || item.id;
      if (pos < 15 || pos > dur - 30) {
        delete all[key];
      } else {
        all[key] = {
          pos: Math.floor(pos), dur: Math.floor(dur), at: Date.now(),
          item: { id: item.id, name: item.name || item.title, url: item.url, poster: UI.posterSrc(item), type: item.type, group: item.group, year: item.year, rating: item.rating, plot: item.plot, seriesId: item.seriesId, playlistId: item.playlistId }
        };
      }
      const keys = Object.keys(all).sort(function (a, b) { return all[b].at - all[a].at; });
      const trimmed = {};
      keys.slice(0, 30).forEach(function (k) { trimmed[k] = all[k]; });
      try { localStorage.setItem(UI.progressKey, JSON.stringify(trimmed)); } catch (e) {}
    },

    continueList: function (type) {
      const all = UI.getProgressAll();
      return Object.keys(all).map(function (k) { return all[k]; })
        .filter(function (p) { return p && p.item && (!type || p.item.type === type || (type === "series" && p.item.type === "episode")); })
        .sort(function (a, b) { return b.at - a.at; });
    }
  };

  window.UI = UI;
})();
