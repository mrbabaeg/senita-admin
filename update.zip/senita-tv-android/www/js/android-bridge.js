/* =========================
   Senita TV
   Android (Capacitor) bridge
   - Remote BACK button -> same key event the app already handles (Escape / 461)
   - Exit app from the dashboard
   - Loaded before the app scripts; does nothing on webOS
   ========================= */

(function () {
  "use strict";

  function isAndroidApp() {
    try {
      return !!(
        window.Capacitor &&
        typeof window.Capacitor.getPlatform === "function" &&
        window.Capacitor.getPlatform() === "android"
      );
    } catch (e) {
      return false;
    }
  }

  function getAppPlugin() {
    return window.Capacitor && window.Capacitor.Plugins ? window.Capacitor.Plugins.App : null;
  }

  function dispatchBackKey() {
    const init = {
      key: "Escape",
      code: "Escape",
      bubbles: true,
      cancelable: true
    };

    const event = new KeyboardEvent("keydown", init);

    try {
      Object.defineProperty(event, "keyCode", { get: function () { return 461; } });
      Object.defineProperty(event, "which", { get: function () { return 461; } });
    } catch (e) {}

    const target = document.activeElement && document.activeElement !== document.body
      ? document.activeElement
      : document;

    target.dispatchEvent(event);

    const up = new KeyboardEvent("keyup", init);
    try {
      Object.defineProperty(up, "keyCode", { get: function () { return 461; } });
    } catch (e) {}
    target.dispatchEvent(up);
  }

  const AndroidBridge = {
    isAndroid: isAndroidApp(),

    exitApp: function () {
      const App = getAppPlugin();
      if (App && typeof App.exitApp === "function") {
        App.exitApp();
        return true;
      }
      return false;
    },

    init: function () {
      if (!this.isAndroid) return;

      document.documentElement.classList.add("platform-android");

      const App = getAppPlugin();
      if (App && typeof App.addListener === "function") {
        /* Registering this listener disables the default "close app" behaviour */
        App.addListener("backButton", function () {
          dispatchBackKey();
        });
      }
    }
  };

  window.AndroidBridge = AndroidBridge;
  AndroidBridge.init();
})();
