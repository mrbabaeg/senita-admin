/* =========================
   Senita TV
   Global Config
   ========================= */

(function () {
  "use strict";

  window.APP_CONFIG = {
    appName: "Senita TV",
    appId: "az.senita.tv",
    version: "1.2.2",

    /* Abunəlik (cihaz lisenziyası) serveri — Supabase.
       url:     Supabase → Connect (və ya Settings → API Keys) → Project URL   (məs. "https://abcd1234.supabase.co")
       anonKey: Publishable key (sb_publishable_...) — və ya köhnə "anon public" açarı (eyJ...)
       İkisi də boş qalsa lisenziya sistemi SÖNÜLÜDÜR və tətbiq blok olmadan işləyir. */
    license: {
      url: "https://majotjbdnomsrnlamnmf.supabase.co",
      anonKey: "sb_publishable_W1H_TRmMbwa4UkeaHyjSSg_Z9hyYZ8y"
    },

    theme: {
      background: "#0B0F19",
      panel: "#171F2F",
      card: "#1D2638",
      purple: "#8B5CF6",
      cyan: "#06B6D4",
      text: "#FFFFFF",
      muted: "#A8B0C2"
    },

    routes: {
      dashboard: "dashboard",
      playlists: "playlists",
      live: "live",
      movies: "movies",
      series: "series",
      player: "player",
      vodDetail: "vodDetail",
      favorites: "favorites",
      settings: "settings"
    },

    layout: {
      dashboardColumns: 4,
      posterColumns: 6,
      liveRowHeight: 92,
      categoryRowHeight: 64,
      posterRowHeight: 330,
      virtualOverscan: 8
    },

    player: {
      defaultAspect: "contain",
      aspects: [
        {
          id: "contain",
          label: "Original"
        },
        {
          id: "cover",
          label: "Zoom"
        },
        {
          id: "fill",
          label: "Stretch"
        }
      ],
      overlayTimeout: 7000
    },

    images: {
      channelFallback: "",
      posterFallback: "",
      logoFallback: ""
    },

    keys: {
      ENTER: 13,
      LEFT: 37,
      UP: 38,
      RIGHT: 39,
      DOWN: 40,
      BACK_WEBOS: 461,
      BACK_TIZEN: 10009,
      ZERO: 48,
      SPACE: 32
    },

    limits: {
      maxFavorites: 1000,
      maxRenderedItems: 120,
      maxPlaylistName: 64
    },

    demo: {
      enabled: true,
      playlistName: "Demo Playlist"
    },

    debug: false
  };

  window.logDebug = function () {
    if (!window.APP_CONFIG || !APP_CONFIG.debug) return;
    try {
      console.log.apply(console, arguments);
    } catch (e) {}
  };
})();
