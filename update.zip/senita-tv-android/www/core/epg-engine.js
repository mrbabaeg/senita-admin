/* =========================
   Senita TV
   EPG Engine Core
   XMLTV Now / Next support
   ========================= */

(function () {
  "use strict";

  function pad(n) { return String(n).padStart(2, "0"); }
  function formatClock(date) { return pad(date.getHours()) + ":" + pad(date.getMinutes()); }
  function addMinutes(date, minutes) { return new Date(date.getTime() + minutes * 60000); }

  function fallbackProgram(channel) {
    const now = new Date();
    const slotLength = 60;
    const slotStartMinutes = Math.floor((now.getHours() * 60 + now.getMinutes()) / slotLength) * slotLength;
    const start = new Date(now);
    start.setHours(Math.floor(slotStartMinutes / 60), slotStartMinutes % 60, 0, 0);
    const end = addMinutes(start, slotLength);

    const progress = Math.max(
      0,
      Math.min(100, Math.round(((now.getTime() - start.getTime()) / (end.getTime() - start.getTime())) * 100))
    );

    const channelName = channel && channel.name ? channel.name : "Channel";

    return {
      title: "Live: " + channelName,
      description: "No EPG data available",
      start: start,
      end: end,
      startText: formatClock(start),
      endText: formatClock(end),
      progress: progress,
      nextTitle: "Next program",
      nextStartText: formatClock(end),
      nextEndText: formatClock(addMinutes(end, slotLength)),
      source: "fallback"
    };
  }

  const EPGEngine = {
    programs: {},

    setPrograms(data) {
      this.programs = data && typeof data === "object" ? data : {};
    },

    clear() {
      this.programs = {};
    },

    getChannelKey(channel) {
      if (!channel) return "";
      const candidates = [channel.tvgId, channel.tvgName, channel.name].filter(Boolean);
      for (let i = 0; i < candidates.length; i++) {
        const key = String(candidates[i]).toLowerCase().trim();
        if (this.programs[key]) return key;
      }
      return "";
    },

    getPrograms(channel) {
      const key = this.getChannelKey(channel);
      return key ? this.programs[key] : [];
    },

    getNowNext(channel) {
      const list = this.getPrograms(channel);

      if (!list || !list.length) return fallbackProgram(channel);

      const now = new Date();
      let current = null;
      let next = null;

      for (let i = 0; i < list.length; i++) {
        const p = list[i];
        const start = new Date(p.start);
        const end = new Date(p.end);

        if (now >= start && now < end) {
          current = Object.assign({}, p, { start: start, end: end });
          next = list[i + 1] || null;
          break;
        }
      }

      if (!current) {
        for (let i = 0; i < list.length; i++) {
          const p = list[i];
          const start = new Date(p.start);

          if (start > now) {
            next = p;
            break;
          }
        }

        if (!next) return fallbackProgram(channel);

        const ns = new Date(next.start);
        const ne = new Date(next.end);

        return {
          title: "No current programme",
          description: "",
          start: now,
          end: ns,
          startText: formatClock(now),
          endText: formatClock(ns),
          progress: 0,
          nextTitle: next.title || "Next program",
          nextStartText: formatClock(ns),
          nextEndText: formatClock(ne),
          source: "xmltv"
        };
      }

      const progress = Math.max(
        0,
        Math.min(100, Math.round(((now.getTime() - current.start.getTime()) / (current.end.getTime() - current.start.getTime())) * 100))
      );

      return {
        title: current.title || "Current program",
        description: current.description || "",
        start: current.start,
        end: current.end,
        startText: formatClock(current.start),
        endText: formatClock(current.end),
        progress: progress,
        nextTitle: next ? (next.title || "Next program") : "Next program",
        nextStartText: next ? formatClock(new Date(next.start)) : formatClock(current.end),
        nextEndText: next ? formatClock(new Date(next.end)) : formatClock(addMinutes(current.end, 60)),
        source: "xmltv"
      };
    },

    getProgress(channel) {
      return this.getNowNext(channel).progress;
    }
  };

  window.EPGEngine = EPGEngine;
})();
