/* =========================
   Senita TV
   Storage Core
   ========================= */

(function () {
  "use strict";

  const PREFIX = "mrbabayev_player_";

  const KEYS = {
    PLAYLISTS: PREFIX + "playlists",
    ACTIVE_PLAYLIST_ID: PREFIX + "active_playlist_id",
    CHANNELS_CACHE: PREFIX + "channels_cache",
    VOD_CACHE: PREFIX + "vod_cache",
    FAVORITES: PREFIX + "favorites",
    SETTINGS: PREFIX + "settings",
    LAST_CHANNEL: PREFIX + "last_channel"
  };

  const DEFAULT_SETTINGS = {
    appLanguage: "en",
    startPage: "dashboard",
    playerAspect: "contain",
    autoplayLastChannel: false,
    showClock: true,
    animations: true,
    epgEnabled: true,
    parentalLock: false
  };

  function uid(prefix) {
    return (prefix || "id") + "_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 8);
  }

  function safeParse(value, fallback) {
    if (!value) return fallback;
    try {
      return JSON.parse(value);
    } catch (e) {
      return fallback;
    }
  }

  /* In-memory cache: avoids re-parsing big JSON (channel lists) on every page,
     and keeps data for this session even if localStorage is full. */
  const memo = {};

  function clone(value) {
    return value === undefined ? value : JSON.parse(JSON.stringify(value));
  }

  function read(key, fallback) {
    if (Object.prototype.hasOwnProperty.call(memo, key)) {
      const v = memo[key];
      return v === null || v === undefined ? fallback : clone(v);
    }
    try {
      const raw = localStorage.getItem(key);
      const parsed = safeParse(raw, null);
      memo[key] = parsed;
      return parsed === null ? fallback : clone(parsed);
    } catch (e) {
      return fallback;
    }
  }

  /* Read without copying (large caches; callers must not mutate the result) */
  function readRef(key, fallback) {
    if (!Object.prototype.hasOwnProperty.call(memo, key)) {
      try { memo[key] = safeParse(localStorage.getItem(key), null); } catch (e) { memo[key] = null; }
    }
    const v = memo[key];
    return v === null || v === undefined ? fallback : v;
  }

  function write(key, value) {
    memo[key] = clone(value);
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.error("Storage write failed:", key, e);
      return false;
    }
  }

  function remove(key) {
    delete memo[key];
    try {
      localStorage.removeItem(key);
      return true;
    } catch (e) {
      return false;
    }
  }

  function normalizePlaylist(input) {
    const now = new Date().toISOString();

    /* keep extra fields (xmltvUrl, expiryDate, counts…) — they used to be dropped */
    return Object.assign({}, input, {
      id: input.id || uid("playlist"),
      name: String(input.name || "My Playlist").trim(),
      type: input.type || "m3u",
      url: String(input.url || "").trim(),
      username: input.username || "",
      password: input.password || "",
      server: input.server || "",
      createdAt: input.createdAt || now,
      updatedAt: now,
      lastRefreshAt: input.lastRefreshAt || "",
      itemCount: Number(input.itemCount || 0)
    });
  }

  const StorageCore = {
    keys: KEYS,

    uid: uid,

    read: read,

    write: write,

    remove: remove,

    getPlaylists: function () {
      const list = read(KEYS.PLAYLISTS, []);
      return Array.isArray(list) ? list : [];
    },

    savePlaylists: function (playlists) {
      return write(KEYS.PLAYLISTS, Array.isArray(playlists) ? playlists : []);
    },

    addPlaylist: function (playlist) {
      const list = this.getPlaylists();
      const normalized = normalizePlaylist(playlist || {});

      list.push(normalized);
      this.savePlaylists(list);

      if (!this.getActivePlaylistId()) {
        this.setActivePlaylistId(normalized.id);
      }

      return normalized;
    },

    updatePlaylist: function (id, patch) {
      const list = this.getPlaylists();
      let updated = null;

      const next = list.map(function (item) {
        if (item.id !== id) return item;
        updated = normalizePlaylist(Object.assign({}, item, patch || {}, { id: id }));
        return updated;
      });

      this.savePlaylists(next);
      return updated;
    },

    deletePlaylist: function (id) {
      const list = this.getPlaylists().filter(function (item) {
        return item.id !== id;
      });

      this.savePlaylists(list);

      if (this.getActivePlaylistId() === id) {
        this.setActivePlaylistId(list[0] ? list[0].id : "");
      }

      this.removeChannelsCache(id);
      this.removeVodCache(id);

      return true;
    },

    getPlaylistById: function (id) {
      return this.getPlaylists().find(function (item) {
        return item.id === id;
      }) || null;
    },

    getActivePlaylistId: function () {
      try {
        return localStorage.getItem(KEYS.ACTIVE_PLAYLIST_ID) || "";
      } catch (e) {
        return "";
      }
    },

    setActivePlaylistId: function (id) {
      try {
        localStorage.setItem(KEYS.ACTIVE_PLAYLIST_ID, id || "");
        return true;
      } catch (e) {
        return false;
      }
    },

    getActivePlaylist: function () {
      return this.getPlaylistById(this.getActivePlaylistId());
    },

    getChannelsCache: function (playlistId) {
      const all = readRef(KEYS.CHANNELS_CACHE, {});
      return all && all[playlistId] && Array.isArray(all[playlistId].items)
        ? all[playlistId]
        : {
            items: [],
            updatedAt: ""
          };
    },

    setChannelsCache: function (playlistId, channels) {
      const all = read(KEYS.CHANNELS_CACHE, {});
      all[playlistId] = {
        items: Array.isArray(channels) ? channels : [],
        updatedAt: new Date().toISOString()
      };
      return write(KEYS.CHANNELS_CACHE, all);
    },

    removeChannelsCache: function (playlistId) {
      const all = read(KEYS.CHANNELS_CACHE, {});
      if (all && all[playlistId]) {
        delete all[playlistId];
        write(KEYS.CHANNELS_CACHE, all);
      }
    },

    getVodCache: function (playlistId) {
      const all = readRef(KEYS.VOD_CACHE, {});
      return all && all[playlistId]
        ? all[playlistId]
        : {
            movies: [],
            series: [],
            updatedAt: ""
          };
    },

    setVodCache: function (playlistId, vodData) {
      const all = read(KEYS.VOD_CACHE, {});
      all[playlistId] = {
        movies: Array.isArray(vodData && vodData.movies) ? vodData.movies : [],
        series: Array.isArray(vodData && vodData.series) ? vodData.series : [],
        updatedAt: new Date().toISOString()
      };
      return write(KEYS.VOD_CACHE, all);
    },

    removeVodCache: function (playlistId) {
      const all = read(KEYS.VOD_CACHE, {});
      if (all && all[playlistId]) {
        delete all[playlistId];
        write(KEYS.VOD_CACHE, all);
      }
    },

    getFavorites: function () {
      const fav = read(KEYS.FAVORITES, []);
      return Array.isArray(fav) ? fav : [];
    },

    saveFavorites: function (items) {
      return write(KEYS.FAVORITES, Array.isArray(items) ? items : []);
    },

    makeFavoriteId: function (item) {
      return [
        item.type || "unknown",
        item.playlistId || "",
        item.url || item.streamUrl || item.id || item.name || ""
      ].join("|");
    },

    isFavorite: function (item) {
      const id = this.makeFavoriteId(item || {});
      return this.getFavorites().some(function (fav) {
        return fav.favoriteId === id;
      });
    },

    toggleFavorite: function (item) {
      if (!item) return false;

      const id = this.makeFavoriteId(item);
      const favorites = this.getFavorites();
      const exists = favorites.some(function (fav) {
        return fav.favoriteId === id;
      });

      if (exists) {
        this.saveFavorites(
          favorites.filter(function (fav) {
            return fav.favoriteId !== id;
          })
        );
        return false;
      }

      const favItem = Object.assign({}, item, {
        favoriteId: id,
        addedAt: new Date().toISOString()
      });

      favorites.unshift(favItem);
      this.saveFavorites(favorites.slice(0, 1000));
      return true;
    },

    removeFavorite: function (favoriteId) {
      this.saveFavorites(
        this.getFavorites().filter(function (fav) {
          return fav.favoriteId !== favoriteId;
        })
      );
    },

    getSettings: function () {
      return Object.assign({}, DEFAULT_SETTINGS, read(KEYS.SETTINGS, {}));
    },

    setSettings: function (settings) {
      const merged = Object.assign({}, DEFAULT_SETTINGS, this.getSettings(), settings || {});
      return write(KEYS.SETTINGS, merged);
    },

    setSetting: function (name, value) {
      const settings = this.getSettings();
      settings[name] = value;
      return this.setSettings(settings);
    },

    resetSettings: function () {
      return write(KEYS.SETTINGS, DEFAULT_SETTINGS);
    },

    getLastChannel: function () {
      return read(KEYS.LAST_CHANNEL, null);
    },

    setLastChannel: function (channel) {
      return write(KEYS.LAST_CHANNEL, channel || null);
    },

    clearAll: function () {
      Object.keys(KEYS).forEach(function (key) {
        remove(KEYS[key]);
      });
      return true;
    }
  };

  window.StorageCore = StorageCore;
})();
