
(function () {
  "use strict";

  function isValidUrl(value) {
    try {
      const url = new URL(String(value || "").trim());
      return url.protocol === "http:" || url.protocol === "https:";
    } catch (e) {
      return false;
    }
  }

  function demoM3U() {
    return [
      '#EXTM3U url-tvg=""',
      '#EXTINF:-1 tvg-id="aztv.az" tvg-name="AZ TV" tvg-logo="" group-title="Azerbaijan",AZ TV',
      "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
    ].join("\n");
  }

  function extractXmltvUrl(m3uText) {
    const firstLine = String(m3uText || "").split(/\r?\n/)[0] || "";
    const patterns = [/url-tvg="([^"]+)"/i, /x-tvg-url="([^"]+)"/i, /tvg-url="([^"]+)"/i];
    for (let i = 0; i < patterns.length; i++) {
      const m = firstLine.match(patterns[i]);
      if (m && m[1]) return m[1].trim();
    }
    return "";
  }

  async function fetchM3UText(playlist) {
    if (playlist.type === "demo") return demoM3U();
    if (!isValidUrl(playlist.url)) throw new Error("Playlist URL is invalid");
    if (window.ApiService && ApiService.fetchM3U) return await ApiService.fetchM3U(playlist.url);
    const response = await fetch(playlist.url, { method: "GET", cache: "no-store" });
    if (!response.ok) throw new Error("Playlist request failed: HTTP " + response.status);
    return await response.text();
  }

  /* EPG is loaded in the background (Web Worker); it never blocks the playlist */
  function scheduleXmltv(playlist, m3uText, force) {
    const xmltvUrl = playlist.xmltvUrl || extractXmltvUrl(m3uText);
    if (!xmltvUrl || !isValidUrl(xmltvUrl)) return { ok: false, reason: "No XMLTV URL" };
    if (!window.XMLTVService || !XMLTVService.refreshInBackground) return { ok: false, reason: "XMLTVService not loaded" };
    setTimeout(function () {
      XMLTVService.refreshInBackground(xmltvUrl, null, !!force).then(function (result) {
        if (result && window.StorageCore && StorageCore.updatePlaylist) {
          StorageCore.updatePlaylist(playlist.id, {
            xmltvLastRefreshAt: new Date().toISOString(),
            xmltvChannelCount: result.channelCount,
            xmltvProgramCount: result.programCount,
            xmltvStatus: "loaded"
          });
        }
      });
    }, 1500);
    return { ok: true, url: xmltvUrl, reason: "scheduled" };
  }

  async function tryLoadXmltv(playlist, m3uText) {
    let xmltvUrl = playlist.xmltvUrl || extractXmltvUrl(m3uText);
    if (!xmltvUrl || !isValidUrl(xmltvUrl)) return { ok: false, reason: "No XMLTV URL" };
    if (!window.XMLTVService || !XMLTVService.loadFromUrl) return { ok: false, reason: "XMLTVService not loaded" };
    const result = await XMLTVService.loadFromUrl(xmltvUrl, null);
    if (window.StorageCore && StorageCore.updatePlaylist) {
      StorageCore.updatePlaylist(playlist.id, {
        xmltvUrl: xmltvUrl,
        xmltvLastRefreshAt: new Date().toISOString(),
        xmltvChannelCount: result.channelCount,
        xmltvProgramCount: result.programCount
      });
    }
    return { ok: true, url: xmltvUrl, result: result };
  }

  const PlaylistManager = {
    addM3UUrl: function (url, name) {
      if (!window.StorageCore) throw new Error("StorageCore is not loaded");
      const finalUrl = String(url || "").trim();
      if (!isValidUrl(finalUrl)) throw new Error("Invalid M3U URL");
      return StorageCore.addPlaylist({ type: "m3u", name: String(name || "M3U Playlist").trim(), url: finalUrl });
    },

    addDemoPlaylist: function () {
      if (!window.StorageCore || !window.M3UParser) throw new Error("Required modules are not loaded");
      const playlist = StorageCore.addPlaylist({ type: "demo", name: "Demo Playlist", url: "demo://playlist" });
      const text = demoM3U();
      const parsed = M3UParser.parse(text, { playlistId: playlist.id, sourceName: playlist.name });
      StorageCore.setChannelsCache(playlist.id, parsed.live);
      StorageCore.setVodCache(playlist.id, { movies: parsed.movies, series: parsed.series });
      StorageCore.updatePlaylist(playlist.id, { itemCount: parsed.meta.total, lastRefreshAt: new Date().toISOString(), xmltvUrl: extractXmltvUrl(text) });
      StorageCore.setActivePlaylistId(playlist.id);
      return { playlist: playlist, parsed: parsed };
    },

    refreshPlaylist: async function (playlistId) {
      if (!window.StorageCore) throw new Error("StorageCore is not loaded");
      const id = playlistId || StorageCore.getActivePlaylistId();
      const playlist = StorageCore.getPlaylistById(id);
      if (!playlist) throw new Error("No active playlist selected");

      if (playlist.type === "xtream") {
        if (!window.XtreamService) throw new Error("XtreamService is not loaded");
        const data = await XtreamService.loadAll(playlist);

        StorageCore.setChannelsCache(playlist.id, data.live);
        StorageCore.setVodCache(playlist.id, { movies: data.movies, series: data.series });

        StorageCore.updatePlaylist(playlist.id, {
          itemCount: data.meta.total,
          liveCount: data.meta.live,
          movieCount: data.meta.movies,
          seriesCount: data.meta.series,
          lastRefreshAt: new Date().toISOString(),
          xtreamStatus: "loaded"
        });

        StorageCore.setActivePlaylistId(playlist.id);

        if (window.SearchEngine && SearchEngine.buildFromPlaylist) {
          try { SearchEngine.buildFromPlaylist(); } catch(e) {}
        }

        return {
          playlist: StorageCore.getPlaylistById(playlist.id),
          parsed: {
            live: data.live,
            movies: data.movies,
            series: data.series,
            meta: data.meta
          },
          xmltv: { ok: false, reason: "Xtream API mode" },
          xtream: data
        };
      }

      if (!window.M3UParser) throw new Error("M3UParser is not loaded");
      const text = await fetchM3UText(playlist);
      const parsed = M3UParser.parse(text, { playlistId: playlist.id, sourceName: playlist.name });

      StorageCore.setChannelsCache(playlist.id, parsed.live);
      StorageCore.setVodCache(playlist.id, { movies: parsed.movies, series: parsed.series });

      let xmltv = { ok: false, reason: "Not loaded" };
      try { xmltv = scheduleXmltv(playlist, text, false); }
      catch (err) { xmltv = { ok: false, reason: err.message || "XMLTV load failed" }; }

      StorageCore.updatePlaylist(playlist.id, {
        itemCount: parsed.meta.total,
        lastRefreshAt: new Date().toISOString(),
        xmltvUrl: playlist.xmltvUrl || extractXmltvUrl(text),
        xmltvStatus: xmltv.ok ? "loading" : xmltv.reason
      });

      StorageCore.setActivePlaylistId(playlist.id);

      if (window.SearchEngine && SearchEngine.buildFromPlaylist) {
        try { SearchEngine.buildFromPlaylist(); } catch(e) {}
      }

      return { playlist: StorageCore.getPlaylistById(playlist.id), parsed: parsed, xmltv: xmltv };
    },

    /* Called at startup: refresh EPG in the background if the cache is old */
    ensureEpg: function () {
      if (!window.StorageCore) return;
      const p = StorageCore.getActivePlaylist ? StorageCore.getActivePlaylist() : null;
      if (!p || !p.xmltvUrl || p.type === "xtream") return;
      scheduleXmltv(p, "", false);
    },

    refreshXmltvOnly: async function (playlistId) {
      if (!window.StorageCore) throw new Error("StorageCore is not loaded");
      const id = playlistId || StorageCore.getActivePlaylistId();
      const playlist = StorageCore.getPlaylistById(id);
      if (!playlist) throw new Error("No active playlist selected");
      if (!playlist.xmltvUrl) throw new Error("Playlist has no XMLTV URL");
      return await tryLoadXmltv(playlist, "");
    },

    getActiveLiveChannels: function () {
      if (!window.StorageCore) return [];
      const id = StorageCore.getActivePlaylistId();
      if (!id) return [];
      return StorageCore.getChannelsCache(id).items || [];
    },

    getActiveVod: function () {
      if (!window.StorageCore) return { movies: [], series: [] };
      const id = StorageCore.getActivePlaylistId();
      if (!id) return { movies: [], series: [] };
      const cache = StorageCore.getVodCache(id);
      return { movies: cache.movies || [], series: cache.series || [] };
    },

    getCategories: function (type) {
      const live = this.getActiveLiveChannels();
      const vod = this.getActiveVod();
      if (type === "movie") return window.M3UParser ? M3UParser.buildCategories(vod.movies || []) : [];
      if (type === "series") return window.M3UParser ? M3UParser.buildCategories(vod.series || []) : [];
      return window.M3UParser ? M3UParser.buildCategories(live || []) : [];
    },

    getItemsByCategory: function (type, categoryName) {
      const live = this.getActiveLiveChannels();
      const vod = this.getActiveVod();
      if (!window.M3UParser) return [];
      if (type === "movie") return M3UParser.filterByCategory(vod.movies || [], categoryName);
      if (type === "series") return M3UParser.filterByCategory(vod.series || [], categoryName);
      return M3UParser.filterByCategory(live || [], categoryName);
    },

    search: function (type, query) {
      if (!window.M3UParser) return [];
      const live = this.getActiveLiveChannels();
      const vod = this.getActiveVod();
      if (type === "movie") return M3UParser.search(vod.movies || [], query);
      if (type === "series") return M3UParser.search(vod.series || [], query);
      return M3UParser.search(live || [], query);
    },

    setActive: function (playlistId) {
      if (!window.StorageCore) return false;
      const p = StorageCore.getPlaylistById(playlistId);
      if (!p) return false;
      StorageCore.setActivePlaylistId(playlistId);
      return true;
    },

    deletePlaylist: function (playlistId) {
      if (!window.StorageCore) return false;
      return StorageCore.deletePlaylist(playlistId);
    },

    getPlaylists: function () { return window.StorageCore ? StorageCore.getPlaylists() : []; },
    getActivePlaylist: function () { return window.StorageCore ? StorageCore.getActivePlaylist() : null; },

    hasActivePlaylistData: function () {
      const items = this.getActiveLiveChannels();
      const vod = this.getActiveVod();
      return items.length > 0 || (vod.movies && vod.movies.length > 0) || (vod.series && vod.series.length > 0);
    }
  };

  window.PlaylistManager = PlaylistManager;
})();
