/* =========================
   Senita TV
   M3U Parser
   FIX v2: group-title + #EXTGRP support
   Supports hls.gd style playlists
   ========================= */

(function () {
  "use strict";

  function clean(value) {
    return String(value || "")
      .replace(/^\uFEFF/, "")
      .trim();
  }

  function normalizeGroup(group) {
    group = clean(group);

    if (!group) return "Other";

    /*
     * Keep provider numbering because many IPTV apps show it this way:
     * "1. News/Новости", "2. Sports/Спорт" etc.
     */
    group = group
      .replace(/^[|>\-:\s]+/, "")
      .replace(/[|>\-:\s]+$/, "")
      .trim();

    return group || "Other";
  }

  function parseAttributes(line) {
    const attrs = {};
    const text = String(line || "");
    const re = /([A-Za-z0-9_-]+)\s*=\s*("([^"]*)"|'([^']*)'|([^\s,]+))/g;
    let match;

    while ((match = re.exec(text)) !== null) {
      const key = String(match[1] || "").toLowerCase();
      const value = match[3] !== undefined
        ? match[3]
        : (match[4] !== undefined ? match[4] : match[5]);

      attrs[key] = clean(value);
    }

    return attrs;
  }

  function parseTitle(line) {
    const idx = String(line || "").lastIndexOf(",");
    if (idx >= 0) return clean(String(line).slice(idx + 1));
    return "";
  }

  function getHeaderMeta(text) {
    const first = String(text || "").split(/\r?\n/)[0] || "";
    const attrs = parseAttributes(first);

    return {
      urlTvg: attrs["url-tvg"] || attrs["x-tvg-url"] || attrs["tvg-url"] || "",
      generationDate: attrs["generation-date"] || "",
      name: attrs["name"] || ""
    };
  }

  function detectType(item) {
    const group = String(item.group || "").toLowerCase();
    const name = String(item.name || "").toLowerCase();
    const url = String(item.url || "").toLowerCase();

    if (
      group.indexOf("series") >= 0 ||
      group.indexOf("serial") >= 0 ||
      group.indexOf("dizi") >= 0 ||
      /s\d{1,2}e\d{1,2}/i.test(name) ||
      url.indexOf("/series/") >= 0
    ) {
      return "series";
    }

    if (
      group.indexOf("movie") >= 0 ||
      group.indexOf("film") >= 0 ||
      group.indexOf("vod") >= 0 ||
      url.indexOf("/movie/") >= 0
    ) {
      return "movie";
    }

    return "live";
  }

  function makeId(prefix, index, item) {
    const raw = [
      item.tvgId,
      item.tvgName,
      item.name,
      item.url,
      index
    ].filter(Boolean).join("_");

    let hash = 0;

    for (let i = 0; i < raw.length; i++) {
      hash = ((hash << 5) - hash) + raw.charCodeAt(i);
      hash |= 0;
    }

    return prefix + "_" + Math.abs(hash);
  }

  const M3UParser = {
    parse: function (text, options) {
      options = options || {};

      const sourceName = options.sourceName || "Playlist";
      const playlistId = options.playlistId || "";
      const lines = String(text || "").split(/\r?\n/);
      const header = getHeaderMeta(text);

      const items = [];
      let current = null;

      for (let i = 0; i < lines.length; i++) {
        const line = clean(lines[i]);

        if (!line) continue;

        if (line.indexOf("#EXTM3U") === 0) {
          continue;
        }

        if (line.indexOf("#EXTINF") === 0) {
          const attrs = parseAttributes(line);
          const title = parseTitle(line);

          current = {
            duration: this.parseDuration(line),
            tvgId: attrs["tvg-id"] || attrs["tvgid"] || "",
            tvgName: attrs["tvg-name"] || attrs["tvgname"] || "",
            logo: attrs["tvg-logo"] || attrs["logo"] || "",
            tvgLogo: attrs["tvg-logo"] || attrs["logo"] || "",
            group: normalizeGroup(attrs["group-title"] || attrs["group"] || attrs["category"] || ""),
            name: clean(title || attrs["tvg-name"] || attrs["name"] || "Unknown"),
            rawExtinf: line
          };

          continue;
        }

        /*
         * hls.gd and many IPTV portals use:
         * #EXTINF:...
         * #EXTGRP:1. News/Новости
         * http://...
         */
        if (line.indexOf("#EXTGRP:") === 0) {
          if (current) {
            const group = clean(line.replace("#EXTGRP:", ""));
            current.group = normalizeGroup(group);
          }
          continue;
        }

        if (line[0] === "#") {
          continue;
        }

        if (current) {
          current.url = line;
          current.playlistId = playlistId;
          current.sourceName = sourceName;
          current.group = normalizeGroup(current.group);
          current.type = detectType(current);
          current.number = items.length + 1;
          current.id = makeId(current.type, items.length, current);
          current.year = this.extractYear(current.name);
          items.push(current);
          current = null;
        }
      }

      const live = [];
      const movies = [];
      const series = [];

      for (let i = 0; i < items.length; i++) {
        const item = items[i];

        if (item.type === "movie") {
          movies.push(item);
        } else if (item.type === "series") {
          series.push(item);
        } else {
          live.push(item);
        }
      }

      return {
        header: header,
        items: items,
        live: live,
        movies: movies,
        series: series,
        meta: {
          total: items.length,
          live: live.length,
          movies: movies.length,
          series: series.length,
          urlTvg: header.urlTvg
        }
      };
    },

    parseDuration: function (line) {
      const match = String(line || "").match(/#EXTINF:\s*([^,\s]+)/i);
      if (!match) return -1;

      const value = Number(match[1]);
      return isNaN(value) ? -1 : value;
    },

    extractYear: function (text) {
      const match = String(text || "").match(/\b(19|20)\d{2}\b/);
      return match ? match[0] : "";
    },

    buildCategories: function (items) {
      const list = Array.isArray(items) ? items : [];
      const map = {};

      for (let i = 0; i < list.length; i++) {
        const group = normalizeGroup(list[i].group || "Other");

        if (!map[group]) map[group] = 0;
        map[group]++;
      }

      const categories = [{
        id: "all",
        name: "All",
        count: list.length
      }];

      Object.keys(map)
        .sort(function (a, b) {
          const na = Number((a.match(/^(\d+)/) || [])[1] || 9999);
          const nb = Number((b.match(/^(\d+)/) || [])[1] || 9999);

          if (na !== nb) return na - nb;
          if (a === "Other") return 1;
          if (b === "Other") return -1;

          return a.localeCompare(b);
        })
        .forEach(function (name) {
          categories.push({
            id: "cat_" + name.toLowerCase().replace(/[^a-z0-9а-яё]+/gi, "_"),
            name: name,
            count: map[name]
          });
        });

      return categories;
    },

    filterByCategory: function (items, categoryName) {
      const list = Array.isArray(items) ? items : [];

      if (!categoryName || categoryName === "All") {
        return list.slice();
      }

      return list.filter(function (item) {
        return normalizeGroup(item.group || "Other") === categoryName;
      });
    },

    search: function (items, query) {
      const list = Array.isArray(items) ? items : [];
      const q = String(query || "").toLowerCase().trim();

      if (!q) return list.slice();

      return list.filter(function (item) {
        const haystack = [
          item.name,
          item.tvgName,
          item.tvgId,
          item.group,
          item.url
        ].filter(Boolean).join(" ").toLowerCase();

        return haystack.indexOf(q) >= 0;
      });
    }
  };

  window.M3UParser = M3UParser;
})();
