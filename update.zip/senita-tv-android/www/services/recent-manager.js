
(function () {
  "use strict";

  const RecentManager = {
    key: "mrb_recent_channels",
    max: 10,
    installed: false,

    addChannel: function (channel) {
      if (!channel || !(channel.url || channel.streamUrl)) return;

      const item = {
        id: channel.id || "",
        name: channel.name || "Unknown",
        url: channel.url || channel.streamUrl || "",
        logo: channel.logo || channel.tvgLogo || "",
        tvgLogo: channel.tvgLogo || channel.logo || "",
        group: channel.group || "",
        tvgId: channel.tvgId || "",
        tvgName: channel.tvgName || "",
        type: channel.type || "live",
        number: channel.number || "",
        lastWatchedAt: new Date().toISOString()
      };

      let list = this.getAll().filter(function (x) {
        return x.url !== item.url && x.id !== item.id;
      });

      list.unshift(item);
      list = list.slice(0, this.max);

      try {
        localStorage.setItem(this.key, JSON.stringify(list));
      } catch (e) {}
    },

    getAll: function () {
      try {
        const raw = localStorage.getItem(this.key);
        const list = raw ? JSON.parse(raw) : [];
        return Array.isArray(list) ? list : [];
      } catch (e) {
        return [];
      }
    },

    clear: function () {
      try { localStorage.removeItem(this.key); } catch (e) {}
    },

    install: function () {
      if (this.installed) return;
      if (!window.MRB || typeof MRB.navigate !== "function") return;

      const originalNavigate = MRB.navigate.bind(MRB);
      const self = this;

      MRB.navigate = function (route, params, options) {
        try {
          if (route === "player" && params && params.channel) {
            self.addChannel(params.channel);
          }
        } catch (e) {}
        return originalNavigate(route, params, options);
      };

      this.installed = true;
    },

    boot: function () {
      const self = this;
      const timer = setInterval(function () {
        self.install();
        if (self.installed) clearInterval(timer);
      }, 300);
    }
  };

  window.RecentManager = RecentManager;

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
      RecentManager.boot();
    });
  } else {
    RecentManager.boot();
  }
})();
