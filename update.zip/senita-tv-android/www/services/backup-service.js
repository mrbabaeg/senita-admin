
(function () {
  "use strict";

  const BackupService = {
    version: "1.0.0",

    keys: [
      "mrb_storage",
      "mrb_recent_channels",
      "mrb_auto_refresh_state",
      "mrb_player_settings",
      "mrb_favorites"
    ],

    exportData: function () {
      const data = {
        app: "Senita TV",
        version: this.version,
        exportedAt: new Date().toISOString(),
        localStorage: {}
      };

      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (!key) continue;

        if (
          key.indexOf("mrb") === 0 ||
          key.indexOf("MRB") === 0 ||
          key.indexOf("playlist") >= 0 ||
          key.indexOf("favorite") >= 0
        ) {
          data.localStorage[key] = localStorage.getItem(key);
        }
      }

      return data;
    },

    exportText: function () {
      return JSON.stringify(this.exportData(), null, 2);
    },

    downloadBackup: function () {
      const text = this.exportText();
      const filename = "senita-tv-backup-" + this.dateStamp() + ".json";

      try {
        const blob = new Blob([text], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(function () {
          URL.revokeObjectURL(url);
          if (a.parentNode) a.parentNode.removeChild(a);
        }, 500);
        return true;
      } catch (e) {
        this.showBackupText(text);
        return false;
      }
    },

    showBackupText: function (text) {
      let root = document.getElementById("backup-modal-root");
      if (!root) {
        root = document.createElement("div");
        root.id = "backup-modal-root";
        document.body.appendChild(root);
      }

      root.className = "backup-modal-root";
      root.innerHTML =
        '<div class="backup-modal">' +
          '<div class="backup-modal-title">Backup JSON</div>' +
          '<div class="backup-modal-subtitle">Copy and save this JSON text.</div>' +
          '<textarea id="backup-export-text" class="backup-textarea"></textarea>' +
          '<div class="backup-modal-actions">' +
            '<button id="backup-close-btn" class="backup-modal-btn">Close</button>' +
          '</div>' +
        '</div>';

      const textarea = document.getElementById("backup-export-text");
      if (textarea) {
        textarea.value = text;
        textarea.focus();
        textarea.select();
      }

      const close = document.getElementById("backup-close-btn");
      if (close) {
        close.onclick = function () {
          root.innerHTML = "";
          root.className = "";
        };
      }
    },

    importText: function (text) {
      if (!text || !String(text).trim()) throw new Error("Backup text is empty");

      let data;
      try {
        data = JSON.parse(text);
      } catch (e) {
        throw new Error("Invalid backup JSON");
      }

      if (!data || !data.localStorage) {
        throw new Error("This is not a valid Senita TV backup");
      }

      Object.keys(data.localStorage).forEach(function (key) {
        if (data.localStorage[key] !== undefined && data.localStorage[key] !== null) {
          localStorage.setItem(key, data.localStorage[key]);
        }
      });

      return true;
    },

    openImportModal: function (onDone) {
      let root = document.getElementById("backup-modal-root");
      if (!root) {
        root = document.createElement("div");
        root.id = "backup-modal-root";
        document.body.appendChild(root);
      }

      root.className = "backup-modal-root";
      root.innerHTML =
        '<div class="backup-modal">' +
          '<div class="backup-modal-title">Restore Backup</div>' +
          '<div class="backup-modal-subtitle">Paste backup JSON here, then press Restore.</div>' +
          '<textarea id="backup-import-text" class="backup-textarea" placeholder="Paste backup JSON..."></textarea>' +
          '<div class="backup-modal-actions">' +
            '<button id="backup-restore-btn" class="backup-modal-btn primary">Restore</button>' +
            '<button id="backup-cancel-btn" class="backup-modal-btn">Cancel</button>' +
          '</div>' +
        '</div>';

      const textarea = document.getElementById("backup-import-text");
      if (textarea) textarea.focus();

      const restore = document.getElementById("backup-restore-btn");
      const cancel = document.getElementById("backup-cancel-btn");

      if (restore) {
        restore.onclick = () => {
          try {
            this.importText(textarea ? textarea.value : "");
            root.innerHTML = "";
            root.className = "";
            if (onDone) onDone(true);
          } catch (err) {
            alert(err.message || "Restore failed");
          }
        };
      }

      if (cancel) {
        cancel.onclick = function () {
          root.innerHTML = "";
          root.className = "";
        };
      }
    },

    dateStamp: function () {
      const d = new Date();
      const p = function (n) { return String(n).padStart(2, "0"); };
      return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + "-" + p(d.getHours()) + p(d.getMinutes());
    }
  };

  window.BackupService = BackupService;
})();
