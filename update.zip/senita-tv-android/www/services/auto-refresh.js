
(function () {
  "use strict";
  const AutoRefresh = {
    key: "mrb_auto_refresh_state",
    intervalMs: 6 * 60 * 60 * 1000,
    isRunning: false,
    boot: function () {
      setTimeout(() => this.checkAndRefresh("boot"), 15000);
      setInterval(() => this.checkAndRefresh("timer"), 30 * 60 * 1000);
    },
    checkAndRefresh: async function (reason) {
      if (this.isRunning || !window.StorageCore || !window.PlaylistManager) return;
      const p = StorageCore.getActivePlaylist ? StorageCore.getActivePlaylist() : null;
      if (!p || !p.id) return;
      const last = p.lastRefreshAt ? new Date(p.lastRefreshAt).getTime() : 0;
      if (last && Date.now() - last < this.intervalMs) {
        this.saveState({ lastCheckAt: new Date().toISOString(), status: "fresh", message: "Playlist cache is fresh", lastReason: reason });
        return;
      }
      await this.refreshNow(reason);
    },
    refreshNow: async function (reason) {
      if (this.isRunning) return;
      if (!window.StorageCore || !window.PlaylistManager) throw new Error("Required modules are not loaded");
      const p = StorageCore.getActivePlaylist ? StorageCore.getActivePlaylist() : null;
      if (!p || !p.id) throw new Error("No active playlist");
      this.isRunning = true;
      this.saveState({ lastCheckAt: new Date().toISOString(), status: "refreshing", message: "Refreshing playlist...", lastReason: reason || "manual" });
      try {
        const result = await PlaylistManager.refreshPlaylist(p.id);
        const meta = result && result.parsed && result.parsed.meta ? result.parsed.meta : {};
        this.saveState({
          lastCheckAt: new Date().toISOString(),
          lastRefreshAt: new Date().toISOString(),
          status: "ok",
          message: "Playlist refreshed",
          lastReason: reason || "manual",
          total: meta.total || 0,
          live: meta.live || 0,
          xmltvStatus: result && result.xmltv ? (result.xmltv.ok ? "loaded" : result.xmltv.reason) : ""
        });
        if (window.SearchEngine && SearchEngine.buildFromPlaylist) { try { SearchEngine.buildFromPlaylist(); } catch(e){} }
        try { window.dispatchEvent(new CustomEvent("mrb:playlist-updated")); } catch(e) {}
        return result;
      } catch (err) {
        this.saveState({ lastCheckAt: new Date().toISOString(), status: "error", message: err.message || "Refresh failed", lastReason: reason || "manual" });
        throw err;
      } finally {
        this.isRunning = false;
      }
    },
    getState: function () {
      try { return JSON.parse(localStorage.getItem(this.key) || "{}"); } catch(e) { return {}; }
    },
    saveState: function (state) {
      try { localStorage.setItem(this.key, JSON.stringify(Object.assign({}, this.getState(), state))); } catch(e) {}
    },
    formatDateTime: function (iso) {
      if (!iso) return "Never";
      try { return new Date(iso).toLocaleString(undefined, { day:"2-digit", month:"short", hour:"2-digit", minute:"2-digit" }); } catch(e) { return iso; }
    }
  };
  window.AutoRefresh = AutoRefresh;
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => AutoRefresh.boot());
  else AutoRefresh.boot();
})();
