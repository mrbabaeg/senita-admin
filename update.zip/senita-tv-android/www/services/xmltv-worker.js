/* =========================
   Senita TV
   XMLTV streaming parser (Web Worker)
   - receives the XML in text chunks, never builds a DOM
   - keeps only channels that exist in the playlist
   - keeps only programmes inside a time window
   ========================= */

"use strict";

let wantedIds = {};      // lowercase tvg-id -> lookup key
let wantedNames = {};    // lowercase channel name -> lookup key
let idToKey = {};        // xmltv channel id -> lookup key
let fromMs = 0;
let toMs = 0;
let maxPerChannel = 80;
let buffer = "";
let programs = {};
let programCount = 0;
let channelCount = 0;

function decode(s) {
  if (!s) return "";
  if (s.indexOf("<![CDATA[") >= 0) s = s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1");
  if (s.indexOf("&") < 0) return s.trim();
  return s
    .replace(/&#x([0-9a-f]+);/gi, function (m, h) { try { return String.fromCodePoint(parseInt(h, 16)); } catch (e) { return ""; } })
    .replace(/&#(\d+);/g, function (m, d) { try { return String.fromCodePoint(parseInt(d, 10)); } catch (e) { return ""; } })
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .trim();
}

function attr(tag, name) {
  let i = tag.indexOf(" " + name + "=");
  if (i < 0) return "";
  i += name.length + 2;
  const q = tag.charAt(i);
  if (q !== '"' && q !== "'") return "";
  const end = tag.indexOf(q, i + 1);
  return end < 0 ? "" : tag.slice(i + 1, end);
}

function inner(block, tagName) {
  const open = block.indexOf("<" + tagName);
  if (open < 0) return "";
  const gt = block.indexOf(">", open);
  if (gt < 0 || block.charAt(gt - 1) === "/") return "";
  const close = block.indexOf("</" + tagName + ">", gt);
  return close < 0 ? "" : decode(block.slice(gt + 1, close));
}

function parseDate(v) {
  const m = String(v || "").trim().match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})?\s*([+-]\d{4})?/);
  if (!m) return NaN;
  let t = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
  if (m[7]) {
    const sign = m[7][0] === "-" ? -1 : 1;
    const off = (parseInt(m[7].slice(1, 3), 10) * 60 + parseInt(m[7].slice(3, 5), 10)) * 60000;
    t -= sign * off;
  }
  return t;
}

function handleChannel(block) {
  const openEnd = block.indexOf(">");
  const id = decode(attr(block.slice(0, openEnd + 1), "id"));
  if (!id) return;
  let key = wantedIds[id.toLowerCase()];
  if (!key) {
    const re = /<display-name(?:\s[^>]*)?>([\s\S]*?)<\/display-name>/gi;
    let m;
    while ((m = re.exec(block))) {
      const n = decode(m[1]).toLowerCase();
      if (wantedNames[n]) { key = wantedNames[n]; break; }
    }
  }
  if (key) {
    idToKey[id] = key;
    channelCount++;
  }
}

function handleProgramme(block) {
  const openEnd = block.indexOf(">");
  const open = block.slice(0, openEnd + 1);
  const channelId = decode(attr(open, "channel"));
  let key = idToKey[channelId];
  if (!key) {
    /* some files have no <channel> section: match the id directly */
    key = wantedIds[channelId.toLowerCase()];
    if (!key) return;
    idToKey[channelId] = key;
    channelCount++;
  }
  const start = parseDate(attr(open, "start"));
  const end = parseDate(attr(open, "stop"));
  if (!(start < end) || end <= fromMs || start >= toMs) return;

  const list = programs[key] || (programs[key] = []);
  if (list.length >= maxPerChannel) return;

  let desc = inner(block, "desc");
  if (desc.length > 160) desc = desc.slice(0, 157) + "...";

  list.push({ start: start, end: end, title: inner(block, "title") || "Programme", description: desc });
  programCount++;
}

function drain(final) {
  let pos = 0;
  /* next known positions; -2 = unknown, -1 = none left in this buffer */
  let nextC = -2;
  let nextP = -2;
  while (true) {
    if (nextC === -2 || (nextC >= 0 && nextC < pos)) nextC = buffer.indexOf("<channel", pos);
    if (nextP === -2 || (nextP >= 0 && nextP < pos)) nextP = buffer.indexOf("<programme", pos);
    if (nextC < 0 && nextP < 0) { pos = Math.max(pos, buffer.length - 12); break; }

    const isChannel = nextC >= 0 && (nextP < 0 || nextC < nextP);
    const startIdx = isChannel ? nextC : nextP;
    const closeTag = isChannel ? "</channel>" : "</programme>";
    const endIdx = buffer.indexOf(closeTag, startIdx);
    let blockEnd;
    if (endIdx < 0) {
      const gt = buffer.indexOf(">", startIdx);
      if (gt >= 0 && buffer.charAt(gt - 1) === "/") {
        blockEnd = gt + 1;
      } else {
        pos = startIdx;
        break;
      }
    } else {
      blockEnd = endIdx + closeTag.length;
    }

    const block = buffer.slice(startIdx, blockEnd);
    try {
      if (isChannel) handleChannel(block); else handleProgramme(block);
    } catch (e) {}
    pos = blockEnd;
  }
  buffer = final ? "" : buffer.slice(pos);
}

self.onmessage = function (e) {
  const msg = e.data || {};
  if (msg.type === "init") {
    wantedIds = {};
    wantedNames = {};
    idToKey = {};
    programs = {};
    programCount = 0;
    channelCount = 0;
    buffer = "";
    (msg.wanted || []).forEach(function (w) {
      if (w.tvgId) wantedIds[String(w.tvgId).toLowerCase().trim()] = w.key;
      if (w.name) wantedNames[String(w.name).toLowerCase().trim()] = w.key;
    });
    fromMs = msg.from || 0;
    toMs = msg.to || Infinity;
    maxPerChannel = msg.maxPerChannel || 80;
  } else if (msg.type === "chunk") {
    buffer += msg.text || "";
    drain(false);
  } else if (msg.type === "end") {
    drain(true);
    Object.keys(programs).forEach(function (k) {
      programs[k].sort(function (a, b) { return a.start - b.start; });
    });
    self.postMessage({ type: "done", programs: programs, programCount: programCount, channelCount: channelCount });
  }
};
