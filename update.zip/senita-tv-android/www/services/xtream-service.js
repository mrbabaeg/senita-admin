
(function () {
  "use strict";

  const XtreamService = {
    normalizeServer: function (server) {
      server = String(server || "").trim();
      if (!server) throw new Error("Server URL is empty");
      if (!/^https?:\/\//i.test(server)) server = "http://" + server;
      return server.replace(/\/+$/, "");
    },

    buildUrl: function (server, username, password, params) {
      server = this.normalizeServer(server);
      params = params || {};

      const query = Object.assign({
        username: username,
        password: password
      }, params);

      const qs = Object.keys(query).map(function (key) {
        return encodeURIComponent(key) + "=" + encodeURIComponent(query[key]);
      }).join("&");

      return server + "/player_api.php?" + qs;
    },

    buildStreamUrl: function (server, username, password, type, streamId, ext) {
      server = this.normalizeServer(server);
      ext = ext || (type === "live" ? "ts" : "mp4");

      if (type === "live") {
        return server + "/live/" + encodeURIComponent(username) + "/" + encodeURIComponent(password) + "/" + streamId + "." + ext;
      }

      if (type === "movie") {
        return server + "/movie/" + encodeURIComponent(username) + "/" + encodeURIComponent(password) + "/" + streamId + "." + ext;
      }

      if (type === "series") {
        return server + "/series/" + encodeURIComponent(username) + "/" + encodeURIComponent(password) + "/" + streamId + "." + ext;
      }

      return "";
    },

    fetchJson: async function (url, timeoutMs) {
      timeoutMs = timeoutMs || 25000;

      const controller = window.AbortController ? new AbortController() : null;
      const timer = controller ? setTimeout(function () { controller.abort(); }, timeoutMs) : null;

      try {
        const res = await fetch(url, {
          method: "GET",
          cache: "no-store",
          signal: controller ? controller.signal : undefined
        });

        if (!res.ok) throw new Error("HTTP " + res.status);

        return await res.json();
      } finally {
        if (timer) clearTimeout(timer);
      }
    },

    getAccountInfo: async function (server, username, password) {
      const url = this.buildUrl(server, username, password, {});
      return await this.fetchJson(url);
    },

    getLiveCategories: async function (server, username, password) {
      return await this.fetchJson(this.buildUrl(server, username, password, { action: "get_live_categories" }));
    },

    getVodCategories: async function (server, username, password) {
      return await this.fetchJson(this.buildUrl(server, username, password, { action: "get_vod_categories" }));
    },

    getSeriesCategories: async function (server, username, password) {
      return await this.fetchJson(this.buildUrl(server, username, password, { action: "get_series_categories" }));
    },

    getLiveStreams: async function (server, username, password) {
      return await this.fetchJson(this.buildUrl(server, username, password, { action: "get_live_streams" }));
    },

    getVodStreams: async function (server, username, password) {
      return await this.fetchJson(this.buildUrl(server, username, password, { action: "get_vod_streams" }));
    },

    getSeries: async function (server, username, password) {
      return await this.fetchJson(this.buildUrl(server, username, password, { action: "get_series" }));
    },

    getVodInfo: async function (server, username, password, vodId) {
      return await this.fetchJson(this.buildUrl(server, username, password, {
        action: "get_vod_info",
        vod_id: vodId
      }));
    },

    getSeriesInfo: async function (server, username, password, seriesId) {
      return await this.fetchJson(this.buildUrl(server, username, password, {
        action: "get_series_info",
        series_id: seriesId
      }));
    },

    getShortEpg: async function (server, username, password, streamId, limit) {
      return await this.fetchJson(this.buildUrl(server, username, password, {
        action: "get_short_epg",
        stream_id: streamId,
        limit: limit || 4
      }));
    },

    loadAll: async function (playlist) {
      if (!playlist) throw new Error("Playlist is empty");

      const server = this.normalizeServer(playlist.server || playlist.url || "");
      const username = playlist.username || "";
      const password = playlist.password || "";

      if (!username || !password) throw new Error("Xtream username/password missing");

      const account = await this.getAccountInfo(server, username, password);
      const user = account && account.user_info ? account.user_info : {};

      if (user.auth !== undefined && Number(user.auth) !== 1) {
        throw new Error("Xtream account authentication failed");
      }

      const liveCategories = await this.safe(() => this.getLiveCategories(server, username, password), []);
      const vodCategories = await this.safe(() => this.getVodCategories(server, username, password), []);
      const seriesCategories = await this.safe(() => this.getSeriesCategories(server, username, password), []);

      const liveStreams = await this.safe(() => this.getLiveStreams(server, username, password), []);
      const vodStreams = await this.safe(() => this.getVodStreams(server, username, password), []);
      const series = await this.safe(() => this.getSeries(server, username, password), []);

      const liveMap = this.categoryMap(liveCategories);
      const vodMap = this.categoryMap(vodCategories);
      const seriesMap = this.categoryMap(seriesCategories);

      const live = liveStreams.map((item, index) => this.normalizeLive(item, index, playlist, server, username, password, liveMap));
      const movies = vodStreams.map((item, index) => this.normalizeMovie(item, index, playlist, server, username, password, vodMap));
      const normalizedSeries = series.map((item, index) => this.normalizeSeries(item, index, playlist, server, username, password, seriesMap));

      return {
        account: account,
        liveCategories: liveCategories,
        vodCategories: vodCategories,
        seriesCategories: seriesCategories,
        live: live,
        movies: movies,
        series: normalizedSeries,
        meta: {
          total: live.length + movies.length + normalizedSeries.length,
          live: live.length,
          movies: movies.length,
          series: normalizedSeries.length
        }
      };
    },

    safe: async function (fn, fallback) {
      try { return await fn(); }
      catch (e) { console.warn("Xtream API part failed:", e); return fallback; }
    },

    categoryMap: function (categories) {
      const map = {};
      (categories || []).forEach(function (cat) {
        map[String(cat.category_id)] = cat.category_name || "Other";
      });
      return map;
    },

    normalizeLive: function (item, index, playlist, server, username, password, categoryMap) {
      const streamId = item.stream_id || item.num || index + 1;
      return {
        id: "xt_live_" + streamId,
        playlistId: playlist.id,
        sourceName: playlist.name || "Xtream",
        type: "live",
        number: index + 1,
        name: item.name || "Live Channel",
        tvgId: item.epg_channel_id || "",
        tvgName: item.name || "",
        logo: item.stream_icon || "",
        tvgLogo: item.stream_icon || "",
        group: categoryMap[String(item.category_id)] || "Other",
        categoryId: item.category_id || "",
        streamId: streamId,
        url: this.buildStreamUrl(server, username, password, "live", streamId, "ts"),
        raw: item
      };
    },

    normalizeMovie: function (item, index, playlist, server, username, password, categoryMap) {
      const streamId = item.stream_id || index + 1;
      const ext = item.container_extension || "mp4";
      return {
        id: "xt_movie_" + streamId,
        playlistId: playlist.id,
        sourceName: playlist.name || "Xtream",
        type: "movie",
        number: index + 1,
        name: item.name || "Movie",
        title: item.name || "Movie",
        logo: item.stream_icon || item.cover || "",
        poster: item.stream_icon || item.cover || "",
        group: categoryMap[String(item.category_id)] || "Movies",
        categoryId: item.category_id || "",
        streamId: streamId,
        rating: item.rating || "",
        year: item.year || "",
        url: this.buildStreamUrl(server, username, password, "movie", streamId, ext),
        raw: item
      };
    },

    normalizeSeries: function (item, index, playlist, server, username, password, categoryMap) {
      const seriesId = item.series_id || index + 1;
      return {
        id: "xt_series_" + seriesId,
        playlistId: playlist.id,
        sourceName: playlist.name || "Xtream",
        type: "series",
        number: index + 1,
        name: item.name || "Series",
        title: item.name || "Series",
        logo: item.cover || "",
        poster: item.cover || "",
        cover: item.cover || "",
        group: categoryMap[String(item.category_id)] || "Series",
        categoryId: item.category_id || "",
        seriesId: seriesId,
        rating: item.rating || "",
        year: item.year || "",
        plot: item.plot || "",
        raw: item
      };
    }
  };

  window.XtreamService = XtreamService;
})();
