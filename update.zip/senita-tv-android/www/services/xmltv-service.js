/* =========================
   Senita TV
   XMLTV Service v2
   - Downloads the EPG as a stream and parses it in a Web Worker
     (the UI never freezes, even with 50+ MB XMLTV files)
   - Keeps only the playlist's channels and a 2-day window
   - Caches the compact result (opens instantly next time)
   ========================= */

(function () {
  "use strict";

  const CACHE_KEY = "mrb_epg_v2";
  const MAX_AGE_MS = 12 * 60 * 60 * 1000;
  const FETCH_TIMEOUT_MS = 180000;

  function epgKey(channel) {
    if (!channel) return "";
    return String(channel.tvgId || channel.tvgName || channel.name || "").toLowerCase().trim();
  }

  function readCache() {
    try {
      const raw = localStorage.getItem(CACHE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  function writeCache(data) {
    let json = JSON.stringify(data);
    if (json.length > 2500000) {
      /* keep storage small: drop descriptions for very large EPGs */
      const slim = {};
      Object.keys(data.programs || {}).forEach(function (k) {
        slim[k] = data.programs[k].map(function (p) { return { start: p.start, end: p.end, title: p.title }; });
      });
      json = JSON.stringify({ url: data.url, savedAt: data.savedAt, programs: slim });
    }
    try {
      localStorage.setItem(CACHE_KEY, json);
    } catch (e) {
      try { localStorage.removeItem(CACHE_KEY); } catch (err) {}
    }
  }

  function buildWanted(channels) {
    const wanted = [];
    const seen = {};
    (channels || []).forEach(function (ch) {
      const key = epgKey(ch);
      if (!key || seen[key]) return;
      seen[key] = true;
      if (ch.tvgId) wanted.push({ key: key, tvgId: ch.tvgId });
      if (ch.tvgName) wanted.push({ key: key, name: ch.tvgName });
      if (ch.name) wanted.push({ key: key, name: ch.name });
    });
    return wanted;
  }

  const XMLTVService = {
    programsByChannel: {},
    lastLoadedUrl: "",
    lastLoadedAt: "",
    loading: false,

    /* Load cached EPG into memory (fast, called at startup) */
    init: function () {
      const cache = readCache();
      if (cache && cache.programs) {
        this.apply(cache.programs, cache.url, cache.savedAt);
      }
    },

    apply: function (programs, url, at) {
      this.programsByChannel = programs || {};
      this.lastLoadedUrl = url || "";
      this.lastLoadedAt = at || "";
      if (window.EPGEngine && EPGEngine.setPrograms) EPGEngine.setPrograms(this.programsByChannel);
    },

    isFresh: function (url) {
      const cache = readCache();
      return !!(cache && cache.url === url && cache.savedAt && Date.now() - new Date(cache.savedAt).getTime() < MAX_AGE_MS);
    },

    /* Refresh in the background only when needed. Never throws. */
    refreshInBackground: function (url, channels, force) {
      if (!url || this.loading) return Promise.resolve(null);
      if (!force && this.isFresh(url)) return Promise.resolve(null);
      return this.loadFromUrl(url, channels).catch(function (err) {
        console.warn("EPG load failed:", err && err.message);
        return null;
      });
    },

    loadFromUrl: function (url, channels) {
      if (this._pending) return this._pending;
      const self = this;
      this._pending = this._load(url, channels).finally(function () { self._pending = null; });
      return this._pending;
    },

    _load: async function (url, channels) {
      if (!url) throw new Error("XMLTV URL is empty");
      if (typeof Worker === "undefined") throw new Error("Worker not supported");

      channels = channels || (window.PlaylistManager ? PlaylistManager.getActiveLiveChannels() : []);
      const wanted = buildWanted(channels);
      if (!wanted.length) return { url: url, channelCount: 0, programCount: 0 };

      this.loading = true;
      const worker = new Worker("services/xmltv-worker.js");
      const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
      const timer = setTimeout(function () { if (controller) controller.abort(); }, FETCH_TIMEOUT_MS);

      try {
        const now = Date.now();
        worker.postMessage({
          type: "init",
          wanted: wanted,
          from: now - 2 * 3600000,
          to: now + 30 * 3600000,
          maxPerChannel: 48
        });

        const done = new Promise(function (resolve, reject) {
          worker.onmessage = function (e) {
            if (e.data && e.data.type === "done") resolve(e.data);
          };
          worker.onerror = function (e) { reject(new Error((e && e.message) || "EPG worker error")); };
        });

        const response = await fetch(url, { cache: "no-store", signal: controller ? controller.signal : undefined });
        if (!response.ok) throw new Error("EPG HTTP " + response.status);

        let stream = response.body;
        const gz = /\.gz(\?|$)/i.test(url);
        if (stream && gz && typeof DecompressionStream !== "undefined") {
          stream = stream.pipeThrough(new DecompressionStream("gzip"));
        }

        if (stream && stream.getReader && typeof TextDecoder !== "undefined") {
          const reader = stream.getReader();
          const decoder = new TextDecoder("utf-8");
          while (true) {
            const step = await reader.read();
            if (step.done) break;
            const text = decoder.decode(step.value, { stream: true });
            if (text) worker.postMessage({ type: "chunk", text: text });
          }
          const tail = decoder.decode();
          if (tail) worker.postMessage({ type: "chunk", text: tail });
        } else {
          const text = await response.text();
          const size = 256 * 1024;
          for (let i = 0; i < text.length; i += size) {
            worker.postMessage({ type: "chunk", text: text.slice(i, i + size) });
          }
        }

        worker.postMessage({ type: "end" });
        const result = await done;

        const savedAt = new Date().toISOString();
        this.apply(result.programs, url, savedAt);
        writeCache({ url: url, savedAt: savedAt, programs: result.programs });

        try { window.dispatchEvent(new CustomEvent("mrb:epg-updated")); } catch (e) {}

        return {
          url: url,
          loadedAt: savedAt,
          channelCount: result.channelCount,
          programCount: result.programCount
        };
      } finally {
        clearTimeout(timer);
        try { worker.terminate(); } catch (e) {}
        this.loading = false;
      }
    },

    findChannelKey: function (channel) {
      const key = epgKey(channel);
      if (key && this.programsByChannel[key]) return key;
      const name = String((channel && channel.name) || "").toLowerCase().trim();
      if (name && this.programsByChannel[name]) return name;
      return "";
    },

    getProgramsForChannel: function (channel) {
      const key = this.findChannelKey(channel);
      return key ? (this.programsByChannel[key] || []) : [];
    },

    clear: function () {
      this.programsByChannel = {};
      this.lastLoadedUrl = "";
      this.lastLoadedAt = "";
      try { localStorage.removeItem(CACHE_KEY); } catch (e) {}
      if (window.EPGEngine && EPGEngine.clear) EPGEngine.clear();
    },

    getStats: function () {
      return {
        url: this.lastLoadedUrl,
        loadedAt: this.lastLoadedAt,
        channels: Object.keys(this.programsByChannel).length
      };
    }
  };

  window.XMLTVService = XMLTVService;
})();
