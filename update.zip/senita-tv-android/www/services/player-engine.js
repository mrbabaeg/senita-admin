/* =========================
   Senita TV
   Player Engine Service
   HTML5 / HLS / MPEG-TS
   - webOS: native <video> playback (unchanged behaviour)
   - Android (Capacitor): hls.js for HLS, mpegts.js for raw .ts,
     native <video> for mp4/mkv, with automatic fallback chain
   ========================= */

(function () {
  "use strict";

  const HTTP_INTERCEPTOR = "_capacitor_http_interceptor_";

  function isAndroidApp() {
    try {
      return !!(
        window.Capacitor &&
        typeof window.Capacitor.getPlatform === "function" &&
        window.Capacitor.getPlatform() === "android"
      );
    } catch (e) {
      return false;
    }
  }

  function urlPath(url) {
    return String(url || "").split("#")[0].split("?")[0].toLowerCase();
  }

  function isHlsUrl(url) {
    const p = urlPath(url);
    return p.endsWith(".m3u8") || p.endsWith(".m3u") || String(url).toLowerCase().indexOf("m3u8") > -1;
  }

  function isTsUrl(url) {
    return urlPath(url).endsWith(".ts");
  }

  function isXtreamLiveTs(url) {
    return /\/live\/[^/]+\/[^/]+\/[^/?#]+\.ts(\?|#|$)/i.test(String(url || ""));
  }

  function tsToM3u8(url) {
    return String(url).replace(/\.ts(\?|#|$)/i, ".m3u8$1");
  }

  /*
   * Capacitor routes cross-origin GET requests through a local proxy URL
   * (http://localhost/_capacitor_http_interceptor_?u=...). hls.js resolves
   * relative segment paths against response.url, so we restore the real URL.
   */
  function createHlsLoader() {
    if (!window.Hls || !window.Hls.DefaultConfig || !window.Hls.DefaultConfig.loader) return undefined;

    const Base = window.Hls.DefaultConfig.loader;

    return class ProxyAwareLoader extends Base {
      load(context, config, callbacks) {
        const originalUrl = context.url;
        const onSuccess = callbacks.onSuccess;

        const wrapped = Object.assign({}, callbacks, {
          onSuccess: function (response, stats, ctx, networkDetails) {
            if (response && typeof response.url === "string" && response.url.indexOf(HTTP_INTERCEPTOR) > -1) {
              response.url = originalUrl;
            }
            onSuccess(response, stats, ctx, networkDetails);
          }
        });

        super.load(context, config, wrapped);
      }
    };
  }

  const PlayerEngine = {
    video: null,
    source: "",
    currentItem: null,
    status: "idle",
    retryCount: 0,
    maxRetries: 3,
    retryTimer: null,
    bufferingTimer: null,
    lastTime: 0,
    aspect: "contain",

    /* playback strategy */
    plan: [],
    planIndex: 0,
    attemptId: 0,
    hasPlayed: false,
    autoplay: true,
    hls: null,
    mpegtsPlayer: null,
    mediaRecoverTried: false,

    callbacks: {
      onStatus: null,
      onError: null,
      onTime: null,
      onEnded: null,
      onBuffering: null
    },

    init: function (videoElement, options) {
      options = options || {};

      this.destroy();

      if (!videoElement) {
        throw new Error("PlayerEngine requires a video element");
      }

      this.video = videoElement;
      this.retryCount = 0;
      this.status = "idle";

      this.callbacks.onStatus = typeof options.onStatus === "function" ? options.onStatus : null;
      this.callbacks.onError = typeof options.onError === "function" ? options.onError : null;
      this.callbacks.onTime = typeof options.onTime === "function" ? options.onTime : null;
      this.callbacks.onEnded = typeof options.onEnded === "function" ? options.onEnded : null;
      this.callbacks.onBuffering = typeof options.onBuffering === "function" ? options.onBuffering : null;

      this.bindEvents();

      const settings = window.StorageCore ? StorageCore.getSettings() : {};
      this.setAspect(settings.playerAspect || "contain");

      return this;
    },

    bindEvents: function () {
      if (!this.video) return;

      this._onLoadStart = () => this.setStatus("loading");
      this._onCanPlay = () => this.setStatus("ready");
      this._onPlaying = () => {
        this.hasPlayed = true;
        this.retryCount = 0;
        this.setStatus("playing");
      };
      this._onPause = () => this.setStatus("paused");
      this._onWaiting = () => {
        this.setStatus("buffering");
        this.emit("onBuffering", true);
      };
      this._onStalled = () => {
        this.setStatus("buffering");
        this.emit("onBuffering", true);
      };
      this._onTimeUpdate = () => {
        if (this.video) {
          this.lastTime = this.video.currentTime || 0;
          this.emit("onTime", {
            currentTime: this.video.currentTime || 0,
            duration: this.video.duration || 0
          });
        }
      };
      this._onEnded = () => {
        this.setStatus("ended");
        this.emit("onEnded", this.currentItem);
      };
      this._onError = () => {
        /* hls.js / mpegts.js report their own errors; ignore the duplicate video error */
        const step = this.plan[this.planIndex];
        if (step && step.mode !== "native" && (this.hls || this.mpegtsPlayer)) return;
        this.handleError(this.getVideoError());
      };

      this.video.addEventListener("loadstart", this._onLoadStart);
      this.video.addEventListener("canplay", this._onCanPlay);
      this.video.addEventListener("playing", this._onPlaying);
      this.video.addEventListener("pause", this._onPause);
      this.video.addEventListener("waiting", this._onWaiting);
      this.video.addEventListener("stalled", this._onStalled);
      this.video.addEventListener("timeupdate", this._onTimeUpdate);
      this.video.addEventListener("ended", this._onEnded);
      this.video.addEventListener("error", this._onError);
    },

    unbindEvents: function () {
      if (!this.video) return;

      this.video.removeEventListener("loadstart", this._onLoadStart);
      this.video.removeEventListener("canplay", this._onCanPlay);
      this.video.removeEventListener("playing", this._onPlaying);
      this.video.removeEventListener("pause", this._onPause);
      this.video.removeEventListener("waiting", this._onWaiting);
      this.video.removeEventListener("stalled", this._onStalled);
      this.video.removeEventListener("timeupdate", this._onTimeUpdate);
      this.video.removeEventListener("ended", this._onEnded);
      this.video.removeEventListener("error", this._onError);
    },

    /* Build the ordered list of playback strategies for a URL */
    buildPlan: function (url) {
      if (!isAndroidApp()) {
        return [{ mode: "native", url: url }];
      }

      const hlsOk = !!(window.Hls && window.Hls.isSupported());
      const tsOk = !!(window.mpegts && window.mpegts.isSupported());
      const plan = [];

      if (isHlsUrl(url)) {
        if (hlsOk) plan.push({ mode: "hls", url: url });
        plan.push({ mode: "native", url: url });
      } else if (isTsUrl(url)) {
        if (isXtreamLiveTs(url) && hlsOk) plan.push({ mode: "hls", url: tsToM3u8(url) });
        if (tsOk) plan.push({ mode: "mpegts", url: url });
        if (!isXtreamLiveTs(url) && hlsOk) plan.push({ mode: "hls", url: url });
        plan.push({ mode: "native", url: url });
      } else {
        plan.push({ mode: "native", url: url });
        if (hlsOk) plan.push({ mode: "hls", url: url });
        if (tsOk) plan.push({ mode: "mpegts", url: url });
      }

      return plan;
    },

    load: function (item, options) {
      options = options || {};

      if (!this.video) {
        throw new Error("PlayerEngine is not initialized");
      }

      if (!item || !(item.url || item.streamUrl)) {
        throw new Error("Stream URL is missing");
      }

      this.currentItem = item;
      this.source = item.url || item.streamUrl;
      this.retryCount = 0;
      this.lastTime = 0;
      this.hasPlayed = false;
      this.autoplay = options.autoplay !== false;

      this.stopRetry();

      this.video.preload = "auto";
      this.video.autoplay = this.autoplay;
      this.video.playsInline = true;
      this.video.setAttribute("playsinline", "true");
      this.video.setAttribute("webkit-playsinline", "true");

      this.plan = this.buildPlan(this.source);
      this.startAttempt(0);

      return true;
    },

    startAttempt: function (index) {
      if (!this.video) return;

      this.teardownEngines();
      this.safeResetVideo();

      this.planIndex = index;
      this.mediaRecoverTried = false;
      const attempt = ++this.attemptId;
      const step = this.plan[index];
      if (!step) return;

      this.setStatus("loading");

      try {
        if (step.mode === "hls") this.startHls(step.url, attempt);
        else if (step.mode === "mpegts") this.startMpegts(step.url, attempt);
        else this.startNative(step.url);
      } catch (e) {
        this.handleError({ type: step.mode, message: e.message || "Player start failed", error: e }, attempt);
      }
    },

    startNative: function (url) {
      this.video.src = url;
      this.video.load();
      if (this.autoplay) this.play().catch(() => {});
    },

    startHls: function (url, attempt) {
      const Hls = window.Hls;
      const config = {
        enableWorker: true,
        lowLatencyMode: false,
        backBufferLength: 30,
        maxBufferLength: 30,
        maxMaxBufferLength: 60,
        manifestLoadingMaxRetry: 2,
        levelLoadingMaxRetry: 2,
        fragLoadingMaxRetry: 4
      };

      const Loader = createHlsLoader();
      if (Loader) config.loader = Loader;

      const hls = new Hls(config);
      this.hls = hls;

      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        if (attempt !== this.attemptId) return;
        if (this.autoplay) this.play().catch(() => {});
      });

      hls.on(Hls.Events.ERROR, (event, data) => {
        if (attempt !== this.attemptId || !data || !data.fatal) return;

        if (data.type === Hls.ErrorTypes.MEDIA_ERROR && !this.mediaRecoverTried) {
          this.mediaRecoverTried = true;
          try {
            hls.recoverMediaError();
            return;
          } catch (e) {}
        }

        this.handleError({
          type: "hls",
          code: data.details || data.type,
          message: "HLS: " + (data.details || data.type || "fatal error"),
          source: url
        }, attempt);
      });

      hls.attachMedia(this.video);
      hls.loadSource(url);
    },

    startMpegts: function (url, attempt) {
      const mpegts = window.mpegts;

      const player = mpegts.createPlayer(
        { type: "mpegts", isLive: true, url: url },
        {
          enableWorker: false,
          lazyLoad: false,
          liveBufferLatencyChasing: true,
          liveBufferLatencyMaxLatency: 6,
          liveBufferLatencyMinRemain: 1.5,
          autoCleanupSourceBuffer: true
        }
      );
      this.mpegtsPlayer = player;

      player.on(mpegts.Events.ERROR, (type, details) => {
        if (attempt !== this.attemptId) return;
        this.handleError({
          type: "mpegts",
          code: details || type,
          message: "MPEG-TS: " + (details || type || "error"),
          source: url
        }, attempt);
      });

      player.attachMediaElement(this.video);
      player.load();
      if (this.autoplay) {
        const p = player.play();
        if (p && typeof p.catch === "function") p.catch(() => {});
      }
    },

    teardownEngines: function () {
      if (this.hls) {
        try { this.hls.destroy(); } catch (e) {}
        this.hls = null;
      }
      if (this.mpegtsPlayer) {
        try { this.mpegtsPlayer.pause(); } catch (e) {}
        try { this.mpegtsPlayer.unload(); } catch (e) {}
        try { this.mpegtsPlayer.detachMediaElement(); } catch (e) {}
        try { this.mpegtsPlayer.destroy(); } catch (e) {}
        this.mpegtsPlayer = null;
      }
    },

    play: function () {
      if (!this.video) return Promise.reject(new Error("Video not initialized"));

      const p = this.video.play();

      if (p && typeof p.catch === "function") {
        return p.catch((err) => {
          if (err && err.name === "AbortError") throw err;
          this.setStatus("blocked");
          this.emit("onError", {
            type: "autoplay",
            message: "Autoplay blocked or stream not ready",
            error: err
          });
          throw err;
        });
      }

      return Promise.resolve();
    },

    pause: function () {
      if (!this.video) return;

      try {
        this.video.pause();
      } catch (e) {}
    },

    togglePlay: function () {
      if (!this.video) return;

      if (this.video.paused) {
        return this.play();
      }

      this.pause();
      return Promise.resolve();
    },

    stop: function () {
      this.stopRetry();
      this.attemptId++;
      this.setStatus("stopped");
      this.teardownEngines();
      this.safeResetVideo();
    },

    safeResetVideo: function () {
      if (!this.video) return;

      try {
        this.video.pause();
      } catch (e) {}

      try {
        this.video.removeAttribute("src");
        this.video.load();
      } catch (e) {}
    },

    handleError: function (errorInfo, attempt) {
      if (attempt !== undefined && attempt !== this.attemptId) return;

      /* Not played yet and another strategy is available -> try it silently */
      if (!this.hasPlayed && this.planIndex + 1 < this.plan.length) {
        this.startAttempt(this.planIndex + 1);
        return;
      }

      this.setStatus("error");
      this.emit("onError", errorInfo || this.getVideoError());

      if (this.retryCount < this.maxRetries && this.source) {
        this.retryCount++;
        this.scheduleRetry();
      }
    },

    scheduleRetry: function () {
      this.stopRetry();

      const delay = Math.min(6000, 1000 + this.retryCount * 1500);
      const index = this.hasPlayed ? this.planIndex : 0;

      this.setStatus("retrying");

      this.retryTimer = setTimeout(() => {
        if (!this.video || !this.source) return;

        try {
          this.startAttempt(index);
        } catch (e) {
          this.emit("onError", {
            type: "retry",
            message: e.message || "Retry failed",
            error: e
          });
        }
      }, delay);
    },

    stopRetry: function () {
      if (this.retryTimer) {
        clearTimeout(this.retryTimer);
        this.retryTimer = null;
      }
    },

    setAspect: function (aspect) {
      this.aspect = aspect || "contain";

      if (this.video) {
        this.video.style.objectFit = this.aspect;
      }

      if (window.StorageCore) {
        StorageCore.setSetting("playerAspect", this.aspect);
      }
    },

    cycleAspect: function () {
      const aspects =
        (window.APP_CONFIG && APP_CONFIG.player && APP_CONFIG.player.aspects) ||
        [
          { id: "contain", label: "Original" },
          { id: "cover", label: "Zoom" },
          { id: "fill", label: "Stretch" }
        ];

      const currentIndex = aspects.findIndex((a) => a.id === this.aspect);
      const nextIndex = currentIndex >= 0 ? (currentIndex + 1) % aspects.length : 0;
      const next = aspects[nextIndex];

      this.setAspect(next.id);

      return next;
    },

    getAspectLabel: function () {
      const aspects =
        (window.APP_CONFIG && APP_CONFIG.player && APP_CONFIG.player.aspects) ||
        [
          { id: "contain", label: "Original" },
          { id: "cover", label: "Zoom" },
          { id: "fill", label: "Stretch" }
        ];

      const found = aspects.find((a) => a.id === this.aspect);
      return found ? found.label : this.aspect;
    },

    getVideoError: function () {
      if (!this.video || !this.video.error) {
        return {
          type: "unknown",
          code: 0,
          message: "Unknown playback error"
        };
      }

      const code = this.video.error.code;
      let message = "Playback error";

      if (code === 1) message = "Playback aborted";
      if (code === 2) message = "Network error";
      if (code === 3) message = "Decode error";
      if (code === 4) message = "Unsupported stream";

      return {
        type: "video",
        code: code,
        message: message,
        source: this.source
      };
    },

    getState: function () {
      if (!this.video) {
        return {
          status: this.status,
          currentTime: 0,
          duration: 0,
          paused: true,
          muted: false,
          volume: 1
        };
      }

      const step = this.plan[this.planIndex];

      return {
        status: this.status,
        currentTime: this.video.currentTime || 0,
        duration: this.video.duration || 0,
        paused: this.video.paused,
        muted: this.video.muted,
        volume: this.video.volume,
        aspect: this.aspect,
        source: this.source,
        engine: step ? step.mode : "native",
        retryCount: this.retryCount
      };
    },

    setStatus: function (status) {
      this.status = status;
      this.emit("onStatus", status);
    },

    emit: function (name, payload) {
      const fn = this.callbacks[name];
      if (typeof fn === "function") {
        try {
          fn(payload);
        } catch (e) {
          console.warn("PlayerEngine callback failed:", name, e);
        }
      }
    },

    destroy: function () {
      this.stopRetry();
      this.attemptId++;

      if (this.bufferingTimer) {
        clearInterval(this.bufferingTimer);
        this.bufferingTimer = null;
      }

      this.teardownEngines();

      if (this.video) {
        this.unbindEvents();
        this.safeResetVideo();
      }

      this.video = null;
      this.source = "";
      this.currentItem = null;
      this.status = "idle";
      this.retryCount = 0;
      this.lastTime = 0;
      this.plan = [];
      this.planIndex = 0;
      this.hasPlayed = false;
    }
  };

  window.PlayerEngine = PlayerEngine;
})();
