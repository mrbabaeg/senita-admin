/* =========================
   Senita TV
   Search Engine Service
   Fast search for Live TV / Movies / Series
   ========================= */

(function () {
  "use strict";

  const SearchEngine = {
    indexes: {
      live: [],
      movie: [],
      series: [],
      all: []
    },

    normalize: function (value) {
      const text = String(value || "")
        .toLowerCase()
        .trim()
        .replace(/[^\p{L}\p{N}\s]/gu, " ")
        .replace(/\s+/g, " ");

      return text;
    },

    tokenize: function (value) {
      const normalized = this.normalize(value);
      if (!normalized) return [];

      return normalized
        .split(" ")
        .filter(function (part) {
          return part.length > 1;
        });
    },

    createSearchText: function (item) {
      item = item || {};

      return this.normalize([
        item.name,
        item.title,
        item.tvgName,
        item.group,
        item.category,
        item.year,
        item.rating,
        item.type,
        item.number
      ].filter(Boolean).join(" "));
    },

    buildIndex: function (type, items) {
      type = type || "all";
      items = Array.isArray(items) ? items : [];

      const indexed = items.map((item, index) => {
        const searchText = this.createSearchText(item);
        const tokens = this.tokenize(searchText);

        return {
          item: item,
          index: index,
          type: item.type || type,
          searchText: searchText,
          tokens: tokens
        };
      });

      this.indexes[type] = indexed;

      this.rebuildAll();

      return indexed;
    },

    rebuildAll: function () {
      this.indexes.all = []
        .concat(this.indexes.live || [])
        .concat(this.indexes.movie || [])
        .concat(this.indexes.series || []);
    },

    buildFromPlaylist: function () {
      let live = [];
      let movies = [];
      let series = [];

      try {
        if (window.PlaylistManager) {
          live = PlaylistManager.getActiveLiveChannels() || [];

          const vod = PlaylistManager.getActiveVod();
          movies = vod.movies || [];
          series = vod.series || [];
        }
      } catch (e) {
        live = [];
        movies = [];
        series = [];
      }

      this.buildIndex("live", live);
      this.buildIndex("movie", movies);
      this.buildIndex("series", series);

      return {
        live: live.length,
        movie: movies.length,
        series: series.length,
        all: this.indexes.all.length
      };
    },

    search: function (query, options) {
      options = options || {};

      const type = options.type || "all";
      const limit = Number(options.limit || 60);
      const includeScore = options.includeScore === true;

      const q = this.normalize(query);

      if (!q) return [];

      const queryTokens = this.tokenize(q);
      const source = this.indexes[type] || this.indexes.all || [];

      const results = [];

      for (let i = 0; i < source.length; i++) {
        const row = source[i];
        const score = this.score(row, q, queryTokens);

        if (score > 0) {
          if (includeScore) {
            results.push({
              item: row.item,
              score: score,
              index: row.index,
              type: row.type
            });
          } else {
            results.push(row.item);
          }
        }
      }

      results.sort(function (a, b) {
        const sa = includeScore ? a.score : 0;
        const sb = includeScore ? b.score : 0;

        if (includeScore) return sb - sa;

        const an = String(a.name || a.title || "");
        const bn = String(b.name || b.title || "");

        return an.localeCompare(bn);
      });

      return results.slice(0, limit);
    },

    score: function (row, query, queryTokens) {
      if (!row || !row.searchText) return 0;

      const text = row.searchText;

      if (text === query) return 1000;
      if (text.startsWith(query)) return 850;
      if (text.includes(query)) return 700;

      let tokenScore = 0;

      for (let i = 0; i < queryTokens.length; i++) {
        const q = queryTokens[i];

        if (row.tokens.indexOf(q) >= 0) {
          tokenScore += 120;
          continue;
        }

        for (let t = 0; t < row.tokens.length; t++) {
          const token = row.tokens[t];

          if (token.startsWith(q)) {
            tokenScore += 80;
            break;
          }

          if (token.includes(q)) {
            tokenScore += 40;
            break;
          }

          if (this.levenshteinLite(token, q) <= 1 && q.length >= 4) {
            tokenScore += 35;
            break;
          }
        }
      }

      return tokenScore;
    },

    levenshteinLite: function (a, b) {
      a = String(a || "");
      b = String(b || "");

      const al = a.length;
      const bl = b.length;

      if (Math.abs(al - bl) > 2) return 99;
      if (a === b) return 0;
      if (!al) return bl;
      if (!bl) return al;

      const matrix = [];

      for (let i = 0; i <= bl; i++) matrix[i] = [i];
      for (let j = 0; j <= al; j++) matrix[0][j] = j;

      for (let i = 1; i <= bl; i++) {
        for (let j = 1; j <= al; j++) {
          if (b.charAt(i - 1) === a.charAt(j - 1)) {
            matrix[i][j] = matrix[i - 1][j - 1];
          } else {
            matrix[i][j] = Math.min(
              matrix[i - 1][j - 1] + 1,
              matrix[i][j - 1] + 1,
              matrix[i - 1][j] + 1
            );
          }
        }
      }

      return matrix[bl][al];
    },

    searchLive: function (query, limit) {
      return this.search(query, {
        type: "live",
        limit: limit || 60
      });
    },

    searchMovies: function (query, limit) {
      return this.search(query, {
        type: "movie",
        limit: limit || 60
      });
    },

    searchSeries: function (query, limit) {
      return this.search(query, {
        type: "series",
        limit: limit || 60
      });
    },

    searchAll: function (query, limit) {
      return this.search(query, {
        type: "all",
        limit: limit || 80
      });
    },

    clear: function () {
      this.indexes.live = [];
      this.indexes.movie = [];
      this.indexes.series = [];
      this.indexes.all = [];
    },

    stats: function () {
      return {
        live: this.indexes.live.length,
        movie: this.indexes.movie.length,
        series: this.indexes.series.length,
        all: this.indexes.all.length
      };
    }
  };

  window.SearchEngine = SearchEngine;
})();
