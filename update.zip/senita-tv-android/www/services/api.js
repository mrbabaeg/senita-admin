/* =========================
   Senita TV
   API Service
   M3U / Xtream Codes helpers
   ========================= */

(function () {
  "use strict";

  const ApiService = {
    defaultTimeout: 18000,

    buildUrl: function (base, params) {
      const url = new URL(base);

      Object.keys(params || {}).forEach(function (key) {
        const value = params[key];

        if (value !== undefined && value !== null && value !== "") {
          url.searchParams.set(key, value);
        }
      });

      return url.toString();
    },

    normalizeServer: function (server) {
      let value = String(server || "").trim();

      if (!value) {
        throw new Error("Server URL is empty");
      }

      if (!/^https?:\/\//i.test(value)) {
        value = "http://" + value;
      }

      value = value.replace(/\/+$/, "");

      return value;
    },

    fetchText: async function (url, options) {
      options = options || {};

      const controller = new AbortController();
      const timeout = setTimeout(function () {
        controller.abort();
      }, options.timeout || this.defaultTimeout);

      try {
        const response = await fetch(url, {
          method: options.method || "GET",
          cache: options.cache || "no-store",
          headers: options.headers || {},
          signal: controller.signal
        });

        if (!response.ok) {
          throw new Error("HTTP " + response.status);
        }

        return await response.text();
      } catch (err) {
        if (err && err.name === "AbortError") {
          throw new Error("Request timeout");
        }

        throw err;
      } finally {
        clearTimeout(timeout);
      }
    },

    fetchJson: async function (url, options) {
      const text = await this.fetchText(url, options);

      try {
        return JSON.parse(text);
      } catch (e) {
        throw new Error("Invalid JSON response");
      }
    },

    fetchM3U: async function (url) {
      if (!this.isHttpUrl(url)) {
        throw new Error("Invalid M3U URL");
      }

      return await this.fetchText(url, {
        timeout: this.defaultTimeout
      });
    },

    isHttpUrl: function (value) {
      try {
        const url = new URL(String(value || "").trim());
        return url.protocol === "http:" || url.protocol === "https:";
      } catch (e) {
        return false;
      }
    },

    xtream: {
      buildPlayerApiUrl: function (server, username, password, action, extra) {
        const normalized = ApiService.normalizeServer(server);

        return ApiService.buildUrl(normalized + "/player_api.php", Object.assign({
          username: username,
          password: password,
          action: action || ""
        }, extra || {}));
      },

      buildM3UUrl: function (server, username, password, type) {
        const normalized = ApiService.normalizeServer(server);

        return ApiService.buildUrl(normalized + "/get.php", {
          username: username,
          password: password,
          type: "m3u_plus",
          output: type || "ts"
        });
      },

      getAccountInfo: async function (server, username, password) {
        const url = this.buildPlayerApiUrl(server, username, password, "");
        return await ApiService.fetchJson(url);
      },

      getLiveCategories: async function (server, username, password) {
        const url = this.buildPlayerApiUrl(server, username, password, "get_live_categories");
        return await ApiService.fetchJson(url);
      },

      getLiveStreams: async function (server, username, password, categoryId) {
        const url = this.buildPlayerApiUrl(server, username, password, "get_live_streams", {
          category_id: categoryId || ""
        });

        return await ApiService.fetchJson(url);
      },

      getVodCategories: async function (server, username, password) {
        const url = this.buildPlayerApiUrl(server, username, password, "get_vod_categories");
        return await ApiService.fetchJson(url);
      },

      getVodStreams: async function (server, username, password, categoryId) {
        const url = this.buildPlayerApiUrl(server, username, password, "get_vod_streams", {
          category_id: categoryId || ""
        });

        return await ApiService.fetchJson(url);
      },

      getSeriesCategories: async function (server, username, password) {
        const url = this.buildPlayerApiUrl(server, username, password, "get_series_categories");
        return await ApiService.fetchJson(url);
      },

      getSeries: async function (server, username, password, categoryId) {
        const url = this.buildPlayerApiUrl(server, username, password, "get_series", {
          category_id: categoryId || ""
        });

        return await ApiService.fetchJson(url);
      },

      buildLiveStreamUrl: function (server, username, password, streamId, extension) {
        const normalized = ApiService.normalizeServer(server);
        return normalized + "/live/" + encodeURIComponent(username) + "/" + encodeURIComponent(password) + "/" + encodeURIComponent(streamId) + "." + (extension || "ts");
      },

      buildMovieStreamUrl: function (server, username, password, streamId, extension) {
        const normalized = ApiService.normalizeServer(server);
        return normalized + "/movie/" + encodeURIComponent(username) + "/" + encodeURIComponent(password) + "/" + encodeURIComponent(streamId) + "." + (extension || "mp4");
      },

      buildSeriesStreamUrl: function (server, username, password, streamId, extension) {
        const normalized = ApiService.normalizeServer(server);
        return normalized + "/series/" + encodeURIComponent(username) + "/" + encodeURIComponent(password) + "/" + encodeURIComponent(streamId) + "." + (extension || "mp4");
      },

      normalizeLiveStream: function (raw, server, username, password) {
        raw = raw || {};

        return {
          id: "xt_live_" + (raw.stream_id || raw.num || Math.random()),
          type: "live",
          number: Number(raw.num || raw.stream_id || 0),
          name: raw.name || "Live Channel",
          tvgId: raw.epg_channel_id || "",
          tvgName: raw.name || "",
          logo: raw.stream_icon || "",
          group: raw.category_name || raw.category_id || "Live",
          url: this.buildLiveStreamUrl(server, username, password, raw.stream_id, raw.container_extension || "ts"),
          streamId: raw.stream_id,
          categoryId: raw.category_id || ""
        };
      },

      normalizeVodStream: function (raw, server, username, password) {
        raw = raw || {};

        return {
          id: "xt_movie_" + (raw.stream_id || raw.num || Math.random()),
          type: "movie",
          number: Number(raw.num || raw.stream_id || 0),
          name: raw.name || "Movie",
          logo: raw.stream_icon || "",
          poster: raw.stream_icon || "",
          group: raw.category_name || raw.category_id || "Movies",
          year: raw.year || "",
          rating: raw.rating || "",
          plot: raw.plot || "",
          url: this.buildMovieStreamUrl(server, username, password, raw.stream_id, raw.container_extension || "mp4"),
          streamId: raw.stream_id,
          categoryId: raw.category_id || ""
        };
      },

      normalizeSeries: function (raw) {
        raw = raw || {};

        return {
          id: "xt_series_" + (raw.series_id || raw.num || Math.random()),
          type: "series",
          number: Number(raw.num || raw.series_id || 0),
          name: raw.name || "Series",
          logo: raw.cover || "",
          poster: raw.cover || "",
          group: raw.category_name || raw.category_id || "Series",
          year: raw.releaseDate ? String(raw.releaseDate).slice(0, 4) : "",
          rating: raw.rating || "",
          plot: raw.plot || "",
          url: "",
          seriesId: raw.series_id,
          categoryId: raw.category_id || ""
        };
      }
    },

    testConnection: async function (source) {
      source = source || {};

      if (source.type === "m3u") {
        const text = await this.fetchM3U(source.url);
        return {
          ok: true,
          type: "m3u",
          length: text.length
        };
      }

      if (source.type === "xtream") {
        const info = await this.xtream.getAccountInfo(
          source.server,
          source.username,
          source.password
        );

        return {
          ok: true,
          type: "xtream",
          info: info
        };
      }

      throw new Error("Unsupported source type");
    }
  };

  window.ApiService = ApiService;
})();
