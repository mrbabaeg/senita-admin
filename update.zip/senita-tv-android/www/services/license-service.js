/* =====================================================================
   Senita TV — Lisenziya xidməti (virtual MAC + cihaz açarı)
   ---------------------------------------------------------------------
   - Cihaz üçün sabit virtual MAC (məs. 3A:7F:C2:91:0B:E4) və 6 rəqəmli açar yaradır.
   - Supabase-də check_device funksiyasını çağırır.
   - Status aktiv deyilsə tam ekran "blok" pəncərəsi göstərir.
     Playlistlər, favoritlər və "Davam et" toxunulmur, blok açılan kimi
     tətbiq qaldığı yerdən davam edir.
   - Oflayn: son "aktiv" yoxlamadan sonra 3 gün işləyir.

   Server ayarları: www/js/config.js → APP_CONFIG.license { url, anonKey }.
   Boş qalsa lisenziya sistemi SÖNÜLÜDÜR (tətbiq blok olmadan işləyir).

   İstifadə (app.js-də, tətbiq açılanda):
     MrbLicense.start({ version: '1.2.0', platform: isTv ? 'tv' : 'phone', lang: 'az' });
   Ayarlar səhifəsi üçün:
     MrbLicense.getIdentity()  -> { mac, key }
     MrbLicense.getState()     -> { status, expires_at, last_day, customer_no, checkedAt, online }
     MrbLicense.onChange(fn)
   Blok ekranı açıq olanda pult/klaviatura düymələri tətbiqə ötürülmür
   (window capture fazasında tutulur); Back = tətbiqdən çıxış.
   ===================================================================== */
(function (global) {
  'use strict';

  var LIC = (global.APP_CONFIG && global.APP_CONFIG.license) || {};
  var CONFIG = {
    SUPABASE_URL: String(LIC.url || '').trim(),
    SUPABASE_ANON_KEY: String(LIC.anonKey || '').trim(),
    SALT: 'mrbabayev-player-license-v1',                 // dəyişmə — dəyişsə bütün MAC-lar dəyişər
    GRACE_MS: 3 * 24 * 3600 * 1000,   // oflayn icazə: 3 gün
    RECHECK_MS: 3600 * 1000,          // aktiv olanda hər 1 saatdan bir yoxla
    RESUME_RECHECK_MS: 15 * 60 * 1000, // fondan qayıdanda: son yoxlamadan 15 dəq keçibsə yoxla
    LOCKED_RECHECK_MS: 60 * 1000,     // bloklu ekranda hər 1 dəqiqədən bir yoxla
    TICK_MS: 60 * 1000,
    TIMEOUT_MS: 12000
  };

  var LS_CACHE = 'mrb_license_cache_v1';
  var LS_FALLBACK_ID = 'mrb_license_fallback_id_v1';

  var TEXT = {
    az: {
      app: 'Senita TV',
      checking: 'Yoxlanılır…',
      pending_t: 'Cihaz aktiv deyil',
      pending_d: 'Tətbiqi aktivləşdirmək üçün aşağıdakı MAC kodunu satıcıya bildirin.',
      expired_t: 'Abunə müddəti bitib',
      expired_d: 'Aylıq ödəniş edilməyib. Ödənişdən sonra "Yenidən yoxla" düyməsini basın. Playlistləriniz və favoritləriniz yerində qalır.',
      blocked_t: 'Cihaz bloklanıb',
      blocked_d: 'Ətraflı məlumat üçün satıcıya müraciət edin.',
      offline_t: 'Serverlə əlaqə yoxdur',
      offline_d: 'Abunə 3 gündən çoxdur yoxlanılmayıb. İnterneti yoxlayıb yenidən cəhd edin.',
      unknown_t: 'İnternet bağlantısı yoxdur',
      unknown_d: 'İlk açılışda cihazı yoxlamaq üçün internet lazımdır.',
      mismatch_t: 'Cihaz açarı uyğun gəlmir',
      mismatch_d: 'Satıcıya MAC kodunu göndərin ki, açarı sıfırlasın.',
      mac: 'MAC', key: 'Cihaz açarı',
      retry: 'Yenidən yoxla', exit: 'Çıxış',
      last: 'Son yoxlama', never: 'heç vaxt',
      expires: 'Son gün',
      cid: 'Müştəri ID'
    },
    en: {
      app: 'Senita TV',
      checking: 'Checking…',
      pending_t: 'Device not activated',
      pending_d: 'Send the MAC code below to your reseller to activate the app.',
      expired_t: 'Subscription expired',
      expired_d: 'The monthly payment has not been made. After payment, press "Check again". Your playlists and favorites are kept.',
      blocked_t: 'Device blocked',
      blocked_d: 'Please contact your reseller.',
      offline_t: 'Cannot reach server',
      offline_d: 'The subscription has not been verified for more than 3 days. Check your internet and try again.',
      unknown_t: 'No internet connection',
      unknown_d: 'An internet connection is required to verify this device on first launch.',
      mismatch_t: 'Device key mismatch',
      mismatch_d: 'Send the MAC code to your reseller to reset the key.',
      mac: 'MAC', key: 'Device key',
      retry: 'Check again', exit: 'Exit',
      last: 'Last check', never: 'never',
      expires: 'Last day',
      cid: 'Customer ID'
    },
    ru: {
      app: 'Senita TV',
      checking: 'Проверка…',
      pending_t: 'Устройство не активировано',
      pending_d: 'Отправьте MAC-код ниже продавцу для активации приложения.',
      expired_t: 'Подписка истекла',
      expired_d: 'Ежемесячная оплата не внесена. После оплаты нажмите «Проверить снова». Ваши плейлисты и избранное сохранены.',
      blocked_t: 'Устройство заблокировано',
      blocked_d: 'Обратитесь к продавцу.',
      offline_t: 'Нет связи с сервером',
      offline_d: 'Подписка не проверялась более 3 дней. Проверьте интернет и повторите попытку.',
      unknown_t: 'Нет подключения к интернету',
      unknown_d: 'Для первой проверки устройства нужен интернет.',
      mismatch_t: 'Ключ устройства не совпадает',
      mismatch_d: 'Отправьте MAC-код продавцу, чтобы он сбросил ключ.',
      mac: 'MAC', key: 'Ключ устройства',
      retry: 'Проверить снова', exit: 'Выход',
      last: 'Последняя проверка', never: 'никогда',
      expires: 'Последний день',
      cid: 'ID клиента'
    }
  };

  function isConfigured() {
    return /^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(CONFIG.SUPABASE_URL) && CONFIG.SUPABASE_ANON_KEY.length > 20;
  }

  var KNOWN = ['active', 'pending', 'expired', 'blocked', 'key_mismatch', 'invalid'];

  var state = {
    ident: null,
    cache: null,
    online: null,
    checking: false,
    inflight: null,
    focusIdx: 0,
    lang: 'az',
    opts: {},
    timer: null,
    listeners: [],
    gate: null,
    shownStatus: null,
    disabled: false,
    started: false
  };

  /* ---------------- storage ---------------- */
  function lsGet(k) { try { return global.localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { global.localStorage.setItem(k, v); } catch (e) { /* ignore */ } }
  function loadCache() {
    try { var c = JSON.parse(lsGet(LS_CACHE) || 'null'); return c && c.status ? c : null; } catch (e) { return null; }
  }
  function saveCache(c) { lsSet(LS_CACHE, JSON.stringify(c)); }

  /* ---------------- SHA-256 (sinxron, kitabxanasız) ---------------- */
  var K256 = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
  ];
  function ror(x, n) { return (x >>> n) | (x << (32 - n)); }
  function utf8Bytes(str) {
    var s = unescape(encodeURIComponent(str)), out = [];
    for (var i = 0; i < s.length; i++) out.push(s.charCodeAt(i));
    return out;
  }
  function sha256(bytes) {
    var H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
    var bitLen = bytes.length * 8;
    var m = bytes.slice();
    m.push(0x80);
    while ((m.length % 64) !== 56) m.push(0);
    m.push(0, 0, 0, 0, (bitLen >>> 24) & 255, (bitLen >>> 16) & 255, (bitLen >>> 8) & 255, bitLen & 255);
    var W = new Array(64);
    for (var off = 0; off < m.length; off += 64) {
      var t;
      for (t = 0; t < 16; t++) {
        W[t] = (m[off + 4 * t] << 24) | (m[off + 4 * t + 1] << 16) | (m[off + 4 * t + 2] << 8) | m[off + 4 * t + 3];
      }
      for (t = 16; t < 64; t++) {
        var x = W[t - 15], y = W[t - 2];
        var s0 = ror(x, 7) ^ ror(x, 18) ^ (x >>> 3);
        var s1 = ror(y, 17) ^ ror(y, 19) ^ (y >>> 10);
        W[t] = (W[t - 16] + s0 + W[t - 7] + s1) | 0;
      }
      var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (t = 0; t < 64; t++) {
        var S1 = ror(e, 6) ^ ror(e, 11) ^ ror(e, 25);
        var ch = (e & f) ^ (~e & g);
        var t1 = (h + S1 + ch + K256[t] + W[t]) | 0;
        var S0 = ror(a, 2) ^ ror(a, 13) ^ ror(a, 22);
        var mj = (a & b) ^ (a & c) ^ (b & c);
        var t2 = (S0 + mj) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
      H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
    }
    var out = [];
    for (var i = 0; i < 8; i++) out.push((H[i] >>> 24) & 255, (H[i] >>> 16) & 255, (H[i] >>> 8) & 255, H[i] & 255);
    return out;
  }

  /* ---------------- cihaz kimliyi ---------------- */
  function randomHex(n) {
    var out = '';
    try {
      var arr = new Uint8Array(n);
      global.crypto.getRandomValues(arr);
      for (var i = 0; i < n; i++) out += ('0' + arr[i].toString(16)).slice(-2);
      return out;
    } catch (e) {
      for (var j = 0; j < n * 2; j++) out += Math.floor(Math.random() * 16).toString(16);
      return out;
    }
  }

  function getPlugin() {
    var C = global.Capacitor;
    return (C && C.Plugins && C.Plugins.MrbDevice) || null;
  }

  // ANDROID_ID: eyni cihazda + eyni imza ilə sabitdir (tətbiq silinib yenidən qurulsa da)
  async function getRawDevice() {
    var P = getPlugin();
    var model = '';
    if (P && typeof P.getDeviceId === 'function') {
      try {
        var r = await P.getDeviceId();
        model = r && r.model ? String(r.model) : '';
        if (r && r.id && r.id !== '9774d56d682e549c') return { raw: 'a:' + r.id, model: model }; // köhnə emulyator ID-si istisna
      } catch (e) { /* fallback */ }
    }
    var f = lsGet(LS_FALLBACK_ID);
    if (!f) { f = 'r:' + randomHex(16); lsSet(LS_FALLBACK_ID, f); }
    return { raw: f, model: model };
  }

  function deriveIdentity(raw) {
    var h = sha256(utf8Bytes(CONFIG.SALT + '|' + raw));
    var b = h.slice(0, 6);
    b[0] = (b[0] & 0xFC) | 0x02; // "locally administered" MAC
    var mac = b.map(function (x) { return ('0' + x.toString(16)).slice(-2); }).join(':').toUpperCase();
    var n = ((h[6] << 24) >>> 0) + (h[7] << 16) + (h[8] << 8) + h[9];
    var key = ('00000' + (n % 1000000)).slice(-6);
    return { mac: mac, key: key };
  }

  /* ---------------- server ---------------- */
  function withTimeout(promise, ms) {
    return new Promise(function (resolve, reject) {
      var t = setTimeout(function () { reject(new Error('timeout')); }, ms);
      promise.then(function (v) { clearTimeout(t); resolve(v); }, function (e) { clearTimeout(t); reject(e); });
    });
  }

  async function remoteCheck() {
    var headers = {
      'apikey': CONFIG.SUPABASE_ANON_KEY,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
    // Köhnə "anon" açarı JWT-dir (eyJ...) və Bearer kimi də göndərilir.
    // Yeni "publishable" açar (sb_publishable_...) yalnız apikey başlığında gedir.
    if (CONFIG.SUPABASE_ANON_KEY.indexOf('eyJ') === 0) headers['Authorization'] = 'Bearer ' + CONFIG.SUPABASE_ANON_KEY;
    var res = await withTimeout(fetch(CONFIG.SUPABASE_URL.replace(/\/+$/, '') + '/rest/v1/rpc/check_device', {
      method: 'POST',
      headers: headers,
      body: JSON.stringify({
        p_mac: state.ident.mac,
        p_key: state.ident.key,
        p_platform: state.opts.platform || null,
        p_model: state.ident.model || null,
        p_version: state.opts.version || null
      })
    }), CONFIG.TIMEOUT_MS);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    var data = await res.json();
    if (typeof data === 'string') data = JSON.parse(data);
    if (!data || KNOWN.indexOf(data.status) < 0) throw new Error('bad response');
    return data;
  }

  /* ---------------- status hesabı ---------------- */
  function evaluate() {
    var c = state.cache;
    if (!c) return { status: 'unknown' };
    var now = Date.now();
    var st = c.status;
    if (st === 'active') {
      var serverNow = now + (c.offset || 0);
      if (c.expires_at && Date.parse(c.expires_at) <= serverNow) {
        st = 'expired';
      } else if (state.online === false || state.online === null) {
        var age = now - c.checkedAt;
        // saat geri çəkilibsə və ya 3 gün keçibsə — yoxlama tələb et
        if (age > CONFIG.GRACE_MS || age < -10 * 60 * 1000) st = 'offline';
      }
    }
    if (st === 'invalid') st = 'key_mismatch';
    return { status: st, expires_at: c.expires_at || null, message: c.message || null, checkedAt: c.checkedAt, customer_no: c.customer_no != null ? c.customer_no : null };
  }

  function refresh() {
    if (!state.ident) return Promise.resolve(getState());
    if (state.inflight) return state.inflight;
    state.inflight = doRefresh().then(function () { state.inflight = null; return getState(); });
    return state.inflight;
  }

  async function doRefresh() {
    state.checking = true;
    renderGate();
    try {
      var r = await remoteCheck();
      var serverTime = r.server_time ? Date.parse(r.server_time) : NaN;
      state.cache = {
        status: r.status,
        expires_at: r.expires_at || null,
        message: r.message || null,
        customer_no: r.customer_no != null ? r.customer_no : null,
        checkedAt: Date.now(),
        offset: isNaN(serverTime) ? 0 : serverTime - Date.now()
      };
      saveCache(state.cache);
      state.online = true;
    } catch (e) {
      state.online = false;
    } finally {
      state.checking = false;
    }
    apply();
  }

  function apply() {
    var res = evaluate();
    if (res.status === 'active') hideGate();
    else showGate(res);
    var snapshot = getState();
    state.listeners.slice().forEach(function (fn) { try { fn(snapshot); } catch (e) { /* ignore */ } });
  }

  function tick() {
    var res = evaluate();
    var c = state.cache;
    var since = c ? Date.now() - c.checkedAt : Infinity;
    var limit = res.status === 'active' ? CONFIG.RECHECK_MS : CONFIG.LOCKED_RECHECK_MS;
    if (since >= limit || since < 0) refresh();
    else apply();
  }

  // TV/telefon fondan qayıdanda (və ya ekran yenidən açılanda)
  function onResume() {
    var c = state.cache;
    var since = c ? Date.now() - c.checkedAt : Infinity;
    if (since >= CONFIG.RESUME_RECHECK_MS || since < 0 || evaluate().status !== 'active') refresh();
    else apply();
  }

  /* ---------------- blok ekranı ---------------- */
  function t(k) { return (TEXT[state.lang] || TEXT.az)[k] || TEXT.az[k] || k; }

  function injectStyles() {
    if (document.getElementById('mrb-license-style')) return;
    var css = '' +
      '#mrb-license-gate{position:fixed;inset:0;z-index:2147483646;display:flex;align-items:center;justify-content:center;' +
      'background:radial-gradient(120% 90% at 50% 0%,#1d2340 0%,#0b0e1a 60%,#06070d 100%);color:#eef1fa;' +
      'font-family:Montserrat,"Noto Sans",system-ui,sans-serif;padding:24px;box-sizing:border-box;overflow:auto}' +
      '#mrb-license-gate *{box-sizing:border-box}' +
      '.mlg-card{width:100%;max-width:560px;text-align:center}' +
      '.mlg-brand{font-weight:700;letter-spacing:.04em;font-size:15px;color:#9aa6d6;margin-bottom:22px;text-transform:uppercase}' +
      '.mlg-icon{width:64px;height:64px;border-radius:50%;margin:0 auto 18px;display:flex;align-items:center;justify-content:center;font-size:30px;font-weight:700}' +
      '.mlg-icon.wait{background:rgba(255,196,77,.15);color:#ffc44d}' +
      '.mlg-icon.bad{background:rgba(255,92,92,.15);color:#ff6b6b}' +
      '.mlg-icon.info{background:rgba(120,150,255,.15);color:#8fa8ff}' +
      '.mlg-title{font-size:24px;font-weight:700;margin:0 0 10px}' +
      '.mlg-desc{font-size:15px;line-height:1.5;color:#b8c0dc;margin:0 auto 22px;max-width:460px}' +
      '.mlg-msg{font-size:14px;color:#ffb3b3;margin:-10px auto 18px}' +
      '.mlg-codes{display:grid;grid-template-columns:1fr;gap:10px;margin-bottom:22px}' +
      '.mlg-code{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:14px;padding:14px 16px}' +
      '.mlg-code small{display:block;font-size:12px;color:#8e97b8;text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px}' +
      '.mlg-code b{display:block;font-family:"Noto Sans Mono",ui-monospace,Menlo,Consolas,monospace;font-size:26px;letter-spacing:.06em;color:#fff;word-break:break-all;user-select:text;-webkit-user-select:text}' +
      '.mlg-btns{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}' +
      '.mlg-btn{min-width:160px;padding:14px 22px;border-radius:12px;border:2px solid transparent;font:inherit;font-size:16px;font-weight:600;cursor:pointer;outline:none}' +
      '.mlg-btn.primary{background:#4f6bff;color:#fff}' +
      '.mlg-btn.ghost{background:rgba(255,255,255,.08);color:#dfe4f5}' +
      '.mlg-btn:focus,.mlg-btn.focused{border-color:#fff;box-shadow:0 0 0 4px rgba(79,107,255,.45);transform:scale(1.04)}' +
      '.mlg-btn[disabled]{opacity:.6}' +
      '.mlg-foot{margin-top:18px;font-size:12px;color:#7d86a8}' +
      '.mlg-cid{grid-column:1/-1}.mlg-cid b{color:#ffc44d}' +
      '@media (min-width:900px){.mlg-codes{grid-template-columns:1fr 1fr}.mlg-code b{font-size:30px}.mlg-title{font-size:30px}.mlg-desc{font-size:17px}}' +
      'html.is-tv #mrb-license-gate{padding:60px}' +
      'html.is-tv .mlg-card{max-width:1200px}' +
      'html.is-tv .mlg-brand{font-size:24px;margin-bottom:36px}' +
      'html.is-tv .mlg-icon{width:110px;height:110px;font-size:52px;margin-bottom:28px}' +
      'html.is-tv .mlg-title{font-size:56px;margin-bottom:18px}' +
      'html.is-tv .mlg-desc{font-size:28px;max-width:1000px;margin-bottom:36px}' +
      'html.is-tv .mlg-msg{font-size:26px}' +
      'html.is-tv .mlg-codes{grid-template-columns:1.4fr 1fr;gap:18px;margin-bottom:36px}' +
      'html.is-tv .mlg-code{padding:22px 26px;border-radius:20px}' +
      'html.is-tv .mlg-code small{font-size:20px;margin-bottom:10px}' +
      'html.is-tv .mlg-code b{font-size:52px}' +
      'html.is-tv .mlg-btns{gap:22px}' +
      'html.is-tv .mlg-btn{min-width:300px;padding:22px 34px;font-size:28px;border-radius:16px;border-width:4px}' +
      'html.is-tv .mlg-foot{font-size:22px;margin-top:26px}';
    var st = document.createElement('style');
    st.id = 'mrb-license-style';
    st.textContent = css;
    document.head.appendChild(st);
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function fmtDateTime(ms) {
    if (!ms) return t('never');
    try {
      var loc = state.lang === 'ru' ? 'ru-RU' : state.lang === 'en' ? 'en-GB' : 'az-AZ';
      return new Date(ms).toLocaleString(loc, { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    } catch (e) { return new Date(ms).toISOString().slice(0, 16).replace('T', ' '); }
  }

  // Bitmə anı növbəti günün 00:00-ıdır; ekranda "son gün" göstərilir
  function fmtLastDay(iso) {
    var ms = Date.parse(iso) - 1;
    if (isNaN(ms)) return '';
    try {
      var loc = state.lang === 'ru' ? 'ru-RU' : state.lang === 'en' ? 'en-GB' : 'az-AZ';
      return new Date(ms).toLocaleDateString(loc, { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Baku' });
    } catch (e) {
      var d = new Date(ms + 4 * 3600 * 1000);
      return ('0' + d.getUTCDate()).slice(-2) + '.' + ('0' + (d.getUTCMonth() + 1)).slice(-2) + '.' + d.getUTCFullYear();
    }
  }

  function pauseMedia() {
    try { document.querySelectorAll('video,audio').forEach(function (v) { try { v.pause(); } catch (e) { /* ignore */ } }); } catch (e) { /* ignore */ }
    try { if (global.PlayerEngine && typeof global.PlayerEngine.pause === 'function') global.PlayerEngine.pause(); } catch (e) { /* ignore */ }
  }

  function showGate(res) {
    injectStyles();
    if (!state.gate) {
      state.gate = document.createElement('div');
      state.gate.id = 'mrb-license-gate';
      state.gate.setAttribute('role', 'dialog');
      state.gate.setAttribute('aria-modal', 'true');
      document.body.appendChild(state.gate);
      global.addEventListener('keydown', onKey, true);
      global.addEventListener('keyup', swallowKey, true);
      pauseMedia();
      document.documentElement.classList.add('mrb-license-locked');
    }
    state.shownStatus = res.status;
    renderGate();
  }

  function hideGate() {
    if (!state.gate) return;
    global.removeEventListener('keydown', onKey, true);
    global.removeEventListener('keyup', swallowKey, true);
    state.gate.remove();
    state.gate = null;
    state.focusIdx = 0;
    state.shownStatus = null;
    document.documentElement.classList.remove('mrb-license-locked');
  }

  function renderGate() {
    if (!state.gate) return;
    var res = evaluate();
    var map = {
      pending: ['pending_t', 'pending_d', 'wait', '!'],
      expired: ['expired_t', 'expired_d', 'wait', '⏱'],
      blocked: ['blocked_t', 'blocked_d', 'bad', '✕'],
      offline: ['offline_t', 'offline_d', 'info', '⟳'],
      unknown: ['unknown_t', 'unknown_d', 'info', '⟳'],
      key_mismatch: ['mismatch_t', 'mismatch_d', 'bad', '!']
    };
    var m = map[res.status] || map.unknown;
    var title = state.checking && !state.cache ? t('checking') : t(m[0]);
    var expires = res.expires_at && res.status === 'expired'
      ? '<div class="mlg-foot">' + esc(t('expires')) + ': ' + esc(fmtLastDay(res.expires_at)) + '</div>' : '';
    var cidBox = res.customer_no != null
      ? '<div class="mlg-code mlg-cid"><small>' + esc(t('cid')) + '</small><b>#' + esc(res.customer_no) + '</b></div>' : '';

    state.gate.innerHTML =
      '<div class="mlg-card">' +
        '<div class="mlg-brand" lang="en">' + esc(t('app')) + '</div>' +
        '<div class="mlg-icon ' + m[2] + '">' + m[3] + '</div>' +
        '<h1 class="mlg-title">' + esc(title) + '</h1>' +
        '<p class="mlg-desc">' + esc(t(m[1])) + '</p>' +
        (res.status === 'blocked' && res.message ? '<p class="mlg-msg">' + esc(res.message) + '</p>' : '') +
        '<div class="mlg-codes">' +
          cidBox +
          '<div class="mlg-code"><small>' + esc(t('mac')) + '</small><b>' + esc(state.ident ? state.ident.mac : '—') + '</b></div>' +
          '<div class="mlg-code"><small>' + esc(t('key')) + '</small><b>' + esc(state.ident ? state.ident.key : '—') + '</b></div>' +
        '</div>' +
        '<div class="mlg-btns">' +
          '<button class="mlg-btn primary" data-i="0" data-act="retry"' + (state.checking ? ' disabled' : '') + '>' +
            esc(state.checking ? t('checking') : t('retry')) + '</button>' +
          '<button class="mlg-btn ghost" data-i="1" data-act="exit">' + esc(t('exit')) + '</button>' +
        '</div>' +
        expires +
        '<div class="mlg-foot">' + esc(t('last')) + ': ' + esc(fmtDateTime(res.checkedAt)) + '</div>' +
      '</div>';

    state.gate.querySelectorAll('.mlg-btn').forEach(function (btn) {
      btn.addEventListener('click', function () { act(btn.getAttribute('data-act')); });
    });
    var btns = state.gate.querySelectorAll('.mlg-btn');
    // İstifadəçinin seçdiyi düymə (standart: "Yenidən yoxla"); söndürülübsə müvəqqəti digərinə
    var want = btns[state.focusIdx] || btns[0];
    var target = want.disabled ? btns[1 - state.focusIdx] || btns[1] : want;
    try { target.focus({ preventScroll: true }); } catch (e) { target.focus(); }
  }

  function act(a) {
    if (a === 'retry') refresh();
    else if (a === 'exit') exitApp();
  }

  function exitApp() {
    try { if (global.AndroidBridge && global.AndroidBridge.exitApp && global.AndroidBridge.exitApp()) return; } catch (e) { /* ignore */ }
    var C = global.Capacitor;
    try {
      if (C && C.Plugins && C.Plugins.App && C.Plugins.App.exitApp) { C.Plugins.App.exitApp(); return; }
    } catch (e) { /* ignore */ }
    try { global.close(); } catch (e) { /* ignore */ }
  }

  function swallowKey(e) {
    if (!state.gate) return;
    e.stopPropagation();
    if (e.stopImmediatePropagation) e.stopImmediatePropagation();
  }

  // Blok ekranında pult/klaviatura: yalnız bu ekran idarə olunur, tətbiqin nav.js-i işləmir.
  function onKey(e) {
    if (!state.gate) return;
    var btns = Array.prototype.slice.call(state.gate.querySelectorAll('.mlg-btn'));
    var idx = btns.indexOf(document.activeElement);
    var k = e.key, code = e.keyCode;
    var handled = true;
    if (k === 'ArrowLeft' || k === 'ArrowUp' || code === 37 || code === 38) {
      state.focusIdx = 0;
      if (!btns[0].disabled) btns[0].focus();
    } else if (k === 'ArrowRight' || k === 'ArrowDown' || code === 39 || code === 40) {
      state.focusIdx = 1;
      btns[1].focus();
    } else if (k === 'Enter' || k === ' ' || code === 13 || code === 23 || code === 66) {
      var b = idx >= 0 ? btns[idx] : btns[0];
      // yoxlama gedərkən OK təsadüfən "Çıxış"ı basmasın
      if (b && !b.disabled && !(state.checking && b.getAttribute('data-act') === 'exit' && state.focusIdx === 0)) {
        act(b.getAttribute('data-act'));
      }
    } else if (k === 'Escape' || k === 'GoBack' || k === 'BrowserBack' || k === 'Backspace' || code === 4 || code === 8 || code === 27 || code === 166 || code === 461 || code === 10009) {
      exitApp();
    } else {
      handled = false;
    }
    // Rəqəm, rəngli düymələr və s. də tətbiqə ötürülmür
    e.preventDefault();
    e.stopPropagation();
    if (e.stopImmediatePropagation) e.stopImmediatePropagation();
    return handled;
  }

  /* ---------------- public API ---------------- */
  function getState() {
    if (state.disabled) return { status: 'disabled', expires_at: null, checkedAt: null, customer_no: null, last_day: null, online: null, mac: null, key: null };
    var res = evaluate();
    return {
      status: res.status,
      expires_at: res.expires_at,
      checkedAt: res.checkedAt || null,
      customer_no: res.customer_no != null ? res.customer_no : null,
      last_day: res.expires_at ? fmtLastDay(res.expires_at) : null,
      online: state.online,
      mac: state.ident ? state.ident.mac : null,
      key: state.ident ? state.ident.key : null
    };
  }

  async function start(opts) {
    state.opts = opts || {};
    if (state.started) return getState();
    state.started = true;
    if (state.opts.lang) state.lang = state.opts.lang;
    else state.lang = (global.I18n && global.I18n.lang) || (document.documentElement.lang || 'az').slice(0, 2);
    if (!TEXT[state.lang]) state.lang = 'az';

    if (!isConfigured()) {
      state.disabled = true;
      return getState();
    }

    var dev = await getRawDevice();
    state.ident = deriveIdentity(dev.raw);
    state.ident.model = dev.model;
    state.cache = loadCache();

    // Keşdə "aktiv" varsa, tətbiq dərhal açılır; yoxlama arxa planda gedir.
    apply();
    var first = refresh();

    clearInterval(state.timer);
    state.timer = setInterval(tick, CONFIG.TICK_MS);
    document.addEventListener('visibilitychange', function () {
      if (document.visibilityState === 'visible') onResume();
    });
    try {
      var C = global.Capacitor;
      if (C && C.Plugins && C.Plugins.App && C.Plugins.App.addListener) {
        C.Plugins.App.addListener('resume', onResume);
      }
    } catch (e) { /* ignore */ }

    // Keş yoxdursa (ilk açılış), ilk cavabı gözlə
    if (!state.cache) await first;
    return getState();
  }

  global.MrbLicense = {
    start: start,
    refresh: refresh,
    getState: getState,
    getIdentity: function () { return state.ident ? { mac: state.ident.mac, key: state.ident.key } : null; },
    isBlocking: function () { return !!state.gate; },
    isEnabled: function () { return !state.disabled && isConfigured(); },
    isActive: function () { return evaluate().status === 'active'; },
    setLang: function (l) { if (TEXT[l]) { state.lang = l; renderGate(); } },
    onChange: function (fn) {
      state.listeners.push(fn);
      return function () { state.listeners = state.listeners.filter(function (f) { return f !== fn; }); };
    },
    _deriveIdentity: deriveIdentity, // test üçün
    _sha256: sha256
  };
})(typeof window !== 'undefined' ? window : this);
