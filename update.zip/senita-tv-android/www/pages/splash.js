/* Splash — same look as the native launch screen */
(function () {
  "use strict";

  const SplashPage = {
    mount: function (el) {
      el.innerHTML =
        '<div class="splash">' +
          '<div class="splash-center">' +
            '<img src="assets/app-logo.png" alt="Senita TV">' +
            '<div class="splash-progress"><i></i></div>' +
            '<div class="splash-status" id="splash-status">' + UI.esc(t("starting")) + '</div>' +
          '</div>' +
          '<div class="splash-version">v' + UI.esc(MRB.version) + '</div>' +
        '</div>';
    },

    setStatus: function (text) {
      const el = document.getElementById("splash-status");
      if (el) el.textContent = text || "";
    },

    destroy: function () {}
  };

  window.SplashPage = SplashPage;
})();
