/* Movie / series detail — play / resume, favorite, plot, episodes (Xtream), similar titles */
(function () {
  "use strict";

  const DetailPage = {
    mount: function (el, params) {
      this.el = el;
      this.tv = UI.isTV();
      this.item = params.item || null;
      this.type = params.type || (this.item && this.item.type) || "movie";
      this.season = params.season || null;
      this.episodes = null;
      this.seasons = [];
      this.loadingEps = false;
      if (!this.item) {
        el.innerHTML = '<div class="empty"><h3>' + UI.esc(t("notFound")) + '</h3></div>';
        return;
      }
      this.similar = this.findSimilar();
      this.render();
      if (this.isXtreamSeries()) this.loadEpisodes();
    },

    getState: function () {
      return { item: this.item, type: this.type, season: this.season };
    },

    isXtreamSeries: function () {
      return this.type === "series" && !this.item.url && !!this.item.seriesId;
    },

    findSimilar: function () {
      const vod = window.PlaylistManager ? PlaylistManager.getActiveVod() : { movies: [], series: [] };
      const pool = this.type === "series" ? (vod.series || []) : (vod.movies || []);
      const it = this.item;
      const out = [];
      for (let i = 0; i < pool.length && out.length < 12; i++) {
        const x = pool[i];
        if (x.group === it.group && (x.url || x.id) !== (it.url || it.id)) out.push(x);
      }
      return out;
    },

    render: function () {
      const it = this.item;
      const tv = this.tv;
      const name = it.name || it.title || "";
      const src = UI.posterSrc(it);
      const prog = UI.getProgress(it);
      const fav = window.StorageCore ? StorageCore.isFavorite(Object.assign({}, it, { type: this.type })) : false;

      let metas = "";
      if (it.year) metas += '<span class="meta">' + UI.esc(it.year) + '</span>';
      if (prog && prog.dur) metas += '<span class="meta">' + UI.esc(UI.duration(prog.dur)) + '</span>';
      if (it.group) metas += '<span class="meta">' + UI.esc(UI.catName(it.group)) + '</span>';
      if (it.rating && String(it.rating) !== "0") metas += '<span class="meta gold">★ ' + UI.esc(String(it.rating).slice(0, 3)) + '</span>';

      const canPlay = !!it.url;
      const playLabel = prog ? t("resumeAt", { time: UI.duration(prog.pos) }) : t("watch");
      let actions = '<div class="actions">';
      if (canPlay) actions += '<button class="btn btn-primary" data-f data-act="play">' + Icon("play", 18) + UI.esc(playLabel) + '</button>';
      if (canPlay && prog) actions += '<button class="square-btn" data-f data-act="restart" aria-label="' + UI.esc(t("fromStart")) + '">' + Icon("refresh", 20) + '</button>';
      actions += '<button class="square-btn' + (fav ? " on" : "") + '" data-f data-act="fav" aria-label="' + UI.esc(fav ? t("removeFavorite") : t("addFavorite")) + '">' + Icon(fav ? "starFill" : "star", 22) + '</button></div>';

      const plot = it.plot || it.description || "";
      let eps = "";
      if (this.isXtreamSeries()) eps = '<div id="eps">' + this.episodesHtml() + '</div>';

      let sim = "";
      if (this.similar.length) {
        sim = '<section class="section"><div class="section-head"><h2>' + UI.esc(this.type === "series" ? t("similarSeries") : t("similarMovies")) + '</h2></div><div class="hscroll">';
        this.similar.forEach(function (s, i) {
          sim += '<button class="vcard sim" data-f data-sim="' + i + '">' + UI.poster(s) + '</button>';
        });
        sim += '</div></section>';
      }

      let html;
      if (tv) {
        html = '<div class="detail-tv">' + (src ? '<div class="bg" style="background-image:url(\'' + UI.esc(src) + '\')"></div>' : '') +
          '<div class="dposter" style="background:' + UI.color(name) + '"><span style="position:relative">' + UI.esc(name) + '</span>' + (src ? '<img alt="" src="' + UI.esc(src) + '" onerror="this.remove()">' : '') + '</div>' +
          '<div class="dinfo scroll"><h1>' + UI.esc(name) + '</h1><div class="metas">' + metas + '</div>' + actions +
          (plot ? '<p class="plot">' + UI.esc(plot) + '</p>' : '') + eps + sim + '</div></div>';
      } else {
        html = '<div class="scroll"><div class="detail-hero" style="background:' + UI.color(name) + '">' +
          '<div class="clip">' + (src ? '<div class="bg" style="background-image:url(\'' + UI.esc(src) + '\')"></div>' : '') + '<div class="shade"></div></div>' +
          '<button class="icon-btn" data-act="back" aria-label="' + UI.esc(t("back")) + '">' + Icon("back", 22) + '</button>' +
          '<div class="detail-poster" style="background:' + UI.color(name) + '"><span style="position:relative">' + UI.esc(name) + '</span>' + (src ? '<img alt="" src="' + UI.esc(src) + '" onerror="this.remove()">' : '') + '</div></div>' +
          '<div class="detail-title"><h1>' + UI.esc(name) + '</h1></div>' +
          '<div class="detail-body"><div class="metas">' + metas + '</div>' + actions +
          (plot ? '<p class="plot">' + UI.esc(plot) + '</p>' : '') + eps + sim + '</div></div>';
      }
      this.el.innerHTML = html;
      this.bind();
      if (tv) Nav.focus(this.el.querySelector('[data-act="play"]') || this.el.querySelector(".ep") || this.el.querySelector("[data-f]"));
    },

    episodesHtml: function () {
      if (this.loadingEps) return '<div style="display:flex;align-items:center;gap:12px;color:var(--muted)"><span class="spinner"></span>' + UI.esc(t("loadingEpisodes")) + '</div>';
      if (!this.episodes) return "";
      if (!this.seasons.length) return '<p class="muted">' + UI.esc(t("noEpisodes")) + '</p>';
      let h = '<section class="section"><div class="section-head"><h2>' + UI.esc(t("episodes")) + '</h2></div>';
      if (this.seasons.length > 1) {
        h += '<div class="hscroll">';
        this.seasons.forEach((s) => {
          h += '<button class="chip' + (s === this.season ? " on" : "") + '" data-f data-season="' + UI.esc(s) + '">' + UI.esc(t("seasonN", { n: s })) + '</button>';
        });
        h += '</div>';
      }
      h += '<div class="ep-list">';
      (this.episodes[this.season] || []).forEach((ep, i) => {
        const p = UI.getProgress(ep);
        h += '<button class="ep" data-f data-ep="' + i + '"><span class="no">' + UI.esc(ep.num) + '</span><span class="grow"><span class="t ellipsis" style="display:block">' + UI.esc(ep.title) + '</span>' +
          '<span class="s" style="display:block">' + UI.esc(p ? t("resumeAt", { time: UI.duration(p.pos) }) : (ep.duration || "")) + '</span></span>' + Icon("play", 18) + '</button>';
      });
      h += '</div></section>';
      return h;
    },

    loadEpisodes: async function () {
      const it = this.item;
      const pl = window.StorageCore ? StorageCore.getPlaylistById(it.playlistId) : null;
      if (!pl || !window.XtreamService) { this.episodes = {}; this.updateEps(); return; }
      this.loadingEps = true;
      this.updateEps();
      try {
        const server = XtreamService.normalizeServer(pl.server || pl.url);
        const info = await XtreamService.getSeriesInfo(server, pl.username, pl.password, it.seriesId);
        const raw = (info && info.episodes) || {};
        const out = {};
        Object.keys(raw).sort(function (a, b) { return Number(a) - Number(b); }).forEach(function (s) {
          out[s] = (raw[s] || []).map(function (ep, i) {
            const num = ep.episode_num || i + 1;
            return {
              id: "xt_ep_" + ep.id,
              type: "series",
              playlistId: it.playlistId,
              num: num,
              title: ep.title || (t("episodeN", { n: num })),
              name: (it.name || "") + " · S" + s + " E" + num,
              poster: (ep.info && ep.info.movie_image) || UI.posterSrc(it),
              duration: ep.info && ep.info.duration ? ep.info.duration : "",
              group: it.group,
              url: XtreamService.buildStreamUrl(server, pl.username, pl.password, "series", ep.id, ep.container_extension || "mp4")
            };
          });
        });
        if (info && info.info && info.info.plot && !it.plot) it.plot = info.info.plot;
        this.episodes = out;
        this.seasons = Object.keys(out);
        if (!this.season || this.seasons.indexOf(this.season) < 0) this.season = this.seasons[0] || null;
      } catch (e) {
        this.episodes = {};
        this.seasons = [];
        MRB.toast(t("loadFailed"));
      }
      this.loadingEps = false;
      this.render();
    },

    updateEps: function () {
      const box = document.getElementById("eps");
      if (box) box.innerHTML = this.episodesHtml();
    },

    play: function (resume) {
      const it = this.item;
      const p = UI.getProgress(it);
      MRB.navigate("player", { channel: Object.assign({}, it, { type: this.type }), channels: [Object.assign({}, it, { type: this.type })], resumeAt: resume && p ? p.pos : 0 });
    },

    bind: function () {
      const el = this.el;
      el.addEventListener("click", (e) => {
        const b = e.target.closest("button");
        if (!b || !el.contains(b)) return;
        const act = b.getAttribute("data-act");
        if (act === "back") return MRB.back();
        if (act === "play") return this.play(true);
        if (act === "restart") return this.play(false);
        if (act === "fav") {
          const added = StorageCore.toggleFavorite(Object.assign({}, this.item, { type: this.type }));
          MRB.toast(added ? t("addedToFavorites") : t("removedFromFavorites"));
          b.classList.toggle("on", added);
          b.innerHTML = Icon(added ? "starFill" : "star", 22);
          return;
        }
        if (b.hasAttribute("data-season")) {
          this.season = b.getAttribute("data-season");
          this.render();
          if (this.tv) Nav.focus(this.el.querySelector('[data-season="' + this.season + '"]'));
          return;
        }
        if (b.hasAttribute("data-ep")) {
          const list = this.episodes[this.season] || [];
          const ep = list[Number(b.getAttribute("data-ep"))];
          const p = UI.getProgress(ep);
          if (ep) MRB.navigate("player", { channel: ep, channels: list, resumeAt: p ? p.pos : 0 });
          return;
        }
        if (b.hasAttribute("data-sim")) {
          const s = this.similar[Number(b.getAttribute("data-sim"))];
          if (s) MRB.navigate("detail", { item: s, type: this.type }, { replace: true });
        }
      });
    },

    refresh: function () {},
    destroy: function () {}
  };

  window.DetailPage = DetailPage;
})();
