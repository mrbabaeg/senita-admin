/* Language selection — first run (onboarding) and from Settings */
(function () {
  "use strict";

  const LANGS = [
    { code: "az", name: "Azərbaycan dili", key: "langAzNative" },
    { code: "en", name: "English", key: "langEnNative" },
    { code: "ru", name: "Русский", key: "langRuNative" }
  ];

  const LanguagePage = {
    first: false,
    selected: "az",

    mount: function (el, params) {
      this.el = el;
      this.first = params.route === "onboarding";
      this.selected = I18n.lang;
      this.render();
    },

    render: function () {
      const el = this.el;
      let html = '';
      if (!this.first) {
        html += '<header class="topbar back"><button class="icon-btn plain" data-f data-act="back" aria-label="' + UI.esc(t("back")) + '">' + Icon("back", 24) + '</button><h1>' + UI.esc(t("language")) + '</h1></header>';
      }
      html += '<div class="scroll"><div class="lang-page' + (this.first ? '' : ' inline') + '">';
      if (this.first) {
        html += '<img src="assets/app-logo.png" alt="" style="width:72px;height:72px;border-radius:18px">';
        html += '<h1>' + UI.esc(t("welcome")) + '</h1><p>' + UI.esc(t("chooseLanguageText")) + '</p>';
      }
      html += '<div role="radiogroup" aria-label="' + UI.esc(t("language")) + '" style="display:flex;flex-direction:column;gap:12px">';
      LANGS.forEach((l) => {
        const on = l.code === this.selected;
        html += '<button class="opt' + (on ? " on" : "") + '" role="radio" aria-checked="' + on + '" data-f data-lang="' + l.code + '">' +
          '<span class="code">' + l.code.toUpperCase() + '</span>' +
          '<span class="grow"><span class="a">' + UI.esc(l.name) + '</span><span class="b">' + UI.esc(t(l.key)) + '</span></span>' +
          '<span class="radio"></span></button>';
      });
      html += '</div>';
      if (this.first) {
        html += '<div style="flex:1;min-height:24px"></div><button class="btn btn-primary btn-block" data-f data-act="go" style="height:54px;font-size:16px">' + UI.esc(t("continue")) + '</button>';
      }
      html += '</div></div>';
      el.innerHTML = html;

      el.querySelectorAll("[data-lang]").forEach((b) => {
        b.addEventListener("click", () => {
          this.selected = b.getAttribute("data-lang");
          I18n.set(this.selected);
          if (this.first) {
            this.render();
            if (window.Platform && Platform.isTV) Nav.focus(this.el.querySelector('[data-lang="' + this.selected + '"]'));
          } else {
            MRB.toast(t("languageChanged"));
            MRB.back();
          }
        });
      });
      const go = el.querySelector('[data-act="go"]');
      if (go) go.addEventListener("click", () => {
        I18n.set(this.selected);
        MRB.goStart();
      });
      const back = el.querySelector('[data-act="back"]');
      if (back) back.addEventListener("click", () => MRB.back());

      if (window.Platform && Platform.isTV) Nav.focus(el.querySelector(".opt.on") || el.querySelector("[data-f]"));
    },

    destroy: function () {}
  };

  window.LanguagePage = LanguagePage;
})();
