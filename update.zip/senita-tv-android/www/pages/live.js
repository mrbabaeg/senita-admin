/* Live TV — phone: chips + virtual list; TV: categories | channels | preview */
(function () {
  "use strict";

  const FAV = "__fav__";

  const LivePage = {
    manualFocus: true,

    mount: function (el, params) {
      this.el = el;
      this.tv = UI.isTV();
      this.ROW = this.tv ? 66 : 72;
      this.zone = "list";
      this.load();
      this.catIndex = this.findCat(params.category);
      this.applyFilter();
      this.selIndex = 0;
      if (params.channelUrl) {
        const i = this.filtered.findIndex(function (c) { return c.url === params.channelUrl; });
        if (i >= 0) this.selIndex = i;
      }
      this.render();
      if (this.tv) this.focusIn();
    },

    load: function () {
      this.channels = window.PlaylistManager ? PlaylistManager.getActiveLiveChannels() : [];
      const cats = window.PlaylistManager ? PlaylistManager.getCategories("live") : [];
      this.favs = (window.StorageCore ? StorageCore.getFavorites() : []).filter(function (f) { return (f.type || "live") === "live"; });
      this.favSet = {};
      this.favs.forEach((f) => { this.favSet[f.url] = true; });
      this.cats = [];
      this.cats.push({ name: "All", count: this.channels.length });
      if (this.favs.length) this.cats.push({ name: FAV, count: this.favs.length });
      cats.forEach((c) => { if (c.name !== "All") this.cats.push(c); });
      const last = window.StorageCore ? StorageCore.getLastChannel() : null;
      this.lastUrl = last && last.url ? last.url : "";
      this.last = last;
    },

    findCat: function (name) {
      if (!name) return 0;
      const i = this.cats.findIndex(function (c) { return c.name === name; });
      return i >= 0 ? i : 0;
    },

    catLabel: function (c) {
      if (c.name === FAV) return t("favorites");
      return UI.catName(c.name);
    },

    applyFilter: function () {
      const c = this.cats[this.catIndex] || this.cats[0];
      if (!c || c.name === "All") {
        this.filtered = this.channels;
      } else if (c.name === FAV) {
        const byUrl = {};
        this.channels.forEach(function (x) { byUrl[x.url] = x; });
        this.filtered = this.favs.map(function (f) { return byUrl[f.url] || f; });
      } else {
        this.filtered = PlaylistManager.getItemsByCategory("live", c.name);
      }
    },

    getState: function () {
      const c = this.cats && this.cats[this.catIndex];
      const ch = this.filtered && this.filtered[this.selIndex];
      return { category: c ? c.name : "", channelUrl: this.tappedUrl || (ch ? ch.url : "") };
    },

    /* ---------------- render ---------------- */
    render: function () {
      if (this.tv) this.renderTV(); else this.renderPhone();
      this.renderRows(true);
    },

    renderPhone: function () {
      let html = '<header class="topbar" style="justify-content:space-between"><div><h1>' + UI.esc(t("liveTv")) + '</h1><div class="sub" id="live-count">' + UI.esc(t("channelsCount", { n: this.filtered.length })) + '</div></div>' +
        '<button class="icon-btn" data-act="search" aria-label="' + UI.esc(t("search")) + '">' + Icon("search", 20) + '</button></header>';
      if (this.channels.length) {
        html += '<div class="chips" id="live-chips">' + this.chipsHtml() + '</div>';
        html += '<div class="live-list" id="live-list"><div class="vlist-inner" id="live-inner"></div></div>';
        if (this.last && this.last.url) {
          const e = UI.epg(this.last);
          html += '<button class="mini" data-act="mini">' + UI.logo(this.last) + '<div class="grow"><div class="t ellipsis">' + UI.esc(this.last.name) + '</div><div class="s ellipsis">' + UI.esc(e.has ? e.title : t("continueWatching")) + '</div></div><span class="play-dot">' + Icon("play", 16) + '</span></button>';
        }
      } else {
        html += this.emptyHtml();
      }
      this.el.innerHTML = html;
      this.bindPhone();
    },

    chipsHtml: function () {
      let h = "";
      this.cats.forEach((c, i) => {
        h += '<button class="chip' + (i === this.catIndex ? " on" : "") + '" data-ci="' + i + '">' +
          (c.name === FAV ? Icon("starFill", 14) : "") + '<span class="ellipsis">' + UI.esc(this.catLabel(c)) + '</span>' +
          (c.name === "All" ? '' : '<span class="n">' + Number(c.count || 0) + '</span>') + '</button>';
      });
      return h;
    },

    emptyHtml: function () {
      return '<div class="empty"><span class="ic">' + Icon("tv", 28) + '</span><h3>' + UI.esc(t("noChannelsTitle")) + '</h3><p>' + UI.esc(t("noChannelsText")) + '</p>' +
        '<button class="btn btn-primary" data-f data-act="playlists">' + Icon("plus", 18) + UI.esc(t("addPlaylist")) + '</button></div>';
    },

    renderTV: function () {
      if (!this.channels.length) {
        this.el.innerHTML = this.emptyHtml();
        const b = this.el.querySelector('[data-act="playlists"]');
        if (b) b.addEventListener("click", () => MRB.navigate("playlists"));
        this.zone = null;
        return;
      }
      let html = '<div class="tv-live"><aside class="tv-cats"><h1>' + UI.esc(t("liveTv")) + '</h1><div id="tv-cats" class="scroll" style="display:flex;flex-direction:column;gap:4px">';
      this.cats.forEach((c, i) => {
        html += '<div class="tv-cat' + (i === this.catIndex ? " on" : "") + '" data-ci="' + i + '"><span>' + UI.esc(this.catLabel(c)) + '</span><span class="n">' + Number(c.count || 0) + '</span></div>';
      });
      html += '</div></aside>';
      html += '<section class="tv-chs"><div class="live-list" id="live-list"><div class="vlist-inner" id="live-inner"></div></div></section>';
      html += '<section class="tv-prev" id="tv-prev"></section></div>';
      this.el.innerHTML = html;
      this.bindTV();
      this.renderPreview();
    },

    rowHtml: function (c, i) {
      const tv = this.tv;
      const e = UI.epg(c);
      const isCur = c.url === this.lastUrl;
      const sel = tv && i === this.selIndex && this.zone === "list";
      const fav = !!this.favSet[c.url];
      let pg;
      if (e.has) pg = (isCur && !tv ? t("nowWatching") + " · " : UI.clock(e.start) + " · ") + e.title;
      else pg = isCur && !tv ? t("nowWatching") : (c.group ? UI.catName(c.group) : "");
      return '<button class="ch-row' + (isCur ? " cur" : "") + (sel ? " sel" : "") + '" data-i="' + i + '" style="top:' + (i * this.ROW) + 'px">' +
        '<span class="num">' + Number(c.number || i + 1) + '</span>' + UI.logo(c) +
        '<span class="info"><span class="nm" style="display:block">' + UI.esc(c.name) + '</span><span class="pg" style="display:block">' + UI.esc(pg) + '</span>' +
        (e.has ? '<span class="bar' + (isCur ? '' : ' grey') + '" style="display:block"><i style="width:' + e.progress + '%"></i></span>' : '') + '</span>' +
        (tv ? '<span class="favdot' + (fav ? " on" : "") + '">' + Icon("starFill", 20) + '</span>'
            : '<span class="star' + (fav ? " on" : "") + '" data-star="' + i + '" role="button" aria-label="' + UI.esc(fav ? t("removeFavorite") : t("addFavorite")) + '">' + Icon(fav ? "starFill" : "star", 20) + '</span>') +
        '</button>';
    },

    /* virtual list: render only rows around the viewport */
    renderRows: function (force) {
      const list = document.getElementById("live-list");
      const inner = document.getElementById("live-inner");
      if (!list || !inner) return;
      const n = this.filtered.length;
      inner.style.height = (n * this.ROW) + "px";
      const top = list.scrollTop;
      const vh = list.clientHeight || 600;
      const first = Math.max(0, Math.floor(top / this.ROW) - 6);
      const last = Math.min(n, Math.ceil((top + vh) / this.ROW) + 6);
      if (!force && first === this.rFirst && last === this.rLast) return;
      this.rFirst = first;
      this.rLast = last;
      let html = "";
      for (let i = first; i < last; i++) html += this.rowHtml(this.filtered[i], i);
      inner.innerHTML = html;
    },

    scrollToIndex: function (i, center) {
      const list = document.getElementById("live-list");
      if (!list) return;
      const vh = list.clientHeight || 600;
      const top = i * this.ROW;
      if (center) {
        list.scrollTop = Math.max(0, top - vh / 2 + this.ROW / 2);
      } else if (top < list.scrollTop) {
        list.scrollTop = top;
      } else if (top + this.ROW > list.scrollTop + vh) {
        list.scrollTop = top + this.ROW - vh;
      }
    },

    /* ---------------- phone ---------------- */
    bindPhone: function () {
      const el = this.el;
      const list = document.getElementById("live-list");
      if (list) {
        list.addEventListener("scroll", () => {
          if (this.raf) return;
          this.raf = requestAnimationFrame(() => { this.raf = null; this.renderRows(false); });
        }, { passive: true });
        if (this.selIndex > 0) setTimeout(() => { this.scrollToIndex(this.selIndex, true); this.renderRows(true); }, 0);
      }
      el.addEventListener("click", (e) => {
        const star = e.target.closest("[data-star]");
        if (star) {
          e.stopPropagation();
          this.toggleFav(this.filtered[Number(star.getAttribute("data-star"))]);
          return;
        }
        const b = e.target.closest("button");
        if (!b || !el.contains(b)) return;
        const act = b.getAttribute("data-act");
        if (act === "search") return MRB.navigate("search", { filter: "live" });
        if (act === "playlists") return MRB.navigate("playlists");
        if (act === "mini") return this.play(this.last, MRB.channelsFor(this.last));
        if (b.hasAttribute("data-ci")) {
          this.setCategory(Number(b.getAttribute("data-ci")));
          try { b.scrollIntoView({ inline: "center", block: "nearest", behavior: "smooth" }); } catch (err) {}
          return;
        }
        if (b.hasAttribute("data-i")) {
          const i = Number(b.getAttribute("data-i"));
          this.selIndex = i;
          this.play(this.filtered[i], this.filtered);
        }
      });
      const chip = el.querySelector(".chip.on");
      if (chip && this.catIndex > 0) setTimeout(function () { try { chip.scrollIntoView({ inline: "center", block: "nearest" }); } catch (e) {} }, 0);
    },

    setCategory: function (i) {
      if (i === this.catIndex && !this.tv) return;
      this.catIndex = Math.max(0, Math.min(this.cats.length - 1, i));
      this.applyFilter();
      this.selIndex = 0;
      const list = document.getElementById("live-list");
      if (list) list.scrollTop = 0;
      if (this.tv) {
        this.el.querySelectorAll(".tv-cat").forEach((c, k) => {
          c.classList.toggle("on", k === this.catIndex);
          c.classList.toggle("sel", k === this.catIndex && this.zone === "cats");
        });
        const cur = this.el.querySelector(".tv-cat.on");
        if (cur) try { cur.scrollIntoView({ block: "nearest" }); } catch (e) {}
        this.renderPreview();
      } else {
        this.el.querySelectorAll(".chip").forEach((c, k) => c.classList.toggle("on", k === this.catIndex));
        const cnt = document.getElementById("live-count");
        if (cnt) cnt.textContent = t("channelsCount", { n: this.filtered.length });
      }
      this.renderRows(true);
    },

    toggleFav: function (ch) {
      if (!ch || !window.StorageCore) return;
      const added = StorageCore.toggleFavorite(Object.assign({}, ch, { type: "live" }));
      MRB.toast(added ? t("addedToFavorites") : t("removedFromFavorites"));
      const keepCat = this.cats[this.catIndex] ? this.cats[this.catIndex].name : "";
      this.load();
      const idx = this.cats.findIndex(function (c) { return c.name === keepCat; });
      this.catIndex = idx >= 0 ? idx : 0;
      this.applyFilter();
      if (this.selIndex >= this.filtered.length) this.selIndex = Math.max(0, this.filtered.length - 1);
      if (this.tv) {
        this.renderRows(true);
      } else {
        const chips = document.getElementById("live-chips");
        if (chips) {
          const sl = chips.scrollLeft;
          chips.innerHTML = this.chipsHtml();
          chips.scrollLeft = sl;
        }
        this.renderRows(true);
      }
    },

    play: function (ch, list) {
      if (!ch) return;
      this.tappedUrl = ch.url;
      MRB.navigate("player", { channel: ch, channels: list && list.length ? list : MRB.channelsFor(ch) });
    },

    /* ---------------- TV ---------------- */
    bindTV: function () {
      const el = this.el;
      el.addEventListener("click", (e) => {
        const cat = e.target.closest(".tv-cat");
        if (cat) {
          this.zone = "cats";
          this.setCategory(Number(cat.getAttribute("data-ci")));
          return;
        }
        const row = e.target.closest(".ch-row");
        if (row) {
          this.selIndex = Number(row.getAttribute("data-i"));
          this.play(this.filtered[this.selIndex], this.filtered);
        }
      });
      const list = document.getElementById("live-list");
      if (list) list.addEventListener("scroll", () => this.renderRows(false), { passive: true });
      setTimeout(() => {
        this.scrollToIndex(this.selIndex, true);
        this.renderRows(true);
        const cur = el.querySelector(".tv-cat.on");
        if (cur) try { cur.scrollIntoView({ block: "nearest" }); } catch (e) {}
      }, 0);
    },

    focusIn: function () {
      if (!this.channels.length) {
        Nav.focusFirst();
        return;
      }
      Nav.blur();
      this.zone = this.filtered.length ? "list" : "cats";
      this.updateSel();
    },

    updateSel: function () {
      this.el.querySelectorAll(".tv-cat").forEach((c, k) => c.classList.toggle("sel", this.zone === "cats" && k === this.catIndex));
      this.scrollToIndex(this.selIndex, false);
      this.renderRows(true);
      this.renderPreview();
    },

    renderPreview: function () {
      const box = document.getElementById("tv-prev");
      if (!box) return;
      const ch = this.filtered[this.selIndex];
      if (!ch) { box.innerHTML = ""; return; }
      const e = UI.epg(ch, 3);
      let html = '<div class="big"><span class="badge-live"><i></i>' + UI.esc(t("live")) + '</span>' + UI.logo(ch) + '</div>';
      html += '<div><div class="ttl ellipsis">' + UI.esc(e.has ? e.title : ch.name) + '</div>';
      if (e.has) {
        const left = Math.max(0, Math.round((e.end.getTime() - Date.now()) / 60000));
        html += '<div class="tm">' + UI.clock(e.start) + ' – ' + UI.clock(e.end) + ' · ' + UI.esc(t("minLeft", { n: left })) + '</div>';
        html += '<div class="bar" style="margin-top:12px"><i style="width:' + e.progress + '%"></i></div>';
      } else {
        html += '<div class="tm">' + UI.esc(ch.group ? UI.catName(ch.group) : t("noEpg")) + '</div>';
      }
      html += '</div><div>';
      e.next.forEach(function (n) { html += '<div class="ep2"><b>' + UI.clock(n.start) + '</b><span class="ellipsis">' + UI.esc(n.title) + '</span></div>'; });
      html += '</div>';
      box.innerHTML = html;
    },

    onKey: function (e) {
      if (!this.tv || !this.zone || !this.channels.length) return false;
      if (Nav.current) return false; /* rail has focus */
      const k = e.key, c = e.keyCode;
      const up = k === "ArrowUp" || c === 38, down = k === "ArrowDown" || c === 40;
      const left = k === "ArrowLeft" || c === 37, right = k === "ArrowRight" || c === 39;
      const ok = k === "Enter" || c === 13;
      const pgUp = k === "PageUp" || k === "ChannelUp" || c === 33 || c === 427;
      const pgDn = k === "PageDown" || k === "ChannelDown" || c === 34 || c === 428;
      const color = c === 403 || c === 404 || c === 405 || c === 406;

      if (this.zone === "cats") {
        if (up) { this.setCategory(this.catIndex - 1); this.updateSel(); return true; }
        if (down) { this.setCategory(this.catIndex + 1); this.updateSel(); return true; }
        if (right || ok) { if (this.filtered.length) { this.zone = "list"; this.updateSel(); } return true; }
        if (left) { this.zone = null; this.updateSel(); Nav.focusRail(); return true; }
        return false;
      }
      if (this.zone === "list") {
        const n = this.filtered.length;
        if (up || down || pgUp || pgDn) {
          const step = up ? -1 : down ? 1 : pgUp ? -8 : 8;
          this.selIndex = Math.max(0, Math.min(n - 1, this.selIndex + step));
          this.updateSel();
          return true;
        }
        if (ok) { this.play(this.filtered[this.selIndex], this.filtered); return true; }
        if (left) { this.zone = "cats"; this.updateSel(); return true; }
        if (right) return true;
        if (color) { this.toggleFav(this.filtered[this.selIndex]); this.renderPreview(); return true; }
      }
      return false;
    },

    refresh: function (reason) {
      if (reason === "epg") {
        this.renderRows(true);
        if (this.tv) this.renderPreview();
        return;
      }
      const state = this.getState();
      this.load();
      this.catIndex = this.findCat(state.category);
      this.applyFilter();
      this.selIndex = Math.max(0, this.filtered.findIndex(function (c) { return c.url === state.channelUrl; }));
      this.render();
      if (this.tv && !Nav.current) this.focusIn();
    },

    destroy: function () {
      if (this.raf) cancelAnimationFrame(this.raf);
      this.raf = null;
      this.rFirst = this.rLast = -1;
      this.tappedUrl = "";
    }
  };

  window.LivePage = LivePage;
})();
