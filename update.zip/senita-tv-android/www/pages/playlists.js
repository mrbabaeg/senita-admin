/* Playlists — add M3U / Xtream, activate, refresh, delete */
(function () {
  "use strict";

  const PlaylistsPage = {
    mount: function (el, params) {
      this.el = el;
      this.tv = UI.isTV();
      this.mode = params.mode || "m3u";
      this.render();
    },

    getState: function () {
      return { mode: this.mode };
    },

    meta: function (p) {
      const parts = [];
      const counts = window.StorageCore && StorageCore.getChannelsCache ? StorageCore.getChannelsCache(p.id) : { items: [] };
      const vod = window.StorageCore && StorageCore.getVodCache ? StorageCore.getVodCache(p.id) : { movies: [], series: [] };
      const live = (counts.items || []).length;
      if (live) parts.push(t("channelsCount", { n: live }));
      if ((vod.movies || []).length) parts.push(t("moviesCount", { n: vod.movies.length }));
      if ((vod.series || []).length) parts.push(t("seriesCount", { n: vod.series.length }));
      if (!live && !(vod.movies || []).length && p.itemCount) parts.push(t("itemsCount", { n: p.itemCount }));
      if (p.xmltvUrl) parts.push(t("epgAvailable"));
      if (p.expiryDate) parts.push(t("expires", { date: p.expiryDate }));
      else if (p.lastRefreshAt) parts.push(t("updatedAgo", { ago: this.ago(p.lastRefreshAt) }));
      else parts.push(t("notLoadedYet"));
      return parts.join(" · ");
    },

    ago: function (iso) {
      const min = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
      if (min < 1) return t("justNow");
      if (min < 60) return t("minutesAgo", { n: min });
      const h = Math.round(min / 60);
      if (h < 48) return t("hoursAgo", { n: h });
      return t("daysAgo", { n: Math.round(h / 24) });
    },

    render: function () {
      const list = window.StorageCore ? StorageCore.getPlaylists() : [];
      const active = window.StorageCore ? StorageCore.getActivePlaylistId() : "";
      const xt = this.mode === "xtream";
      let html = '<header class="topbar back">' + (this.tv ? '' : '<button class="icon-btn plain" data-act="back" aria-label="' + UI.esc(t("back")) + '">' + Icon("back", 24) + '</button>') + '<h1>' + UI.esc(t("playlists")) + '</h1></header>';
      html += '<div class="scroll"><div style="' + (this.tv ? "padding:0 40px 40px;max-width:760px" : "padding:0 16px 24px") + ';display:flex;flex-direction:column;gap:14px">';

      html += '<section class="card"><h2>' + UI.esc(t("newPlaylist")) + '</h2><div class="seg" style="background:var(--bg)">' +
        '<button data-f data-mode="m3u" class="' + (xt ? "" : "on") + '">' + UI.esc(t("m3uLink")) + '</button>' +
        '<button data-f data-mode="xtream" class="' + (xt ? "on" : "") + '">Xtream Codes</button></div>';
      html += '<div class="field"><label for="pl-name">' + UI.esc(t("name")) + '</label><input class="input" data-f id="pl-name" autocomplete="off" placeholder="' + UI.esc(t("namePlaceholder")) + '"></div>';
      if (xt) {
        html += '<div class="field"><label for="pl-server">' + UI.esc(t("serverUrl")) + '</label><input class="input" data-f id="pl-server" type="url" autocomplete="off" placeholder="http://example.com:8080"></div>';
        html += '<div class="field"><label for="pl-user">' + UI.esc(t("username")) + '</label><input class="input" data-f id="pl-user" autocomplete="off" autocapitalize="off"></div>';
        html += '<div class="field"><label for="pl-pass">' + UI.esc(t("password")) + '</label><input class="input" data-f id="pl-pass" type="password" autocomplete="off"></div>';
      } else {
        html += '<div class="field"><label for="pl-url">' + UI.esc(t("m3uUrl")) + '</label><input class="input" data-f id="pl-url" type="url" autocomplete="off" autocapitalize="off" placeholder="http://…/playlist.m3u8"></div>';
      }
      html += '<button class="btn btn-primary" data-f data-act="add">' + Icon("plus", 18) + UI.esc(t("addAndLoad")) + '</button></section>';

      html += '<h2 class="h" style="font-size:16px;font-weight:700;margin-top:6px">' + UI.esc(t("saved")) + '</h2>';
      if (!list.length) html += '<p class="muted" style="font-size:14px">' + UI.esc(t("noPlaylistsYet")) + '</p>';
      list.forEach((p) => {
        const on = p.id === active;
        html += '<div class="pl-card' + (on ? " active" : "") + '"><div class="grow"><div style="display:flex;align-items:center;gap:8px;min-width:0"><span class="nm ellipsis">' + UI.esc(p.name) + '</span>' +
          (on ? '<span class="badge">' + UI.esc(t("activeBadge")) + '</span>' : '') + '</div><div class="sb">' + UI.esc(this.meta(p)) + '</div></div>' +
          (on ? '' : '<button class="btn btn-outline" data-f data-on="' + UI.esc(p.id) + '">' + UI.esc(t("activate")) + '</button>') +
          '<button class="ib" data-f data-refresh="' + UI.esc(p.id) + '" aria-label="' + UI.esc(t("refresh")) + '">' + Icon("refresh", 18) + '</button>' +
          '<button class="ib danger" data-f data-del="' + UI.esc(p.id) + '" aria-label="' + UI.esc(t("delete")) + '">' + Icon("trash", 18) + '</button></div>';
      });
      html += '</div></div>';
      this.el.innerHTML = html;
      this.bind();
    },

    val: function (id) {
      const el = document.getElementById(id);
      return el ? el.value.trim() : "";
    },

    add: async function () {
      const name = this.val("pl-name");
      try {
        let playlist;
        if (this.mode === "xtream") {
          const server = this.val("pl-server"), user = this.val("pl-user"), pass = this.val("pl-pass");
          if (!server || !user || !pass) throw new Error(t("fillAllFields"));
          const srv = XtreamService.normalizeServer(server);
          MRB.showLoading(t("checkingAccount"));
          const account = await XtreamService.getAccountInfo(srv, user, pass);
          const u = account && account.user_info ? account.user_info : {};
          if (u.auth !== undefined && Number(u.auth) !== 1) throw new Error(t("authFailed"));
          playlist = StorageCore.addPlaylist({
            type: "xtream", name: name || ("Xtream · " + user), server: srv, username: user, password: pass, url: srv,
            accountStatus: u.status || "", expiryDate: u.exp_date ? new Date(Number(u.exp_date) * 1000).toLocaleDateString() : ""
          });
        } else {
          const url = this.val("pl-url");
          if (!/^https?:\/\//i.test(url)) throw new Error(t("invalidUrl"));
          playlist = PlaylistManager.addM3UUrl(url, name || t("myPlaylist"));
        }
        StorageCore.setActivePlaylistId(playlist.id);
        MRB.showLoading(t("loadingPlaylist"));
        await PlaylistManager.refreshPlaylist(playlist.id);
        try { window.dispatchEvent(new CustomEvent("mrb:playlist-updated")); } catch (e) {}
        MRB.hideLoading();
        MRB.toast(t("playlistAdded"));
        this.render();
      } catch (err) {
        MRB.hideLoading();
        MRB.toast((err && err.message) || t("loadFailed"), 3500);
        this.render();
      }
    },

    refreshOne: async function (id) {
      try {
        MRB.showLoading(t("loadingPlaylist"));
        await PlaylistManager.refreshPlaylist(id);
        try { window.dispatchEvent(new CustomEvent("mrb:playlist-updated")); } catch (e) {}
        MRB.hideLoading();
        MRB.toast(t("playlistUpdated"));
      } catch (err) {
        MRB.hideLoading();
        MRB.toast((err && err.message) || t("loadFailed"), 3500);
      }
      this.render();
    },

    bind: function () {
      const el = this.el;
      el.addEventListener("click", async (e) => {
        const b = e.target.closest("button");
        if (!b || !el.contains(b)) return;
        if (b.getAttribute("data-act") === "back") return MRB.back();
        if (b.getAttribute("data-act") === "add") return this.add();
        if (b.hasAttribute("data-mode")) {
          this.mode = b.getAttribute("data-mode");
          this.render();
          if (this.tv) Nav.focus(this.el.querySelector('[data-mode="' + this.mode + '"]'));
          return;
        }
        if (b.hasAttribute("data-on")) {
          const id = b.getAttribute("data-on");
          StorageCore.setActivePlaylistId(id);
          const has = StorageCore.getChannelsCache(id).items.length || StorageCore.getVodCache(id).movies.length;
          if (!has) return this.refreshOne(id);
          try { window.dispatchEvent(new CustomEvent("mrb:playlist-updated")); } catch (err) {}
          try { if (window.SearchEngine) SearchEngine.buildFromPlaylist(); } catch (err) {}
          MRB.toast(t("playlistActivated"));
          this.render();
          return;
        }
        if (b.hasAttribute("data-refresh")) return this.refreshOne(b.getAttribute("data-refresh"));
        if (b.hasAttribute("data-del")) {
          const id = b.getAttribute("data-del");
          const p = StorageCore.getPlaylistById(id);
          const ok = await MRB.confirm(t("deletePlaylistTitle"), t("deletePlaylistText", { name: p ? p.name : "" }), t("delete"));
          if (!ok) return;
          StorageCore.deletePlaylist(id);
          try { window.dispatchEvent(new CustomEvent("mrb:playlist-updated")); } catch (err) {}
          MRB.toast(t("playlistDeleted"));
          this.render();
        }
      });
    },

    refresh: function () {},
    destroy: function () {}
  };

  window.PlaylistsPage = PlaylistsPage;
})();
