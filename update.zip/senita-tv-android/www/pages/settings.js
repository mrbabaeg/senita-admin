/* Settings */
(function () {
  "use strict";

  const LANG_NAMES = { az: "Azərbaycan", en: "English", ru: "Русский" };

  const SettingsPage = {
    mount: function (el) {
      this.el = el;
      this.tv = UI.isTV();
      this.render();
    },

    row: function (act, icon, title, value, opts) {
      opts = opts || {};
      return '<button class="srow' + (opts.danger ? " danger" : "") + '" data-f data-act="' + act + '"><span class="sic">' + Icon(icon, 18) + '</span><span class="t">' + UI.esc(title) + '</span>' +
        (opts.switchOn !== undefined ? '<span class="switch' + (opts.switchOn ? " on" : "") + '" role="switch" aria-checked="' + !!opts.switchOn + '"></span>' : '<span class="v">' + UI.esc(value || "") + '</span>') +
        (opts.chevron ? Icon("chevron", 18, ' style="color:var(--dim)"') : '') + '</button>';
    },

    render: function () {
      const s = window.StorageCore ? StorageCore.getSettings() : {};
      const pls = window.StorageCore ? StorageCore.getPlaylists().length : 0;
      const favs = window.StorageCore ? StorageCore.getFavorites().length : 0;
      const ar = window.AutoRefresh ? AutoRefresh.getState() : {};
      const active = window.StorageCore ? StorageCore.getActivePlaylist() : null;
      const lastRef = active && active.lastRefreshAt ? PlaylistsPage.ago(active.lastRefreshAt) : (ar.lastRefreshAt ? PlaylistsPage.ago(ar.lastRefreshAt) : "");
      const modeOverride = window.Platform ? Platform.override : "auto";
      const modeLabel = modeOverride === "tv" ? t("modeTv") : modeOverride === "mobile" ? t("modePhone") : t("modeAuto") + " (" + (Platform.isTV ? t("modeTv") : t("modePhone")) + ")";
      const aspect = this.aspectLabel(s.playerAspect || "contain");

      let html = '<header class="topbar"><h1>' + UI.esc(t("settings")) + '</h1></header><div class="scroll"><div style="' + (this.tv ? "padding:0 40px 40px;max-width:760px" : "padding:0 16px 24px") + ';display:flex;flex-direction:column;gap:20px">';
      html += this.licenseHtml();
      html += '<div><div class="grp-title">' + UI.esc(t("content")) + '</div><div class="grp">' +
        this.row("playlists", "playlist", t("playlists"), String(pls), { chevron: true }) +
        this.row("favorites", "star", t("favorites"), String(favs), { chevron: true }) + '</div></div>';
      html += '<div><div class="grp-title">' + UI.esc(t("general")) + '</div><div class="grp">' +
        this.row("language", "globe", t("language"), LANG_NAMES[I18n.lang], { chevron: true }) +
        (window.Platform && Platform.isAndroid ? this.row("mode", "tv", t("appearance"), modeLabel) : "") + '</div></div>';
      html += '<div><div class="grp-title">' + UI.esc(t("player")) + '</div><div class="grp">' +
        this.row("aspect", "expand", t("aspectRatio"), aspect) +
        this.row("autoplay", "play", t("openLastChannel"), "", { switchOn: !!s.autoplayLastChannel }) + '</div></div>';
      html += '<div><div class="grp-title">' + UI.esc(t("data")) + '</div><div class="grp">' +
        this.row("refresh", "refresh", t("refreshPlaylistEpg"), lastRef) +
        this.row("backup", "download", t("backup"), "") +
        this.row("clear", "trash", t("clearAll"), "", { danger: true }) + '</div></div>';
      html += '<div class="version">Senita TV · v' + UI.esc(MRB.version) + '</div></div></div>';
      this.el.innerHTML = html;
      this.bind();
    },

    /* ---------- Abunəlik ---------- */
    licenseHtml: function () {
      if (!window.MrbLicense || !MrbLicense.isEnabled || !MrbLicense.isEnabled()) return "";
      return '<div id="lic-box">' + this.licenseInner(MrbLicense.getState()) + '</div>';
    },

    licenseInner: function (st) {
      st = st || {};
      const map = {
        active: t("licActive"),
        pending: t("licPending"),
        expired: t("licExpired"),
        blocked: t("licBlocked"),
        offline: t("licOffline"),
        key_mismatch: t("licMismatch"),
        unknown: t("licChecking")
      };
      const status = map[st.status] || t("licChecking");
      let rows = this.row("license", st.status === "active" ? "check" : "info", t("licStatus"), status);
      if (st.customer_no != null) rows += this.row("license", "list", t("licCustomerId"), "#" + st.customer_no);
      if (st.last_day) rows += this.row("license", "clock", t("licLastDay"), st.last_day);
      rows += this.row("license", "tv", "MAC", st.mac || "—");
      rows += this.row("license", "info", t("licKey"), st.key || "—");
      return '<div class="grp-title">' + UI.esc(t("subscription")) + '</div><div class="grp">' + rows + '</div>';
    },

    renderLicense: function (st) {
      const box = this.el && this.el.querySelector("#lic-box");
      if (!box) return;
      const focused = document.activeElement && box.contains(document.activeElement);
      box.innerHTML = this.licenseInner(st);
      if (focused) this.focusAct("license");
    },

    aspects: function () {
      return [
        { value: "contain", label: t("aspectOriginal") },
        { value: "cover", label: t("aspectZoom") },
        { value: "fill", label: t("aspectStretch") }
      ];
    },

    aspectLabel: function (v) {
      const a = this.aspects().find(function (x) { return x.value === v; });
      return a ? a.label : v;
    },

    focusAct: function (act) {
      if (this.tv) Nav.focus(this.el.querySelector('[data-act="' + act + '"]'));
    },

    bind: function () {
      const el = this.el;
      el.addEventListener("click", async (e) => {
        const b = e.target.closest("[data-act]");
        if (!b || !el.contains(b)) return;
        const act = b.getAttribute("data-act");
        if (act === "license") {
          if (!window.MrbLicense) return;
          MRB.toast(t("licChecking"));
          await MrbLicense.refresh();
          const st = MrbLicense.getState();
          if (st.status === "active") MRB.toast(t("licActive") + (st.last_day ? " · " + st.last_day : ""));
          return;
        }
        if (act === "playlists") return MRB.navigate("playlists");
        if (act === "favorites") return MRB.navigate("favorites");
        if (act === "language") return MRB.navigate("language");
        if (act === "mode") {
          const v = await MRB.choose(t("appearance"), [
            { value: "auto", label: t("modeAuto") },
            { value: "mobile", label: t("modePhone") },
            { value: "tv", label: t("modeTv") }
          ], Platform.override);
          if (v && v !== Platform.override) Platform.setMode(v);
          else this.focusAct("mode");
          return;
        }
        if (act === "aspect") {
          const cur = StorageCore.getSettings().playerAspect || "contain";
          const v = await MRB.choose(t("aspectRatio"), this.aspects(), cur);
          if (v) StorageCore.setSetting("playerAspect", v);
          this.render();
          this.focusAct("aspect");
          return;
        }
        if (act === "autoplay") {
          const cur = !!StorageCore.getSettings().autoplayLastChannel;
          StorageCore.setSetting("autoplayLastChannel", !cur);
          this.render();
          this.focusAct("autoplay");
          return;
        }
        if (act === "refresh") {
          try {
            MRB.showLoading(t("loadingPlaylist"));
            if (window.AutoRefresh) await AutoRefresh.refreshNow("manual");
            MRB.hideLoading();
            MRB.toast(t("playlistUpdated"));
            const p = StorageCore.getActivePlaylist();
            if (p && p.xmltvUrl && window.XMLTVService) {
              MRB.toast(t("epgUpdating"));
              XMLTVService.refreshInBackground(p.xmltvUrl, null, true).then(function (r) { if (r) MRB.toast(t("epgUpdated")); });
            }
          } catch (err) {
            MRB.hideLoading();
            MRB.toast((err && err.message) || t("loadFailed"), 3500);
          }
          this.render();
          this.focusAct("refresh");
          return;
        }
        if (act === "backup") return this.backup();
        if (act === "clear") {
          const ok = await MRB.confirm(t("clearAllTitle"), t("clearAllText"), t("delete"));
          if (!ok) { this.focusAct("clear"); return; }
          try { localStorage.clear(); } catch (err) {}
          location.reload();
        }
      });
    },

    backup: async function () {
      const v = await MRB.choose(t("backup"), [
        { value: "export", label: t("backupExport") },
        { value: "import", label: t("backupImport") }
      ], null);
      if (v === "export") {
        const text = window.BackupService ? BackupService.exportText() : "{}";
        MRB.modal({
          title: t("backupExport"),
          html: '<p>' + UI.esc(t("backupExportText")) + '</p><textarea id="bk" readonly>' + UI.esc(text) + '</textarea>',
          buttons: [{ label: t("close"), kind: "ghost", value: "close" }, { label: t("copy"), kind: "primary", value: "copy" }],
          defaultIndex: 1
        }).then(function (r) {
          if (r !== "copy") return;
          const done = function () { MRB.toast(t("copied")); };
          try {
            if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, function () { MRB.toast(t("copyFailed")); });
            else MRB.toast(t("copyFailed"));
          } catch (e) { MRB.toast(t("copyFailed")); }
        });
      } else if (v === "import") {
        const r = await MRB.modal({
          title: t("backupImport"),
          html: '<p>' + UI.esc(t("backupImportText")) + '</p><textarea id="bk-in" data-f placeholder="{ … }"></textarea>',
          buttons: [{ label: t("cancel"), kind: "ghost", value: false }, { label: t("restore"), kind: "primary", value: true }],
          onMount: function (el) {
            el._val = function () { return (el.querySelector("#bk-in") || {}).value || ""; };
            const ta = el.querySelector("#bk-in");
            if (ta) ta.addEventListener("input", function () { el._last = ta.value; });
            window.__bkModal = el;
          }
        });
        const text = window.__bkModal && window.__bkModal._last ? window.__bkModal._last : "";
        window.__bkModal = null;
        if (!r) return;
        try {
          BackupService.importText(text);
          MRB.toast(t("restored"));
          setTimeout(function () { location.reload(); }, 700);
        } catch (err) {
          MRB.toast((err && err.message) || t("loadFailed"), 3500);
        }
      }
    },

    refresh: function () {},
    destroy: function () {}
  };

  window.SettingsPage = SettingsPage;
})();
