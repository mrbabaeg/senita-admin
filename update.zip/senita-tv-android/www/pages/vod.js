/* Movies / Series — chips, "continue" row, poster grid rendered page by page */
(function () {
  "use strict";

  const PAGE = 60;

  const VodPage = {
    mount: function (el, params) {
      this.el = el;
      this.tv = UI.isTV();
      this.type = params.route === "series" ? "series" : "movie";
      this.load();
      this.catIndex = 0;
      if (params.category) {
        const i = this.cats.findIndex(function (c) { return c.name === params.category; });
        if (i >= 0) this.catIndex = i;
      }
      this.applyFilter();
      this.render();
      if (params.scrollTop) {
        const sc = this.el.querySelector(".scroll");
        const want = params.rendered || 0;
        while (this.rendered < want && this.appendMore()) { /* restore depth */ }
        if (sc) sc.scrollTop = params.scrollTop;
      }
      if (this.tv) {
        const target = params.itemIndex !== undefined ? this.el.querySelector('[data-v="' + params.itemIndex + '"]') : null;
        Nav.focus(target || this.el.querySelector(".chip.on") || this.el.querySelector("[data-f]"));
      }
    },

    load: function () {
      const vod = window.PlaylistManager ? PlaylistManager.getActiveVod() : { movies: [], series: [] };
      this.items = this.type === "series" ? (vod.series || []) : (vod.movies || []);
      this.cats = window.M3UParser ? M3UParser.buildCategories(this.items) : [{ name: "All", count: this.items.length }];
      this.cont = UI.continueList(this.type).slice(0, 10);
    },

    applyFilter: function () {
      const c = this.cats[this.catIndex];
      this.filtered = !c || c.name === "All" ? this.items : M3UParser.filterByCategory(this.items, c.name);
    },

    getState: function () {
      const sc = this.el && this.el.querySelector(".scroll");
      const cat = this.cats[this.catIndex];
      return { category: cat ? cat.name : "", scrollTop: sc ? sc.scrollTop : 0, rendered: this.rendered, itemIndex: this.lastIndex };
    },

    title: function () {
      return this.type === "series" ? t("series") : t("movies");
    },

    render: function () {
      const tv = this.tv;
      let html = '<header class="topbar" style="justify-content:space-between"><div><h1>' + UI.esc(this.title()) + '</h1><div class="sub" id="vod-count">' +
        UI.esc(this.type === "series" ? t("seriesCount", { n: this.items.length }) : t("moviesCount", { n: this.items.length })) + '</div></div>' +
        (tv ? '' : '<button class="icon-btn" data-act="search" aria-label="' + UI.esc(t("search")) + '">' + Icon("search", 20) + '</button>') + '</header>';

      if (!this.items.length) {
        html += '<div class="empty"><span class="ic">' + Icon(this.type === "series" ? "series" : "film", 28) + '</span><h3>' +
          UI.esc(this.type === "series" ? t("noSeriesTitle") : t("noMoviesTitle")) + '</h3><p>' + UI.esc(t("noVodText")) + '</p>' +
          '<button class="btn btn-ghost" data-f data-act="playlists">' + Icon("playlist", 18) + UI.esc(t("playlists")) + '</button></div>';
        this.el.innerHTML = html;
        this.bind();
        return;
      }

      html += '<div class="chips" id="vod-chips">';
      this.cats.forEach((c, i) => {
        html += '<button class="chip' + (i === this.catIndex ? " on" : "") + '" data-f data-ci="' + i + '"><span class="ellipsis">' + UI.esc(UI.catName(c.name)) + '</span>' +
          (c.name === "All" ? '' : '<span class="n">' + Number(c.count || 0) + '</span>') + '</button>';
      });
      html += '</div><div class="scroll" id="vod-scroll"><div class="vod-body">';

      if (this.cont.length && this.catIndex === 0) {
        html += '<section class="section"><div class="section-head"><h2>' + UI.esc(t("continueWatching")) + '</h2></div><div class="hscroll">';
        this.cont.forEach(function (p, i) {
          const it = p.item;
          const src = UI.posterSrc(it);
          const left = Math.max(1, Math.round((p.dur - p.pos) / 60));
          html += '<button class="wide" data-f data-cont="' + i + '"><span class="pic" style="background:' + UI.color(it.name) + '">' +
            (src ? '<img loading="lazy" alt="" src="' + UI.esc(src) + '" onerror="this.remove()">' : '') + '<span class="ellipsis">' + UI.esc(it.name) + '</span>' +
            '<span class="bar"><i style="width:' + Math.round(p.pos * 100 / p.dur) + '%"></i></span></span><span class="y">' + UI.esc(t("minLeft", { n: left })) + '</span></button>';
        });
        html += '</div></section>';
      }

      const cat = this.cats[this.catIndex];
      html += '<section class="section"><div class="section-head"><h2>' + UI.esc(cat && cat.name !== "All" ? UI.catName(cat.name) : t("all")) + '</h2><span class="muted" style="font-size:12px">' + this.filtered.length + '</span></div>' +
        '<div class="vgrid" id="vod-grid">' + this.renderPosters() + '</div></section>';
      html += '</div></div>';
      this.el.innerHTML = html;
      this.bind();
    },

    card: function (it, i) {
      const rating = it.rating && String(it.rating) !== "0" ? '<span class="rate">★ ' + UI.esc(String(it.rating).slice(0, 3)) + '</span>' : '';
      return '<button class="vcard" data-f data-v="' + i + '">' + UI.poster(it, rating) +
        '<span class="t">' + UI.esc(it.name || it.title) + '</span><span class="y">' + UI.esc(it.year || UI.catName(it.group || "")) + '</span></button>';
    },

    renderPosters: function () {
      this.rendered = 0;
      return this.range(0, Math.min(this.filtered.length, PAGE));
    },

    range: function (from, to) {
      let h = "";
      for (let i = from; i < to; i++) h += this.card(this.filtered[i], i);
      this.rendered = Math.max(this.rendered, to);
      return h;
    },

    appendMore: function () {
      if (this.rendered >= this.filtered.length) return false;
      const grid = document.getElementById("vod-grid");
      if (!grid) return false;
      grid.insertAdjacentHTML("beforeend", this.range(this.rendered, Math.min(this.filtered.length, this.rendered + PAGE)));
      return true;
    },

    setCategory: function (i) {
      this.catIndex = i;
      this.applyFilter();
      const sc = this.el.querySelector(".scroll");
      const keep = this.tv;
      this.render();
      const newSc = this.el.querySelector(".scroll");
      if (newSc) newSc.scrollTop = 0;
      const chip = this.el.querySelector('.chip[data-ci="' + i + '"]');
      if (chip) {
        try { chip.scrollIntoView({ inline: "center", block: "nearest" }); } catch (e) {}
        if (keep) Nav.focus(chip);
      }
      void sc;
    },

    open: function (it, i) {
      if (!it) return;
      this.lastIndex = i;
      MRB.navigate("detail", { item: it, type: this.type });
    },

    bind: function () {
      const el = this.el;
      el.addEventListener("click", (e) => {
        const b = e.target.closest("button");
        if (!b || !el.contains(b)) return;
        const act = b.getAttribute("data-act");
        if (act === "search") return MRB.navigate("search", { filter: this.type === "series" ? "series" : "movie" });
        if (act === "playlists") return MRB.navigate("playlists");
        if (b.hasAttribute("data-ci")) return this.setCategory(Number(b.getAttribute("data-ci")));
        if (b.hasAttribute("data-v")) { const i = Number(b.getAttribute("data-v")); return this.open(this.filtered[i], i); }
        if (b.hasAttribute("data-cont")) {
          const p = this.cont[Number(b.getAttribute("data-cont"))];
          if (p) MRB.navigate("player", { channel: p.item, channels: [p.item], resumeAt: p.pos });
        }
      });
      const sc = el.querySelector(".scroll");
      if (sc) sc.addEventListener("scroll", () => {
        if (sc.scrollTop + sc.clientHeight > sc.scrollHeight - 900) this.appendMore();
      }, { passive: true });
    },

    onFocus: function (elx) {
      if (elx && elx.hasAttribute("data-v") && Number(elx.getAttribute("data-v")) > this.rendered - 14) this.appendMore();
    },

    refresh: function (reason) {
      if (reason !== "playlist") return;
      const s = this.getState();
      this.load();
      const i = this.cats.findIndex(function (c) { return c.name === s.category; });
      this.catIndex = i >= 0 ? i : 0;
      this.applyFilter();
      this.render();
      if (this.tv) Nav.focusFirst(".chip.on");
    },

    destroy: function () {}
  };

  window.VodPage = VodPage;
})();
