/* Search — live channels, movies and series with filters and recent queries */
(function () {
  "use strict";

  const RECENT_KEY = "mrb_recent_searches";

  const SearchPage = {
    mount: function (el, params) {
      this.el = el;
      this.tv = UI.isTV();
      this.query = params.query || "";
      this.filter = params.filter || "all";
      this.ensureIndex();
      this.render();
      const input = document.getElementById("q");
      if (this.tv) {
        Nav.focus(input);
      } else if (input && !this.query) {
        setTimeout(function () { try { input.focus(); } catch (e) {} }, 80);
      }
    },

    getState: function () {
      return { query: this.query, filter: this.filter };
    },

    ensureIndex: function () {
      try {
        if (window.SearchEngine && SearchEngine.stats && SearchEngine.stats().all === 0) SearchEngine.buildFromPlaylist();
      } catch (e) {}
    },

    recent: function () {
      try { return JSON.parse(localStorage.getItem(RECENT_KEY) || "[]") || []; } catch (e) { return []; }
    },

    remember: function (q) {
      q = String(q || "").trim();
      if (q.length < 2) return;
      const list = this.recent().filter(function (x) { return x.toLowerCase() !== q.toLowerCase(); });
      list.unshift(q);
      try { localStorage.setItem(RECENT_KEY, JSON.stringify(list.slice(0, 8))); } catch (e) {}
    },

    render: function () {
      const filters = [["all", t("all")], ["live", t("live")], ["movie", t("movies")], ["series", t("series")]];
      let html = '<div class="search-top">' +
        (this.tv ? '' : '<button class="icon-btn" data-act="back" aria-label="' + UI.esc(t("back")) + '">' + Icon("back", 22) + '</button>') +
        '<label class="search-box">' + Icon("search", 18, ' style="color:var(--muted)"') +
        '<input id="q" data-f type="search" enterkeyhint="search" autocomplete="off" placeholder="' + UI.esc(t("searchPlaceholder")) + '" value="' + UI.esc(this.query) + '" aria-label="' + UI.esc(t("search")) + '"></label></div>';
      html += '<div style="padding:14px 16px 4px;flex:0 0 auto"' + (this.tv ? ' class="narrow"' : '') + '><div class="seg" role="tablist">';
      filters.forEach((f) => {
        html += '<button role="tab" data-f data-filter="' + f[0] + '" class="' + (f[0] === this.filter ? "on" : "") + '" aria-selected="' + (f[0] === this.filter) + '">' + UI.esc(f[1]) + '</button>';
      });
      html += '</div></div><div class="scroll" id="results"></div>';
      this.el.innerHTML = html;
      this.bind();
      this.renderResults();
    },

    renderResults: function () {
      const box = document.getElementById("results");
      if (!box) return;
      const q = this.query.trim();
      const pad = this.tv ? '0 40px 40px' : '0 16px 24px';
      if (!q) {
        const rec = this.recent();
        let h = '<div style="padding:' + pad + '">';
        if (rec.length) {
          h += '<div class="label-caps" style="margin:14px 0 10px">' + UI.esc(t("recentSearches")) + '</div><div style="display:flex;gap:8px;flex-wrap:wrap">';
          rec.forEach(function (r, i) { h += '<button class="recent-chip chip" data-f data-recent="' + i + '">' + UI.esc(r) + '</button>'; });
          h += '</div>';
        } else {
          h += '<div class="empty" style="padding-top:60px"><span class="ic">' + Icon("search", 28) + '</span><p>' + UI.esc(t("searchHint")) + '</p></div>';
        }
        box.innerHTML = h + '</div>';
        return;
      }
      const res = this.search(q);
      this.results = res;
      let h = '<div style="padding:' + pad + '">';
      let total = 0;
      const section = (key, label, list, kind) => {
        if (!list.length) return;
        total += list.length;
        h += '<div class="label-caps" style="margin:14px 0 4px">' + UI.esc(label) + ' · ' + list.length + '</div>';
        list.forEach(function (it, i) {
          let left;
          if (kind === "live") left = UI.logo(it, "");
          else left = '<span class="pthumb" style="background:' + UI.color(it.name) + '">' + (UI.posterSrc(it) ? '<img loading="lazy" alt="" src="' + UI.esc(UI.posterSrc(it)) + '" onerror="this.remove()">' : '') + '</span>';
          const sub = kind === "live" ? [UI.catName(it.group || ""), UI.nowLine(it)].filter(Boolean).join(" · ") : [it.year, UI.catName(it.group || "")].filter(Boolean).join(" · ");
          h += '<button class="res" data-f data-k="' + key + '" data-i="' + i + '">' + left + '<span class="grow"><span class="nm" style="display:block">' + UI.highlight(it.name || it.title, q) + '</span><span class="sb" style="display:block">' + UI.esc(sub) + '</span></span>' +
            '<span class="tag">' + UI.esc(kind === "live" ? t("liveTag") : kind === "series" ? t("seriesTag") : t("movieTag")) + '</span></button>';
        });
      };
      section("live", t("liveChannels"), res.live, "live");
      section("movie", t("movies"), res.movie, "movie");
      section("series", t("series"), res.series, "series");
      if (!total) h += '<div class="empty" style="padding-top:60px"><span class="ic">' + Icon("search", 28) + '</span><h3>' + UI.esc(t("nothingFound")) + '</h3><p>' + UI.esc(t("nothingFoundText", { q: q })) + '</p></div>';
      box.innerHTML = h + '</div>';
    },

    search: function (q) {
      const out = { live: [], movie: [], series: [] };
      const lim = this.filter === "all" ? 20 : 80;
      const types = this.filter === "all" ? ["live", "movie", "series"] : [this.filter];
      types.forEach(function (tp) {
        let list = [];
        try {
          if (window.SearchEngine && SearchEngine.search) list = SearchEngine.search(q, { type: tp, limit: lim, includeScore: true }).map(function (r) { return r.item; });
        } catch (e) { list = []; }
        if (!list.length && window.PlaylistManager) list = PlaylistManager.search(tp, q).slice(0, lim);
        out[tp] = list;
      });
      return out;
    },

    bind: function () {
      const el = this.el;
      const input = document.getElementById("q");
      let timer = null;
      input.addEventListener("input", () => {
        this.query = input.value;
        clearTimeout(timer);
        timer = setTimeout(() => this.renderResults(), 160);
      });
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") { this.remember(this.query); input.blur(); }
      });
      el.addEventListener("click", (e) => {
        const b = e.target.closest("button");
        if (!b || !el.contains(b)) return;
        if (b.getAttribute("data-act") === "back") return MRB.back();
        if (b.hasAttribute("data-filter")) {
          this.filter = b.getAttribute("data-filter");
          el.querySelectorAll("[data-filter]").forEach((x) => { const on = x === b; x.classList.toggle("on", on); x.setAttribute("aria-selected", on); });
          this.renderResults();
          return;
        }
        if (b.hasAttribute("data-recent")) {
          this.query = this.recent()[Number(b.getAttribute("data-recent"))] || "";
          input.value = this.query;
          this.renderResults();
          return;
        }
        if (b.hasAttribute("data-k")) {
          const k = b.getAttribute("data-k");
          const it = this.results[k][Number(b.getAttribute("data-i"))];
          if (!it) return;
          this.remember(this.query);
          if (k === "live") MRB.navigate("player", { channel: it, channels: MRB.channelsFor(it) });
          else MRB.navigate("detail", { item: it, type: k === "series" ? "series" : "movie" });
        }
      });
    },

    refresh: function (reason) {
      if (reason === "playlist") { this.ensureIndex(); this.renderResults(); }
    },

    destroy: function () {}
  };

  window.SearchPage = SearchPage;
})();
