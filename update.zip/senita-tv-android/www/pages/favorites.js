/* Favorites — channels / movies / series */
(function () {
  "use strict";

  const FavoritesPage = {
    mount: function (el, params) {
      this.el = el;
      this.tv = UI.isTV();
      this.tab = params.tab || "live";
      this.render();
    },

    getState: function () {
      return { tab: this.tab };
    },

    lists: function () {
      const all = window.StorageCore ? StorageCore.getFavorites() : [];
      const channels = window.PlaylistManager ? PlaylistManager.getActiveLiveChannels() : [];
      const byUrl = {};
      channels.forEach(function (c) { byUrl[c.url] = c; });
      return {
        live: all.filter(function (f) { return (f.type || "live") === "live"; }).map(function (f) { return Object.assign({}, f, byUrl[f.url] || {}); }),
        movie: all.filter(function (f) { return f.type === "movie"; }),
        series: all.filter(function (f) { return f.type === "series"; })
      };
    },

    render: function () {
      const L = this.lists();
      this.L = L;
      const tabs = [["live", t("channels")], ["movie", t("movies")], ["series", t("series")]];
      let html = '<header class="topbar back">' + (this.tv ? '' : '<button class="icon-btn plain" data-act="back" aria-label="' + UI.esc(t("back")) + '">' + Icon("back", 24) + '</button>') + '<h1>' + UI.esc(t("favorites")) + '</h1></header>';
      html += '<div class="' + (this.tv ? "narrow" : "") + '" style="' + (this.tv ? "" : "padding:0 16px 8px;") + 'flex:0 0 auto"><div class="seg" role="tablist">';
      tabs.forEach((tb) => {
        html += '<button role="tab" data-f data-tab="' + tb[0] + '" class="' + (tb[0] === this.tab ? "on" : "") + '">' + UI.esc(tb[1]) + ' · ' + L[tb[0]].length + '</button>';
      });
      html += '</div></div><div class="scroll"><div style="' + (this.tv ? "padding:8px 40px 40px;max-width:840px" : "padding:0 8px 24px 16px") + '">';
      const list = L[this.tab];
      if (!list.length) {
        html += '<div class="empty" style="padding-top:48px"><span class="ic">' + Icon("star", 28) + '</span><h3>' + UI.esc(t("noFavoritesTitle")) + '</h3><p>' + UI.esc(t("noFavoritesText")) + '</p></div>';
      } else {
        list.forEach((it, i) => {
          let left, sub;
          if (this.tab === "live") {
            left = UI.logo(it);
            const e = UI.epg(it);
            sub = e.has ? t("nowPrefix") + ": " + e.title : UI.catName(it.group || "");
          } else {
            left = '<span class="pthumb" style="background:' + UI.color(it.name) + '">' + (UI.posterSrc(it) ? '<img loading="lazy" alt="" src="' + UI.esc(UI.posterSrc(it)) + '" onerror="this.remove()">' : '') + '</span>';
            sub = [it.year, UI.catName(it.group || "")].filter(Boolean).join(" · ");
          }
          html += '<div class="list-row" style="padding-right:4px"><button class="grow" data-f data-open="' + i + '" style="display:flex;align-items:center;gap:12px;min-height:72px;text-align:left">' + left +
            '<span class="grow"><span class="nm" style="display:block">' + UI.esc(it.name || it.title) + '</span><span class="sb" style="display:block">' + UI.esc(sub) + '</span></span></button>' +
            '<button class="star on" data-f data-rm="' + i + '" aria-label="' + UI.esc(t("removeFavorite")) + '">' + Icon("starFill", 20) + '</button></div>';
        });
      }
      html += '<div class="hint">' + Icon("star", 20, ' style="color:var(--gold)"') + '<span>' + UI.esc(this.tv ? t("favHintTv") : t("favHint")) + '</span></div>';
      html += '</div></div>';
      this.el.innerHTML = html;
      this.bind();
      if (this.tv) Nav.focus(this.el.querySelector("[data-open]") || this.el.querySelector('[data-tab].on'));
    },

    bind: function () {
      const el = this.el;
      el.addEventListener("click", (e) => {
        const b = e.target.closest("button");
        if (!b || !el.contains(b)) return;
        if (b.getAttribute("data-act") === "back") return MRB.back();
        if (b.hasAttribute("data-tab")) { this.tab = b.getAttribute("data-tab"); this.render(); if (this.tv) Nav.focus(this.el.querySelector('[data-tab="' + this.tab + '"]')); return; }
        const list = this.L[this.tab];
        if (b.hasAttribute("data-rm")) {
          const it = list[Number(b.getAttribute("data-rm"))];
          if (it) StorageCore.removeFavorite(it.favoriteId);
          MRB.toast(t("removedFromFavorites"));
          this.render();
          return;
        }
        if (b.hasAttribute("data-open")) {
          const it = list[Number(b.getAttribute("data-open"))];
          if (!it) return;
          if (this.tab === "live") MRB.navigate("player", { channel: it, channels: list });
          else MRB.navigate("detail", { item: it, type: this.tab });
        }
      });
    },

    refresh: function () {},
    destroy: function () {}
  };

  window.FavoritesPage = FavoritesPage;
})();
