/* Home — continue watching, recent channels, categories, favorites */
(function () {
  "use strict";

  const HomePage = {
    mount: function (el) {
      this.el = el;
      this.render();
      clearInterval(this.timer);
      this.timer = setInterval(() => this.tick(), 30000);
    },

    data: function () {
      const channels = window.PlaylistManager ? PlaylistManager.getActiveLiveChannels() : [];
      const byUrl = {};
      channels.forEach(function (c) { byUrl[c.url] = c; });
      const fresh = function (c) { return (c && byUrl[c.url]) || c; };

      const lastRaw = window.StorageCore ? StorageCore.getLastChannel() : null;
      const last = lastRaw && lastRaw.url && (lastRaw.type || "live") === "live" ? fresh(lastRaw) : null;
      const recent = (window.RecentManager ? RecentManager.getAll() : [])
        .filter(function (c) { return (c.type || "live") === "live"; })
        .map(fresh).slice(0, 10);
      const cats = (window.PlaylistManager ? PlaylistManager.getCategories("live") : []).filter(function (c) { return c.name !== "All"; });
      const favs = (window.StorageCore ? StorageCore.getFavorites() : [])
        .filter(function (f) { return (f.type || "live") === "live"; })
        .map(fresh).slice(0, 12);
      return { channels: channels, last: last, recent: recent, cats: cats, favs: favs };
    },

    render: function () {
      const tv = UI.isTV();
      const d = this.data();
      this.d = d;
      let html = "";

      if (!tv) {
        html += '<header class="topbar" style="justify-content:space-between"><div class="brand"><img src="assets/app-logo.png" alt=""><span>Senita TV</span></div>' +
          '<button class="icon-btn" data-act="search" aria-label="' + UI.esc(t("search")) + '">' + Icon("search", 20) + '</button></header>';
      }

      html += '<div class="scroll"><div class="home-body">';
      if (tv) {
        html += '<div class="home-head"><h1>' + UI.esc(t("welcome")) + '</h1><div class="clock" id="home-clock">' + UI.clock(new Date()) + '</div></div>';
      }

      if (!d.channels.length) {
        const loading = window.AutoRefresh && AutoRefresh.isRunning;
        html += '<div class="empty-card"><h3>' + UI.esc(loading ? t("loadingChannels") : t("noChannelsTitle")) + '</h3>' +
          '<p>' + UI.esc(loading ? t("loadingChannelsText") : t("noChannelsText")) + '</p>' +
          (loading ? '' : '<button class="btn btn-primary" data-f data-act="playlists">' + Icon("plus", 18) + UI.esc(t("addPlaylist")) + '</button>') + '</div>';
      } else {
        html += this.hero(d.last || d.channels[0], !d.last, tv);

        if (d.recent.length) {
          html += '<section class="section"><div class="section-head"><h2>' + UI.esc(t("recentlyWatched")) + '</h2>' +
            (tv ? '' : '<button class="link" data-act="live">' + UI.esc(t("seeAll")) + '</button>') + '</div><div class="hscroll">';
          d.recent.forEach(function (c, i) { html += HomePage.tile(c, "r", i, tv); });
          html += '</div></section>';
        }

        if (d.cats.length) {
          html += '<section class="section"><div class="section-head"><h2>' + UI.esc(t("categories")) + '</h2></div><div class="cat-grid">';
          d.cats.slice(0, tv ? 8 : 6).forEach(function (c) {
            html += '<button class="cat-chip" data-f data-cat="' + UI.esc(c.name) + '"><span class="ellipsis">' + UI.esc(UI.catName(c.name)) + '</span><span class="n">' + Number(c.count || 0) + '</span></button>';
          });
          html += '</div></section>';
        }

        if (d.favs.length) {
          html += '<section class="section"><div class="section-head"><h2>' + UI.esc(t("favorites")) + '</h2>' +
            (tv ? '' : '<button class="link" data-act="favorites">' + UI.esc(t("seeAll")) + '</button>') + '</div><div class="hscroll">';
          d.favs.forEach(function (c, i) { html += HomePage.tile(c, "fav", i, tv); });
          html += '</div></section>';
        }
      }
      html += '</div></div>';
      this.el.innerHTML = html;
      this.bind();
      if (tv) {
        const hero = this.el.querySelector(".hero");
        Nav.focus(hero || this.el.querySelector("[data-f]"));
      }
    },

    hero: function (ch, suggested, tv) {
      const e = UI.epg(ch, 1);
      const now = e.has ? UI.clock(e.start) + " · " + e.title : (ch.group ? UI.catName(ch.group) : t("liveNow"));
      const next = e.next[0] ? t("next") + ": " + UI.clock(e.next[0].start) + " · " + e.next[0].title : "";
      const label = suggested ? t("startWatching") : t("continueWatching");
      if (tv) {
        return '<button class="hero" data-f data-act="hero">' + UI.logo(ch) +
          '<div class="grow"><div style="display:flex;align-items:center;gap:10px"><span class="badge-live"><i></i>' + UI.esc(t("live")) + '</span><span class="muted" style="font-size:14px">' + UI.esc(label) + '</span></div>' +
          '<div class="hero-title ellipsis">' + UI.esc(ch.name) + '</div><div class="hero-sub ellipsis" id="hero-now">' + UI.esc(e.has ? UI.clock(e.start) + " – " + UI.clock(e.end) + " · " + e.title : now) + '</div>' +
          (e.has ? '<div class="bar"><i style="width:' + e.progress + '%"></i></div>' : '') + '</div>' +
          '<span class="go">' + Icon("play", 20) + UI.esc(t("watch")) + '</span></button>';
      }
      return '<button class="hero" data-act="hero"><div class="hero-top"><span class="badge-live"><i></i>' + UI.esc(t("live")) + '</span>' +
        '<div class="who">' + UI.logo(ch) + '<div class="grow"><div class="hero-title ellipsis">' + UI.esc(ch.name) + '</div><div class="hero-sub ellipsis">' + UI.esc(now) + '</div></div></div></div>' +
        '<div class="hero-bottom"><div class="grow">' + (e.has ? '<div class="bar"><i style="width:' + e.progress + '%"></i></div>' : '') +
        '<div class="next ellipsis">' + UI.esc(next || label) + '</div></div>' +
        '<span class="btn btn-primary btn-round">' + Icon("play", 16) + UI.esc(suggested ? t("watch") : t("continue")) + '</span></div></button>';
    },

    tile: function (c, kind, i, tv) {
      const sub = tv ? (UI.epg(c).title || "") : "";
      return '<button class="tile" data-f data-' + kind + '="' + i + '">' + UI.logo(c) + '<span class="tn ellipsis">' + UI.esc(c.name) + '</span>' +
        (tv ? '<span class="tp ellipsis">' + UI.esc(sub) + '</span>' : '') + '</button>';
    },

    play: function (ch) {
      if (!ch) return;
      MRB.navigate("player", { channel: ch, channels: MRB.channelsFor(ch) });
    },

    bind: function () {
      const el = this.el;
      const d = this.d;
      el.addEventListener("click", (e) => {
        const b = e.target.closest("button");
        if (!b || !el.contains(b)) return;
        const act = b.getAttribute("data-act");
        if (act === "search") return MRB.navigate("search");
        if (act === "live") return MRB.navigate("live");
        if (act === "favorites") return MRB.navigate("favorites");
        if (act === "playlists") return MRB.navigate("playlists");
        if (act === "hero") return this.play(d.last || d.channels[0]);
        if (b.hasAttribute("data-r")) return this.play(d.recent[Number(b.getAttribute("data-r"))]);
        if (b.hasAttribute("data-fav")) return this.play(d.favs[Number(b.getAttribute("data-fav"))]);
        if (b.hasAttribute("data-cat")) return MRB.navigate("live", { category: b.getAttribute("data-cat") });
      });
    },

    tick: function () {
      const c = document.getElementById("home-clock");
      if (c) c.textContent = UI.clock(new Date());
    },

    refresh: function () {
      const tv = UI.isTV();
      const hadData = !!(this.d && this.d.channels && this.d.channels.length);
      const hasData = !!(window.PlaylistManager && PlaylistManager.getActiveLiveChannels().length);
      const cur = tv ? Nav.current : null;
      /* on TV keep the user's focus unless the page changes between empty and filled */
      if (cur && !Nav.inRail(cur) && !cur.classList.contains("hero") && hadData === hasData) return;
      const railEl = cur && Nav.inRail(cur) ? cur : null;
      this.render();
      if (railEl && document.contains(railEl)) Nav.focus(railEl);
    },

    destroy: function () {
      clearInterval(this.timer);
    }
  };

  window.HomePage = HomePage;
})();
