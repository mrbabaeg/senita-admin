/* Player — live channels and movies/episodes.
   Phone: touch controls (top bar, center buttons, EPG / seek bar).
   TV: info overlay, channel list on ◀, numbers, CH+/CH-, color key = favorite. */
(function () {
  "use strict";

  const PlayerPage = {
    mount: function (el, params) {
      this.el = el;
      this.tv = UI.isTV();
      this.channel = params.channel || null;
      this.channels = Array.isArray(params.channels) && params.channels.length ? params.channels : (this.channel ? [this.channel] : []);
      this.index = Math.max(0, this.channels.findIndex((c) => c.url === (this.channel && this.channel.url)));
      if (this.index < 0) this.index = 0;
      this.resumeAt = Number(params.resumeAt || 0);
      this.listVisible = false;
      this.sideIndex = this.index;
      this.numberBuffer = "";
      this.seeking = false;

      if (!this.channel || !this.channel.url) {
        el.innerHTML = '<div class="empty"><h3>' + UI.esc(t("notFound")) + '</h3></div>';
        return;
      }

      el.innerHTML =
        '<div class="player" id="player">' +
          '<video id="video" playsinline webkit-playsinline autoplay></video>' +
          '<div class="pl-spin" id="pl-spin"></div>' +
          '<div class="pl-msg hidden" id="pl-msg"></div>' +
          '<div class="pl-zap hidden" id="pl-zap"></div>' +
          '<div class="pl-num hidden" id="pl-num"></div>' +
          '<aside class="side" id="side"></aside>' +
          (this.tv ? '<div class="tvo" id="tvo"></div>' : '<div class="pmc" id="pmc"></div>') +
        '</div>';

      this.video = document.getElementById("video");
      if (window.PlayerEngine) {
        PlayerEngine.init(this.video, {
          onStatus: (s) => this.onStatus(s),
          onError: (err) => { if (err && err.type !== "autoplay") this.message(t("playbackError"), 1800); }
        });
        const aspect = window.StorageCore ? StorageCore.getSettings().playerAspect : "contain";
        PlayerEngine.setAspect(aspect || "contain");
      }

      this._vEvents = () => this.updateControls();
      ["play", "pause", "playing", "timeupdate", "durationchange", "loadedmetadata"].forEach((ev) => this.video.addEventListener(ev, this._vEvents));
      this._meta = () => {
        if (this.resumeAt > 5 && this.isVod() && isFinite(this.video.duration)) {
          try { this.video.currentTime = Math.min(this.resumeAt, this.video.duration - 5); } catch (e) {}
          this.resumeAt = 0;
        }
      };
      this.video.addEventListener("loadedmetadata", this._meta);

      if (window.Platform && Platform.isAndroid) Platform.enterPlayerMode();

      this.renderControls();
      this.load(false);
      this.clockTimer = setInterval(() => this.updateControls(), 15000);
      this.saveTimer = setInterval(() => this.saveProgress(), 15000);
    },

    isVod: function () {
      const tp = this.channel && this.channel.type;
      return tp === "movie" || tp === "series" || tp === "vod" || tp === "episode";
    },

    load: function (zap) {
      const ch = this.channel;
      if (!this.isVod()) {
        if (window.StorageCore) StorageCore.setLastChannel(ch);
        if (window.RecentManager) RecentManager.addChannel(ch);
      }
      this.spinner(true);
      try {
        if (window.PlayerEngine) PlayerEngine.load(ch, { autoplay: true });
      } catch (e) {
        this.message(e.message || t("playbackError"), 1800);
      }
      this.renderControls();
      if (zap) this.showZap();
      this.showControls();
    },

    onStatus: function (s) {
      if (s === "playing") { this.spinner(false); this.hideMessage(); }
      else if (s === "loading" || s === "buffering" || s === "retrying") this.spinner(true);
      else if (s === "error" || s === "paused" || s === "ready") this.spinner(false);
      this.updateControls();
    },

    spinner: function (on) {
      const s = document.getElementById("pl-spin");
      if (s) s.classList.toggle("hidden", !on);
    },

    message: function (text, ms) {
      const m = document.getElementById("pl-msg");
      if (!m) return;
      m.textContent = text;
      m.classList.remove("hidden");
      clearTimeout(this.msgTimer);
      this.msgTimer = setTimeout(() => m.classList.add("hidden"), ms || 1200);
    },

    hideMessage: function () {
      const m = document.getElementById("pl-msg");
      if (m) m.classList.add("hidden");
    },

    favItem: function () {
      return Object.assign({}, this.channel, { type: this.channel.type || "live" });
    },

    isFav: function () {
      return window.StorageCore ? StorageCore.isFavorite(this.favItem()) : false;
    },

    /* ---------------- controls ---------------- */
    renderControls: function () {
      const ch = this.channel;
      const vod = this.isVod();
      const zap = this.channels.length > 1;
      const fav = this.isFav();
      const num = Number(ch.number || this.index + 1);

      if (this.tv) {
        const box = document.getElementById("tvo");
        if (!box) return;
        let keys;
        if (vod) keys = [["OK", t("keyPause")], ["◀ ▶", t("keySeek")], ["★", t("keyFavorite")]];
        else keys = [["OK", t("keyPause")], ["▲▼", t("keyZap")], ["◀", t("keyList")], ["0–9", t("keyNumber")], ["★", t("keyFavorite")]];
        let html = '<div class="shade"></div><div class="clock" id="tvo-clock"></div><div class="info"><div class="row1">' + UI.logo(ch) +
          '<div class="grow"><div class="nmrow">' + (vod ? '' : '<span class="num">' + num + '</span>') + '<span class="name">' + UI.esc(ch.name) + '</span>' +
          (vod ? '' : '<span class="badge-live">' + UI.esc(t("live")) + '</span>') + (fav ? Icon("starFill", 26, ' style="color:var(--gold)"') : '') + '</div>' +
          '<div class="now" id="tvo-now"></div></div><div class="nx" id="tvo-next"></div></div>' +
          '<div class="prog"><span id="tvo-a"></span><div class="pmc-bar"><i id="tvo-bar" style="width:0"></i></div><span id="tvo-b"></span></div>' +
          '<div class="keys">';
        keys.forEach(function (k) { html += '<span class="key"><span>' + UI.esc(k[0]) + '</span>' + UI.esc(k[1]) + '</span>'; });
        html += '</div></div>';
        box.innerHTML = html;
        this.updateControls();
        return;
      }

      const box = document.getElementById("pmc");
      if (!box) return;
      let html = '<div class="pmc-tap" data-a="tap"></div>' +
        '<div class="pmc-top"><button class="pbtn" data-a="back" aria-label="' + UI.esc(t("back")) + '">' + Icon("back", 22) + '</button>' + UI.logo(ch) +
        '<div class="pmc-title"><div class="l1"><span>' + (vod ? '' : num + ' · ') + UI.esc(ch.name) + '</span>' + (vod ? '' : '<span class="badge-sm">' + UI.esc(t("live")) + '</span>') + '</div><div class="l2" id="pmc-sub"></div></div>' +
        '<button class="pbtn' + (fav ? " on" : "") + '" data-a="fav" aria-label="' + UI.esc(fav ? t("removeFavorite") : t("addFavorite")) + '">' + Icon(fav ? "starFill" : "star", 20) + '</button>' +
        '<button class="pbtn" data-a="aspect" aria-label="' + UI.esc(t("aspectRatio")) + '">' + Icon("expand", 20) + '</button>' +
        (zap ? '<button class="pbtn" data-a="list" aria-label="' + UI.esc(t("channelList")) + '">' + Icon("list", 20) + '</button>' : '') + '</div>' +
        '<div class="pmc-center">' +
        (zap ? '<button class="pbtn big" data-a="prev" aria-label="' + UI.esc(t("previous")) + '">' + Icon("prev", 22) + '</button>' : '') +
        (vod ? '<button class="pbtn big txt" data-a="rew" aria-label="-10">−10</button>' : '') +
        '<button class="pbtn main" data-a="play" id="pmc-play" aria-label="' + UI.esc(t("playPause")) + '">' + Icon("pause", 28) + '</button>' +
        (vod ? '<button class="pbtn big txt" data-a="fwd" aria-label="+10">+10</button>' : '') +
        (zap ? '<button class="pbtn big" data-a="next" aria-label="' + UI.esc(t("next")) + '">' + Icon("next", 22) + '</button>' : '') +
        '</div><div class="pmc-bottom">';
      if (vod) {
        html += '<div class="pmc-seek"><span id="pmc-t">0:00</span><input type="range" id="pmc-seek" min="0" max="1000" value="0" aria-label="' + UI.esc(t("seek")) + '"><span id="pmc-d">0:00</span></div>';
      } else {
        html += '<div class="pmc-epg"><span id="pmc-now"></span><span id="pmc-next"></span></div><div class="pmc-bar"><i id="pmc-bar" style="width:0"></i></div>';
      }
      html += '</div>';
      box.innerHTML = html;
      if (!this.bound) this.bindPhone();
      this.updateControls();
    },

    bindPhone: function () {
      const box = document.getElementById("pmc");
      if (!box) return;
      this.bound = true;
      box.addEventListener("click", (e) => {
        const b = e.target.closest("[data-a]");
        if (!b) return;
        const a = b.getAttribute("data-a");
        if (a === "tap") {
          if (this.listVisible) { this.closeList(); return; }
          if (box.classList.contains("show")) { box.classList.remove("show"); clearTimeout(this.hideTimer); }
          else this.showControls();
          return;
        }
        this.showControls();
        if (a === "back") return MRB.back();
        if (a === "play") return this.togglePlay();
        if (a === "prev") return this.zap(-1);
        if (a === "next") return this.zap(1);
        if (a === "rew") return this.seekBy(-10);
        if (a === "fwd") return this.seekBy(10);
        if (a === "fav") return this.toggleFav();
        if (a === "aspect") return this.cycleAspect();
        if (a === "list") return this.openList();
      });
      box.addEventListener("input", (e) => {
        if (e.target.id !== "pmc-seek") return;
        this.seeking = true;
        this.showControls();
        const d = this.video.duration;
        const tEl = document.getElementById("pmc-t");
        if (tEl && isFinite(d)) tEl.textContent = UI.duration(d * e.target.value / 1000);
      });
      box.addEventListener("change", (e) => {
        if (e.target.id !== "pmc-seek") return;
        const d = this.video.duration;
        if (isFinite(d) && d > 0) this.video.currentTime = d * e.target.value / 1000;
        this.seeking = false;
      });
    },

    updateControls: function () {
      const v = this.video;
      if (!v || !this.channel) return;
      const ch = this.channel;
      const vod = this.isVod();
      const e = vod ? null : UI.epg(ch, 1);

      if (this.tv) {
        const set = function (id, txt) { const x = document.getElementById(id); if (x) x.textContent = txt; };
        set("tvo-clock", UI.clock(new Date()));
        const bar = document.getElementById("tvo-bar");
        if (vod) {
          const d = v.duration;
          set("tvo-now", v.paused ? t("paused") : (ch.group ? UI.catName(ch.group) : ""));
          set("tvo-a", UI.duration(v.currentTime || 0));
          set("tvo-b", isFinite(d) ? UI.duration(d) : "");
          if (bar) bar.style.width = (isFinite(d) && d > 0 ? Math.round(v.currentTime * 100 / d) : 0) + "%";
          set("tvo-next", "");
        } else {
          set("tvo-now", e.has ? e.title : (v.paused ? t("paused") : t("liveNow")));
          set("tvo-a", e.has ? UI.clock(e.start) : "");
          set("tvo-b", e.has ? UI.clock(e.end) : "");
          if (bar) bar.style.width = (e.has ? e.progress : 0) + "%";
          const nx = document.getElementById("tvo-next");
          if (nx) nx.innerHTML = e.next[0] ? '<small>' + UI.esc(t("next")) + '</small><b>' + UI.clock(e.next[0].start) + ' · ' + UI.esc(e.next[0].title) + '</b>' : '';
        }
        return;
      }

      const play = document.getElementById("pmc-play");
      if (play) play.innerHTML = Icon(v.paused ? "play" : "pause", 28);
      const sub = document.getElementById("pmc-sub");
      if (vod) {
        if (sub) sub.textContent = ch.group ? UI.catName(ch.group) : "";
        const d = v.duration;
        if (!this.seeking && isFinite(d) && d > 0) {
          const s = document.getElementById("pmc-seek");
          if (s) s.value = String(Math.round(1000 * (v.currentTime || 0) / d));
          const a = document.getElementById("pmc-t"); if (a) a.textContent = UI.duration(v.currentTime || 0);
          const b = document.getElementById("pmc-d"); if (b) b.textContent = UI.duration(d);
        }
      } else {
        if (sub) sub.textContent = e.has ? e.title : t("liveNow");
        const now = document.getElementById("pmc-now");
        if (now) now.textContent = e.has ? UI.clock(e.start) + " · " + e.title : "";
        const nx = document.getElementById("pmc-next");
        if (nx) nx.textContent = e.next[0] ? t("next") + " " + UI.clock(e.next[0].start) + " · " + e.next[0].title : "";
        const bar = document.getElementById("pmc-bar");
        if (bar) bar.style.width = (e.has ? e.progress : 0) + "%";
      }
    },

    showControls: function (ms) {
      const box = document.getElementById(this.tv ? "tvo" : "pmc");
      if (!box) return;
      box.classList.add("show");
      this.updateControls();
      clearTimeout(this.hideTimer);
      this.hideTimer = setTimeout(() => {
        if (this.video && this.video.paused && !this.tv) return;
        if (this.listVisible || this.seeking) return;
        box.classList.remove("show");
      }, ms || (this.tv ? 5000 : 4000));
    },

    showZap: function () {
      const z = document.getElementById("pl-zap");
      if (!z || this.tv) return;
      z.innerHTML = '<b>' + Number(this.channel.number || this.index + 1) + '</b><span>' + UI.esc(this.channel.name) + '</span>';
      z.classList.remove("hidden");
      clearTimeout(this.zapTimer);
      this.zapTimer = setTimeout(() => z.classList.add("hidden"), 1400);
    },

    togglePlay: function () {
      if (!this.video) return;
      if (this.video.paused) {
        const p = this.video.play();
        if (p && p.catch) p.catch(function () {});
      } else {
        this.video.pause();
      }
      this.showControls();
    },

    seekBy: function (sec) {
      const v = this.video;
      if (!this.isVod() || !v || !isFinite(v.duration)) return;
      v.currentTime = Math.max(0, Math.min(v.duration - 1, (v.currentTime || 0) + sec));
      this.message((sec > 0 ? "+" : "−") + Math.abs(sec) + " " + t("sec"), 700);
      this.showControls();
    },

    zap: function (delta) {
      if (this.channels.length < 2) return;
      this.saveProgress();
      const n = this.channels.length;
      this.index = (this.index + delta + n) % n;
      this.channel = this.channels[this.index];
      this.sideIndex = this.index;
      this.load(true);
    },

    playIndex: function (i) {
      if (i < 0 || i >= this.channels.length) return;
      this.saveProgress();
      this.index = i;
      this.channel = this.channels[i];
      this.sideIndex = i;
      this.closeList();
      this.load(true);
    },

    toggleFav: function () {
      if (!window.StorageCore) return;
      const added = StorageCore.toggleFavorite(this.favItem());
      this.message(added ? "★ " + t("addedToFavorites") : t("removedFromFavorites"), 1100);
      this.renderControls();
      this.showControls();
    },

    cycleAspect: function () {
      if (!window.PlayerEngine) return;
      const order = ["contain", "cover", "fill"];
      const cur = PlayerEngine.aspect || "contain";
      const next = order[(order.indexOf(cur) + 1) % order.length];
      PlayerEngine.setAspect(next);
      const label = next === "cover" ? t("aspectZoom") : next === "fill" ? t("aspectStretch") : t("aspectOriginal");
      this.message(label, 900);
    },

    /* ---------------- channel list ---------------- */
    openList: function () {
      if (this.channels.length < 2) return;
      const side = document.getElementById("side");
      if (!side) return;
      this.listVisible = true;
      this.sideIndex = this.index;
      const first = this.channels[0] || {};
      let html = '<div class="side-head"><h3 class="ellipsis">' + UI.esc(first.group && this.channels.every(function (c) { return c.group === first.group; }) ? UI.catName(first.group) : t("channels")) + '</h3><p>' + UI.esc(t("channelsCount", { n: this.channels.length })) + '</p></div><div class="side-list" id="side-list">';
      this.channels.forEach((c, i) => {
        html += '<button class="side-row' + (i === this.index ? " cur" : "") + (this.tv && i === this.sideIndex ? " sel" : "") + '" data-si="' + i + '"><span class="num">' + Number(c.number || i + 1) + '</span>' + UI.logo(c) +
          '<span class="grow"><span class="nm" style="display:block">' + UI.esc(c.name) + '</span><span class="pg" style="display:block">' + UI.esc(UI.epg(c).title || "") + '</span></span></button>';
      });
      html += '</div>';
      side.innerHTML = html;
      side.classList.add("show");
      side.onclick = (e) => {
        const r = e.target.closest("[data-si]");
        if (r) this.playIndex(Number(r.getAttribute("data-si")));
      };
      this.scrollSide();
      const box = document.getElementById(this.tv ? "tvo" : "pmc");
      if (box) box.classList.remove("show");
    },

    scrollSide: function () {
      const row = document.querySelector('.side-row[data-si="' + this.sideIndex + '"]');
      if (row) try { row.scrollIntoView({ block: "center" }); } catch (e) {}
    },

    moveSide: function (d) {
      const n = this.channels.length;
      this.sideIndex = Math.max(0, Math.min(n - 1, this.sideIndex + d));
      document.querySelectorAll(".side-row").forEach((r, i) => r.classList.toggle("sel", i === this.sideIndex));
      this.scrollSide();
    },

    closeList: function () {
      this.listVisible = false;
      const side = document.getElementById("side");
      if (side) side.classList.remove("show");
    },

    /* ---------------- keys (TV remote + keyboards) ---------------- */
    numberInput: function (d) {
      if (this.isVod() || this.channels.length < 2) return;
      this.numberBuffer = (this.numberBuffer + d).slice(-4);
      const el = document.getElementById("pl-num");
      if (el) { el.textContent = this.numberBuffer; el.classList.remove("hidden"); }
      clearTimeout(this.numTimer);
      this.numTimer = setTimeout(() => this.commitNumber(), 1200);
    },

    commitNumber: function () {
      const num = Number(this.numberBuffer);
      this.numberBuffer = "";
      const el = document.getElementById("pl-num");
      if (el) el.classList.add("hidden");
      if (!num) return;
      let found = this.channels.findIndex(function (c, i) { return Number(c.number || i + 1) === num; });
      if (found < 0 && num <= this.channels.length) found = num - 1;
      if (found >= 0) this.playIndex(found);
      else this.message(t("channelNotFound", { n: num }), 1200);
    },

    onKey: function (e) {
      const k = e.key, c = e.keyCode;
      const up = k === "ArrowUp" || c === 38, down = k === "ArrowDown" || c === 40;
      const left = k === "ArrowLeft" || c === 37, right = k === "ArrowRight" || c === 39;
      const ok = k === "Enter" || c === 13;
      const chUp = k === "ChannelUp" || k === "PageUp" || c === 33 || c === 427;
      const chDn = k === "ChannelDown" || k === "PageDown" || c === 34 || c === 428;
      const vod = this.isVod();

      if (/^[0-9]$/.test(k) || (c >= 48 && c <= 57) || (c >= 96 && c <= 105)) {
        const d = /^[0-9]$/.test(k) ? k : String(c >= 96 ? c - 96 : c - 48);
        this.numberInput(d);
        return true;
      }
      if (k === "MediaPlayPause" || c === 179 || c === 415 || c === 19 || k === " ") { this.togglePlay(); return true; }
      if (c === 417 || k === "MediaFastForward") { this.seekBy(30); return true; }
      if (c === 412 || k === "MediaRewind") { this.seekBy(-30); return true; }
      if (c === 403 || c === 404 || c === 405 || c === 406) { this.toggleFav(); return true; }

      if (this.listVisible) {
        if (up) { this.moveSide(-1); return true; }
        if (down) { this.moveSide(1); return true; }
        if (chUp) { this.moveSide(-8); return true; }
        if (chDn) { this.moveSide(8); return true; }
        if (ok) { this.playIndex(this.sideIndex); return true; }
        if (left || right) { this.closeList(); this.showControls(); return true; }
        return false;
      }

      if (chUp) { this.zap(1); return true; }
      if (chDn) { this.zap(-1); return true; }
      if (ok) { this.togglePlay(); return true; }
      if (vod) {
        if (left) { this.seekBy(-10); return true; }
        if (right) { this.seekBy(10); return true; }
        if (up || down) { this.showControls(); return true; }
        return false;
      }
      if (up) { this.zap(1); return true; }
      if (down) { this.zap(-1); return true; }
      if (left) { this.openList(); return true; }
      if (right) { this.showControls(); return true; }
      return false;
    },

    onBack: function () {
      if (this.listVisible) { this.closeList(); return true; }
      if (this.numberBuffer) { this.numberBuffer = ""; const el = document.getElementById("pl-num"); if (el) el.classList.add("hidden"); return true; }
      return false;
    },

    saveProgress: function () {
      if (!this.video || !this.isVod()) return;
      UI.saveProgress(this.channel, this.video.currentTime || 0, this.video.duration);
    },

    refresh: function (reason) {
      if (reason === "epg") this.updateControls();
    },

    destroy: function () {
      this.saveProgress();
      clearInterval(this.clockTimer);
      clearInterval(this.saveTimer);
      clearTimeout(this.hideTimer);
      clearTimeout(this.zapTimer);
      clearTimeout(this.msgTimer);
      clearTimeout(this.numTimer);
      if (this.video && this._vEvents) {
        ["play", "pause", "playing", "timeupdate", "durationchange", "loadedmetadata"].forEach((ev) => this.video.removeEventListener(ev, this._vEvents));
        this.video.removeEventListener("loadedmetadata", this._meta);
      }
      if (window.PlayerEngine) PlayerEngine.destroy();
      if (window.Platform && Platform.isAndroid) Platform.exitPlayerMode();
      this.video = null;
      this.bound = false;
      this.listVisible = false;
    }
  };

  window.PlayerPage = PlayerPage;
})();
